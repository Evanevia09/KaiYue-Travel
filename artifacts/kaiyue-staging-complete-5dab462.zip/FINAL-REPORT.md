# Staging complete-ledger package (PROPOSED, not approved)

**task_id:** kai-yue-temporary-admin-login-20261110
**Status:** packaged only. Mika assessing a staging-only full rebuilt ledger + Worker trial on the same Worker/D1. Awaiting her decision. No executor writes. Not production. Not `user_accepted`. Not `released`.

Additive 14-file jwt + keep_assets remains **unsafe**. This archive is the **complete** `dist/client` ledger plus bundled `entry.js`. HTML is an intentionally new staged version (`PUBLIC_SITE_URL=https://kaiyue-travel-staging.kai-yue.workers.dev`).

## Identifiers

| Item | Value |
| --- | --- |
| runtimeSourceSHA | `5dab46281ce84b5b5974a28bdb9f94513c670644` |
| docs commit SHA | *fill after docs commit; differs if this report is committed later* |
| GitHub Actions CI | [42864265892](https://github.com/Evanevia09/KaiYue-Travel/actions/runs/42864265892) **success** on runtimeSourceSHA (job `check`) |
| Script | `kaiyue-travel-staging` |
| D1 | `043cd0ff-a1e6-4b5e-98c1-968c286e0c70` (unchanged) |
| R2 | `kaiyue-offers-staging` (unchanged) |
| main_module | `entry.js` |
| MIME | `application/javascript+module` |
| entry.js bytes | 4185645 |
| entry.js sha256 | `4e21131158d4a69516eccf60ee05bbf65a274ec2fbfc11c1a91ef631932e4654` |
| Wrangler dry-run size | 4087.54 KiB / gzip 820.84 KiB |
| Asset files in ledger | 136 |
| Skipped metafiles | 3 (`_headers`, `_redirects`) |
| Ledger bytes (sum size) | 11603025 |
| HTML files | 60 (60 contain staging workers.dev URL) |
| `/_astro/*` files | 31 |

Do **not** use keep_assets. Do **not** use a 14-file jwt.

## Reproducibility

```
git checkout 5dab46281ce84b5b5974a28bdb9f94513c670644
PUBLIC_SITE_URL=https://kaiyue-travel-staging.kai-yue.workers.dev pnpm --filter @kaiyue/web build
node scripts/require-wrangler-env.mjs --env staging
npx wrangler versions upload --dry-run --outdir DIR --env staging --name kaiyue-travel-staging --keep-vars
```

CI `pnpm build` uses `PUBLIC_SITE_URL=https://example.invalid`, so CI HTML hashes **do not** match this staging-URL ledger.

`entry.js` is **not bit-stable** across rebuilds of the same SHA: Astro embeds a per-build random `key` in serialized config (observed vs 68f751b package: same 4185645 bytes, different sha256; only that key differed). Size and wrangler dry-run KiB matched.

Asset CF hashes use wrangler `blake3-wasm.hash(base64(contents)+extension).hex[0:32]`. `_headers` / `_redirects` are config, not ledger keys.

## Changed public HTML / unknown-asset risk (assess, not a prohibition)

- **HTML:** all prerendered HTML in this ledger is a new staged version (canonical/sitemap/og URLs use staging workers.dev). That replaces unpublished Nov 5 HTML. Intended for this trial. Rollback = previous Worker version including its assets.
- **Public hashed JS:** 17 live-matching `/_astro` islands from the parity crawl remain in this dist under the same filenames; CF reuses blobs when hashes already exist in the account. 14 admin/login hashes that 404 today are included in this complete ledger.
- **Unknown live-only files:** no list API. Files on live staging that are absent from this git dist would drop from the new version. That is a residual risk to assess, not an automatic block. Rollback restores the old version’s full asset set.
- **Images / other static:** included in full. Matching bytes reuse by hash; unmatched live-only objects (if any) are the unknown gap.
- **Worker:** new `entry.js` (auth/login). Secrets via `keep_bindings: ["secret_text"]`. Do not mutate staging `ADMIN_EMAILS` / expiry values (template matches current config).

## Connector JWT capability

`POST /workers/assets/upload?base64=true` **must** use `Authorization: Bearer <assets-upload-session jwt>`, not the account token. If the connector cannot switch that header, it cannot run the official complete-manifest flow. Do not paste credentials. See `OPERATOR-API-PLAN.txt`. Wrangler CLI is the operator fallback after approval.

## Provisioner

Env-only hasher zip from runtimeSourceSHA is **unchanged** in this increment. Do not start the loopback server. Do not send passwords or Cloudflare secrets to the agent.

## Do not

Merge, upload, deploy, retry production Workers Builds, or PUT this package until Mika approves.
