#!/usr/bin/env node
/**
 * Build a local multipart/form-data dump for PUT
 * /accounts/:id/workers/scripts/kaiyue-travel-staging
 *
 * Does not send network. Does not read credentials.
 *
 *   node package-multipart.mjs
 */
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const metadata = readFileSync(join(root, "metadata.staging.keep_assets.json"));
const entry = readFileSync(join(root, "worker-modules/entry.js"));
const boundary = "----KaiYueWorkerForm" + Date.now().toString(16);
const chunks = [];

function part(name, content, type, filename) {
  const disp = filename
    ? `Content-Disposition: form-data; name="${name}"; filename="${filename}"`
    : `Content-Disposition: form-data; name="${name}"`;
  const headers = [disp, `Content-Type: ${type}`, "", ""].join("\r\n");
  chunks.push(Buffer.from(`--${boundary}\r\n${headers}`, "utf8"));
  chunks.push(Buffer.isBuffer(content) ? content : Buffer.from(content));
  chunks.push(Buffer.from("\r\n"));
}

part("metadata", metadata, "application/json");
part("entry.js", entry, "application/javascript+module", "entry.js");
chunks.push(Buffer.from(`--${boundary}--\r\n`));
const body = Buffer.concat(chunks);
writeFileSync(join(root, "multipart.bin"), body);
writeFileSync(
  join(root, "multipart.headers.txt"),
  `Content-Type: multipart/form-data; boundary=${boundary}\nContent-Length: ${body.length}\n`,
);
process.stdout.write(
  `Wrote multipart.bin (${body.length} bytes). Not sent. Add Authorization via sanctioned connector.\n`,
);
