Kai Yue staging Worker package
Source SHA: 68f751be9e79171198020e7a157f295bff5db1ee
Script: kaiyue-travel-staging
main_module: entry.js
MIME: application/javascript+module
Bundled by: wrangler deploy --dry-run --env staging (no network upload)
Built: 2026-11-10T17:06:22.938Z

WHAT THIS IS
- worker-modules/entry.js : the exact Wrangler-bundled Worker (same main_module name as the recovered Nov5 entry.js)
- astro-split-modules/     : unbundled Astro adapter output (entry.mjs + chunks). Inspection only; do not PUT these unless you also change main_module to entry.mjs and attach every chunk.
- new-assets-required/     : hashed files that are NOT on live staging today. keep_assets will NOT install them.
- metadata.staging.keep_assets.json : multipart metadata template (no secret values)
- assets-upload-session.manifest.json : CF assets-upload-session body for the new files only
- package-multipart.mjs    : builds a local multipart dump; does not send HTTP

KEEP_ASSETS
Public /_astro islands used on live routes already byte-match this build. keep_assets:true is correct for those.
/login is SSR and will request LoginForm + AdminLocaleSwitch + admin-i18n. Those hashes 404 on live.
After sign-in, /admin needs additional admin islands listed in MANIFEST.json.

SAFE ASSET UPLOAD (required if /login or /admin HTML is served)
1. POST .../workers/scripts/kaiyue-travel-staging/assets-upload-session
   body: assets-upload-session.manifest.json
2. POST .../workers/assets/upload?base64=true  (JWT from step 1)
   each new file: field name = cf_hash_32, value = base64(bytes), Content-Type = application/javascript
3. PUT script with keep_assets:true AND assets.jwt = completion token from step 2
   — or keep_assets:true alone AFTER the new files exist in the account asset store for this script.

Do NOT keep_assets-only and then open /login: LoginForm.DI7HqLqN.js will 404.

CONSTRAINTS
- No wrangler deploy / versions upload from the agent that built this.
- No production Workers Builds retry.
- No secret values in this zip. keep_bindings: ["secret_text"]
- Do not bind D1 069aa442.
- PUT script deploys immediately.
- Production password capability stays closed until later user approval after staging persists.

See FINAL-REPORT.md for hashes, the 14 required new assets (including
api._aekQyCR.js), and why keep_assets alone is not enough for /login.
