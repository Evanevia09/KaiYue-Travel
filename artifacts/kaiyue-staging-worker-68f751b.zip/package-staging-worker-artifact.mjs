/**
 * Local-only packager. Does not upload, does not read secrets, does not
 * call Cloudflare write APIs. Probes live hosts with GET for asset hashes.
 */
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import {
  copyFileSync,
  cpSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, relative } from "node:path";

const ROOT = "/agent/repos/KaiYue-Travel";
const SOURCE_SHA = execFileSync("git", ["rev-parse", "HEAD"], { cwd: ROOT, encoding: "utf8" }).trim();
const DIST_CLIENT = join(ROOT, "apps/web/dist/client");
const DIST_SERVER = join(ROOT, "apps/web/dist/server");
const BUNDLE = "/tmp/kaiyue-wrangler-dry-run";
const STAGING = "https://kaiyue-travel-staging.kai-yue.workers.dev";
const PROD = "https://kaiyuemacau.com";
const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

const OUT = `/tmp/kaiyue-staging-worker-${SOURCE_SHA.slice(0, 7)}`;
const ZIP = `/opt/cursor/artifacts/kaiyue-staging-worker-${SOURCE_SHA.slice(0, 7)}.zip`;
const REPO_ZIP = join(ROOT, "artifacts", `kaiyue-staging-worker-${SOURCE_SHA.slice(0, 7)}.zip`);

function sha256(buf) {
  return createHash("sha256").update(buf).digest("hex");
}
function cfAssetHash(buf) {
  return sha256(buf).slice(0, 32);
}
function mimeForModule(name) {
  if (name.endsWith(".map")) return "application/source-map";
  if (name.endsWith(".wasm")) return "application/wasm";
  if (name.endsWith(".js") || name.endsWith(".mjs")) return "application/javascript+module";
  return "application/octet-stream";
}
function walk(dir, acc = []) {
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) walk(full, acc);
    else acc.push(full);
  }
  return acc;
}

mkdirSync(OUT, { recursive: true });
mkdirSync(join(OUT, "worker-modules"), { recursive: true });
mkdirSync(join(OUT, "astro-split-modules"), { recursive: true });
mkdirSync(join(OUT, "new-assets-required"), { recursive: true });

copyFileSync(join(BUNDLE, "entry.js"), join(OUT, "worker-modules", "entry.js"));
cpSync(DIST_SERVER, join(OUT, "astro-split-modules"), {
  recursive: true,
  filter: (src) => !src.endsWith("wrangler.json") && !src.endsWith(".dev.vars"),
});

const entryBuf = readFileSync(join(OUT, "worker-modules", "entry.js"));
const workerModules = [
  {
    name: "entry.js",
    path: "worker-modules/entry.js",
    mime: "application/javascript+module",
    sha256: sha256(entryBuf),
    bytes: entryBuf.length,
    role: "main_module",
  },
];

const splitModules = walk(join(OUT, "astro-split-modules"))
  .filter((p) => p.endsWith(".mjs") || p.endsWith(".js"))
  .map((full) => {
    const buf = readFileSync(full);
    const rel = relative(join(OUT, "astro-split-modules"), full).replaceAll("\\", "/");
    return {
      name: rel,
      path: `astro-split-modules/${rel}`,
      mime: "application/javascript+module",
      sha256: sha256(buf),
      bytes: buf.length,
      role: rel === "entry.mjs" ? "astro_unbundled_entrypoint" : "astro_split_chunk",
    };
  })
  .sort((a, b) => a.name.localeCompare(b.name));

const clientFiles = walk(DIST_CLIENT).filter((full) => {
  const rel = relative(DIST_CLIENT, full).replaceAll("\\", "/");
  return !rel.endsWith("wrangler.json") && !rel.includes(".dev.vars");
});

const assets = [];
for (const full of clientFiles) {
  const rel = "/" + relative(DIST_CLIENT, full).replaceAll("\\", "/");
  const buf = readFileSync(full);
  assets.push({
    path: rel,
    sha256: sha256(buf),
    cf_hash_32: cfAssetHash(buf),
    bytes: buf.length,
    kind: rel.startsWith("/_astro/") ? "astro-island" : rel.endsWith(".html") ? "html" : "static",
  });
}
assets.sort((a, b) => a.path.localeCompare(b.path));

async function probe(origin, path) {
  const url = `${origin}${path}`;
  try {
    const res = await fetch(url, { headers: { "user-agent": UA }, redirect: "follow" });
    const buf = Buffer.from(await res.arrayBuffer());
    return { status: res.status, sha256: sha256(buf), bytes: buf.length };
  } catch (error) {
    return { status: 0, error: String(error) };
  }
}

const astroAssets = assets.filter((a) => a.kind === "astro-island");
const comparisons = [];
for (const asset of astroAssets) {
  const staging = await probe(STAGING, asset.path);
  const prod = await probe(PROD, asset.path);
  const stagingMatch = staging.status === 200 && staging.sha256 === asset.sha256;
  const prodMatch = prod.status === 200 && prod.sha256 === asset.sha256;
  comparisons.push({
    path: asset.path,
    dist_sha256: asset.sha256,
    dist_cf_hash_32: asset.cf_hash_32,
    dist_bytes: asset.bytes,
    staging_status: staging.status,
    staging_sha256: staging.sha256,
    staging_match: stagingMatch,
    prod_status: prod.status,
    prod_sha256: prod.sha256,
    prod_match: prodMatch,
    keep_assets_covers: stagingMatch,
    required_new_upload: !stagingMatch,
  });
}

const newRequired = comparisons.filter((row) => row.required_new_upload);
for (const row of newRequired) {
  const src = join(DIST_CLIENT, row.path.slice(1));
  copyFileSync(src, join(OUT, "new-assets-required", row.path.replace("/_astro/", "")));
}

function findAstro(prefix) {
  const hit = assets.find((row) => row.path.startsWith(`/_astro/${prefix}.`) && row.path.endsWith(".js"));
  return hit?.path;
}
const loginGraph = [
  findAstro("LoginForm"),
  findAstro("AdminLocaleSwitch"),
  findAstro("admin-i18n"),
  findAstro("auth-client"),
  findAstro("react"),
  findAstro("jsx-runtime"),
].filter(Boolean);
const adminAfterLogin = comparisons
  .filter((row) =>
    /LoginForm|AdminLocaleSwitch|admin-i18n|SetupForm|SignOutButton|DashboardPanel|BookingsPanel|BookingDetailPanel|CalendarPanel|ContactsPanel|ContactDetailPanel|InventoryPanel|OffersPanel|\/api\./.test(
      row.path,
    ),
  )
  .map((row) => row.path);

const metadata = {
  main_module: "entry.js",
  keep_assets: true,
  keep_bindings: ["secret_text"],
  compatibility_date: "2026-09-01",
  compatibility_flags: ["nodejs_compat"],
  annotations: {
    "workers/tag": `git-${SOURCE_SHA.slice(0, 7)}`,
    "workers/message": "Temporary allowlisted admin login for staging. keep_assets true; upload new admin islands first.",
  },
  bindings: [
    { type: "assets", name: "ASSETS" },
    {
      type: "d1",
      name: "DB",
      id: "043cd0ff-a1e6-4b5e-98c1-968c286e0c70",
    },
    {
      type: "r2_bucket",
      name: "OFFERS_BUCKET",
      bucket_name: "kaiyue-offers-staging",
    },
    { type: "plain_text", name: "ENVIRONMENT", text: "preview" },
    {
      type: "plain_text",
      name: "PUBLIC_SITE_URL",
      text: "https://kaiyue-travel-staging.kai-yue.workers.dev",
    },
    { type: "plain_text", name: "BUSINESS_TIMEZONE", text: "Asia/Macau" },
    { type: "plain_text", name: "BOOKING_NOTICE_HOURS", text: "24" },
    { type: "plain_text", name: "WHATSAPP_NUMBER", text: "+85328338882" },
    { type: "plain_text", name: "ACCESS_TEAM_DOMAIN", text: "" },
    { type: "plain_text", name: "ACCESS_AUD", text: "" },
    { type: "plain_text", name: "DEV_ADMIN_BYPASS", text: "false" },
    { type: "plain_text", name: "ADMIN_EMAILS", text: "daniel@kaiyuemacau.com" },
    {
      type: "plain_text",
      name: "TEMP_ADMIN_EXPIRES_AT",
      text: "2026-11-24T15:59:59+08:00",
    },
  ],
};

const assetsUploadSessionManifest = {};
for (const row of newRequired) {
  assetsUploadSessionManifest[row.path] = {
    hash: row.dist_cf_hash_32,
    size: row.dist_bytes,
  };
}

const report = {
  source_sha: SOURCE_SHA,
  built_at: new Date().toISOString(),
  script_name: "kaiyue-travel-staging",
  account_note: "Do not upload from this artifact automatically. PM uses sanctioned CF connector.",
  main_module: "entry.js",
  wrangler_dry_run: {
    command:
      "npx wrangler deploy --dry-run --outdir <out> --env staging --name kaiyue-travel-staging --keep-vars --config wrangler.jsonc",
    uploaded_bytes_reported: "4087.54 KiB / gzip: 820.84 KiB",
    network_upload: false,
  },
  worker_modules: workerModules,
  astro_unbundled: {
    note: "Astro adapter emits no_bundle entry.mjs + chunks. Wrangler root config bundles them into a single entry.js (same shape as recovered Nov5 Worker). PUT script should use bundled entry.js as main_module. Split modules are included for inspection only.",
    adapter_main: "entry.mjs",
    modules: splitModules,
  },
  env_staging: {
    worker_name: "kaiyue-travel-staging",
    compatibility_date: "2026-09-01",
    compatibility_flags: ["nodejs_compat"],
    bindings: {
      ASSETS: { type: "assets" },
      DB: {
        type: "d1",
        database_name: "kaiyue-travel-staging",
        database_id: "043cd0ff-a1e6-4b5e-98c1-968c286e0c70",
      },
      OFFERS_BUCKET: { type: "r2_bucket", bucket_name: "kaiyue-offers-staging" },
    },
    vars: {
      ENVIRONMENT: "preview",
      PUBLIC_SITE_URL: "https://kaiyue-travel-staging.kai-yue.workers.dev",
      BUSINESS_TIMEZONE: "Asia/Macau",
      BOOKING_NOTICE_HOURS: "24",
      WHATSAPP_NUMBER: "+85328338882",
      ACCESS_TEAM_DOMAIN: "",
      ACCESS_AUD: "",
      DEV_ADMIN_BYPASS: "false",
      ADMIN_EMAILS: "daniel@kaiyuemacau.com",
      TEMP_ADMIN_EXPIRES_AT: "2026-11-24T15:59:59+08:00",
    },
    secrets_not_in_artifact: [
      "BETTER_AUTH_SECRET",
      "RESEND_API_KEY",
      "ADMIN_SETUP_TOKEN",
    ],
    keep_bindings: ["secret_text"],
  },
  keep_assets: {
    supported: true,
    sufficient_alone: newRequired.length === 0,
    warning:
      "keep_assets:true retains the previous version's asset set. It does not install new hashed files. /login HTML is SSR (prerender=false) and will reference LoginForm.DI7HqLqN.js. That file 404s on live today.",
  },
  login_island_graph: loginGraph,
  admin_islands_after_login: adminAfterLogin,
  new_assets_required: newRequired,
  existing_matching_astro: comparisons.filter((row) => row.keep_assets_covers).map((row) => row.path),
  asset_comparisons: comparisons,
  dist_assets: assets,
  constraints: [
    "Do not wrangler deploy or wrangler versions upload from an agent.",
    "Do not retry production Workers Builds kaiyue-travel.",
    "PUT /workers/scripts/kaiyue-travel-staging deploys immediately; prefer versions API then a percentage deploy if available.",
    "keep_assets:true will not install new_assets_required.",
    "Do not upload dist HTML; it was built with staging PUBLIC_SITE_URL and would replace live HTML. keep_assets preserves current public pages.",
    "Do not include secret values. Use keep_bindings: ['secret_text'] so BETTER_AUTH_SECRET / RESEND_API_KEY remain.",
    "Do not bind D1 069aa442.",
    "Source maps omitted (contain local absolute paths).",
    "User approval for production is later, after staging persists.",
  ],
};

writeFileSync(join(OUT, "MANIFEST.json"), JSON.stringify(report, null, 2));
writeFileSync(join(OUT, "metadata.staging.keep_assets.json"), JSON.stringify(metadata, null, 2));
writeFileSync(
  join(OUT, "assets-upload-session.manifest.json"),
  JSON.stringify({ manifest: assetsUploadSessionManifest }, null, 2),
);
writeFileSync(join(OUT, "SOURCE-SHA.txt"), `${SOURCE_SHA}\n`);

const readme = `Kai Yue staging Worker package
Source SHA: ${SOURCE_SHA}
Script: kaiyue-travel-staging
main_module: entry.js
MIME: application/javascript+module
Bundled by: wrangler deploy --dry-run --env staging (no network upload)
Built: ${report.built_at}

WHAT THIS IS
- worker-modules/entry.js : the exact Wrangler-bundled Worker (same main_module name as the recovered Nov5 entry.js)
- astro-split-modules/     : unbundled Astro adapter output (entry.mjs + chunks). Inspection only; do not PUT these unless you also change main_module to entry.mjs and attach every chunk.
- new-assets-required/     : hashed files that are NOT on live staging today. keep_assets will NOT install them.
- metadata.staging.keep_assets.json : multipart metadata template (no secret values)
- assets-upload-session.manifest.json : CF assets-upload-session body for the new files only
- package-multipart.mjs    : builds a local multipart dump; does not send HTTP

KEEP_ASSETS
Public /_astro islands used on live routes already byte-match this build. keep_assets:true is correct for those.
/login is SSR and will request LoginForm + AdminLocaleSwitch + admin-i18n. Those hashes 404 on live.
After sign-in, /admin needs additional admin islands listed in MANIFEST.json.

SAFE ASSET UPLOAD (required if /login or /admin HTML is served)
1. POST .../workers/scripts/kaiyue-travel-staging/assets-upload-session
   body: assets-upload-session.manifest.json
2. POST .../workers/assets/upload?base64=true  (JWT from step 1)
   each new file: field name = cf_hash_32, value = base64(bytes), Content-Type = application/javascript
3. PUT script with keep_assets:true AND assets.jwt = completion token from step 2
   — or keep_assets:true alone AFTER the new files exist in the account asset store for this script.

Do NOT keep_assets-only and then open /login: LoginForm.DI7HqLqN.js will 404.

CONSTRAINTS
- No wrangler deploy / versions upload from the agent that built this.
- No production Workers Builds retry.
- No secret values in this zip. keep_bindings: ["secret_text"]
- Do not bind D1 069aa442.
- PUT script deploys immediately.
- Production password capability stays closed until later user approval after staging persists.
`;

writeFileSync(join(OUT, "README.txt"), readme);

copyFileSync("/tmp/package-multipart.mjs", join(OUT, "package-multipart.mjs"));

execFileSync("zip", ["-r", "-q", ZIP, "."], { cwd: OUT });
mkdirSync(dirname(REPO_ZIP), { recursive: true });
copyFileSync(ZIP, REPO_ZIP);
process.stdout.write(
  JSON.stringify(
    {
      source_sha: SOURCE_SHA,
      zip: ZIP,
      repo_zip: REPO_ZIP,
      main_module: "entry.js",
      entry_sha256: workerModules[0].sha256,
      entry_bytes: workerModules[0].bytes,
      new_assets: newRequired.length,
      matching_astro: comparisons.filter((r) => r.keep_assets_covers).length,
      total_astro: comparisons.length,
    },
    null,
    2,
  ) + "\n",
);
