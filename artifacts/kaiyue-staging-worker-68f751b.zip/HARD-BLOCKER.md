HARD BLOCKER: do not PUT keep_assets:true together with a 14-file assets.jwt.

Official Upload Worker: an explicit assets upload takes precedence over
keep_assets (not a union). The assets-upload-session manifest is the
version ledger. A 14-file jwt would drop unpublished public assets.

Live missing /_astro/LoginForm.DI7HqLqN.js and api._aekQyCR.js never
reach the Worker (404.html, no x-request-id). Extra text modules cannot
serve them. run_worker_first cannot be applied via keep_assets-only
metadata.

Do not invent APIs. Do not wrangler deploy. Do not retry production
Workers Builds. See docs/records/2026-11-10-staging-asset-add-blocker.md.
