globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, H as clsx, K as createAstro, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, i as adminDateLocale, l as prefixedLabel, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, r as formatWhen, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
//#region ../../node_modules/.pnpm/mimic-function@5.0.1/node_modules/mimic-function/index.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var copyProperty = (to, from, property, ignoreNonConfigurable) => {
	if (property === "length" || property === "prototype") return;
	if (property === "arguments" || property === "caller") return;
	const toDescriptor = Object.getOwnPropertyDescriptor(to, property);
	const fromDescriptor = Object.getOwnPropertyDescriptor(from, property);
	if (!canCopyProperty(toDescriptor, fromDescriptor) && ignoreNonConfigurable) return;
	Object.defineProperty(to, property, fromDescriptor);
};
var canCopyProperty = function(toDescriptor, fromDescriptor) {
	return toDescriptor === void 0 || toDescriptor.configurable || toDescriptor.writable === fromDescriptor.writable && toDescriptor.enumerable === fromDescriptor.enumerable && toDescriptor.configurable === fromDescriptor.configurable && (toDescriptor.writable || toDescriptor.value === fromDescriptor.value);
};
var changePrototype = (to, from) => {
	const fromPrototype = Object.getPrototypeOf(from);
	if (fromPrototype === Object.getPrototypeOf(to)) return;
	Object.setPrototypeOf(to, fromPrototype);
};
var wrappedToString = (withName, fromBody) => `/* Wrapped ${withName}*/\n${fromBody}`;
var toStringDescriptor = Object.getOwnPropertyDescriptor(Function.prototype, "toString");
var toStringName = Object.getOwnPropertyDescriptor(Function.prototype.toString, "name");
var changeToString = (to, from, name) => {
	const withName = name === "" ? "" : `with ${name.trim()}() `;
	const newToString = wrappedToString.bind(null, withName, from.toString());
	Object.defineProperty(newToString, "name", toStringName);
	const { writable, enumerable, configurable } = toStringDescriptor;
	Object.defineProperty(to, "toString", {
		value: newToString,
		writable,
		enumerable,
		configurable
	});
};
function mimicFunction(to, from, { ignoreNonConfigurable = false } = {}) {
	const { name } = to;
	for (const property of Reflect.ownKeys(from)) copyProperty(to, from, property, ignoreNonConfigurable);
	changePrototype(to, from);
	changeToString(to, from, name);
	return to;
}
//#endregion
//#region ../../node_modules/.pnpm/memoize@10.2.0/node_modules/memoize/distribution/index.js
var maxTimeoutValue = 2147483647;
var cacheStore = /* @__PURE__ */ new WeakMap();
var cacheTimerStore = /* @__PURE__ */ new WeakMap();
var cacheKeyStore = /* @__PURE__ */ new WeakMap();
function getValidCacheItem(cache, key) {
	const item = cache.get(key);
	if (!item) return;
	if (item.maxAge <= Date.now()) {
		cache.delete(key);
		return;
	}
	return item;
}
/**
[Memoize](https://en.wikipedia.org/wiki/Memoization) functions - An optimization used to speed up consecutive function calls by caching the result of calls with identical input.

@param function_ - The function to be memoized.

@example
```
import memoize from 'memoize';

let index = 0;
const counter = () => ++index;
const memoized = memoize(counter);

memoized('foo');
//=> 1

// Cached as it's the same argument
memoized('foo');
//=> 1

// Not cached anymore as the arguments changed
memoized('bar');
//=> 2

memoized('bar');
//=> 2
```
*/
function memoize(function_, { cacheKey, cache = /* @__PURE__ */ new Map(), maxAge } = {}) {
	if (maxAge === 0) return function_;
	if (typeof maxAge === "number" && Number.isFinite(maxAge)) {
		if (maxAge > maxTimeoutValue) throw new TypeError(`The \`maxAge\` option cannot exceed ${maxTimeoutValue}.`);
		if (maxAge < 0) throw new TypeError("The `maxAge` option should not be a negative number.");
	}
	const memoized = function(...arguments_) {
		const key = cacheKey ? cacheKey(arguments_) : arguments_[0];
		const cacheItem = getValidCacheItem(cache, key);
		if (cacheItem) return cacheItem.data;
		const result = function_.apply(this, arguments_);
		const computedMaxAge = typeof maxAge === "function" ? maxAge(...arguments_) : maxAge;
		if (computedMaxAge !== void 0 && computedMaxAge !== Number.POSITIVE_INFINITY) {
			if (!Number.isFinite(computedMaxAge)) throw new TypeError("The `maxAge` function must return a finite number, `0`, or `Infinity`.");
			if (computedMaxAge <= 0) return result;
			if (computedMaxAge > maxTimeoutValue) throw new TypeError(`The \`maxAge\` function result cannot exceed ${maxTimeoutValue}.`);
		}
		cache.set(key, {
			data: result,
			maxAge: computedMaxAge === void 0 || computedMaxAge === Number.POSITIVE_INFINITY ? Number.POSITIVE_INFINITY : Date.now() + computedMaxAge
		});
		if (computedMaxAge !== void 0 && computedMaxAge !== Number.POSITIVE_INFINITY) {
			const timer = setTimeout(() => {
				cache.delete(key);
				cacheTimerStore.get(memoized)?.delete(timer);
			}, computedMaxAge);
			timer.unref?.();
			const timers = cacheTimerStore.get(memoized) ?? /* @__PURE__ */ new Set();
			timers.add(timer);
			cacheTimerStore.set(memoized, timers);
		}
		return result;
	};
	mimicFunction(memoized, function_, { ignoreNonConfigurable: true });
	cacheStore.set(memoized, cache);
	cacheKeyStore.set(memoized, cacheKey ?? ((arguments_) => arguments_[0]));
	return memoized;
}
//#endregion
//#region ../../node_modules/.pnpm/get-user-locale@3.0.0/node_modules/get-user-locale/dist/index.js
function isString(el) {
	return typeof el === "string";
}
function isUnique(el, index, arr) {
	return arr.indexOf(el) === index;
}
function isAllLowerCase(el) {
	return el.toLowerCase() === el;
}
function fixCommas(el) {
	return el.indexOf(",") === -1 ? el : el.split(",");
}
function normalizeLocale(locale) {
	if (!locale) return locale;
	if (locale === "C" || locale === "posix" || locale === "POSIX") return "en-US";
	if (locale.indexOf(".") !== -1) {
		var _a = locale.split(".")[0], actualLocale = _a === void 0 ? "" : _a;
		return normalizeLocale(actualLocale);
	}
	if (locale.indexOf("@") !== -1) {
		var _b = locale.split("@")[0], actualLocale = _b === void 0 ? "" : _b;
		return normalizeLocale(actualLocale);
	}
	if (locale.indexOf("-") === -1 || !isAllLowerCase(locale)) return locale;
	var _c = locale.split("-"), splitEl1 = _c[0], _d = _c[1], splitEl2 = _d === void 0 ? "" : _d;
	return "".concat(splitEl1, "-").concat(splitEl2.toUpperCase());
}
function getUserLocalesInternal(_a) {
	var _b = _a === void 0 ? {} : _a, _c = _b.useFallbackLocale, useFallbackLocale = _c === void 0 ? true : _c, _d = _b.fallbackLocale, fallbackLocale = _d === void 0 ? "en-US" : _d;
	var languageList = [];
	if (typeof navigator !== "undefined") {
		var rawLanguages = navigator.languages || [];
		var languages = [];
		for (var _i = 0, rawLanguages_1 = rawLanguages; _i < rawLanguages_1.length; _i++) {
			var rawLanguagesItem = rawLanguages_1[_i];
			languages = languages.concat(fixCommas(rawLanguagesItem));
		}
		var rawLanguage = navigator.language;
		var language = rawLanguage ? fixCommas(rawLanguage) : rawLanguage;
		languageList = languageList.concat(languages, language);
	}
	if (useFallbackLocale) languageList.push(fallbackLocale);
	return languageList.filter(isString).map(normalizeLocale).filter(isUnique);
}
var getUserLocales = memoize(getUserLocalesInternal, { cacheKey: JSON.stringify });
function getUserLocaleInternal(options) {
	return getUserLocales(options)[0] || null;
}
var getUserLocale = memoize(getUserLocaleInternal, { cacheKey: JSON.stringify });
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/shared/dateFormatter.js
var formatterCache = /* @__PURE__ */ new Map();
function getFormatter(options) {
	return function formatter(locale, date) {
		const localeWithDefault = locale || getUserLocale();
		if (!formatterCache.has(localeWithDefault)) formatterCache.set(localeWithDefault, /* @__PURE__ */ new Map());
		const formatterCacheLocale = formatterCache.get(localeWithDefault);
		if (!formatterCacheLocale.has(options)) {
			const formatter = new Intl.DateTimeFormat(localeWithDefault || void 0, options);
			formatterCacheLocale.set(options, formatter.format.bind(formatter));
		}
		return formatterCacheLocale.get(options)(date);
	};
}
/**
* Changes the hour in a Date to ensure right date formatting even if DST is messed up.
* Workaround for bug in WebKit and Firefox with historical dates.
* For more details, see:
* https://bugs.chromium.org/p/chromium/issues/detail?id=750465
* https://bugzilla.mozilla.org/show_bug.cgi?id=1385643
*
* @param {Date} date Date.
* @returns {Date} Date with hour set to 12.
*/
function toSafeHour(date) {
	const safeDate = new Date(date);
	return new Date(safeDate.setHours(12));
}
function getSafeFormatter(options) {
	return (locale, date) => getFormatter(options)(locale, toSafeHour(date));
}
var formatDayOptions = { day: "numeric" };
var formatLongDateOptions = {
	day: "numeric",
	month: "long",
	year: "numeric"
};
var formatMonthOptions = { month: "long" };
var formatMonthYearOptions = {
	month: "long",
	year: "numeric"
};
var formatShortWeekdayOptions = { weekday: "short" };
var formatWeekdayOptions = { weekday: "long" };
var formatYearOptions = { year: "numeric" };
var formatDay = getSafeFormatter(formatDayOptions);
var formatLongDate = getSafeFormatter(formatLongDateOptions);
var formatMonth = getSafeFormatter(formatMonthOptions);
var formatMonthYear = getSafeFormatter(formatMonthYearOptions);
var formatShortWeekday = getSafeFormatter(formatShortWeekdayOptions);
var formatWeekday = getSafeFormatter(formatWeekdayOptions);
var formatYear = getSafeFormatter(formatYearOptions);
//#endregion
//#region ../../node_modules/.pnpm/@wojtekmaj+date-utils@2.0.2/node_modules/@wojtekmaj/date-utils/dist/index.js
/**
* Utils
*/
function makeGetEdgeOfNeighbor(getPeriod, getEdgeOfPeriod, defaultOffset) {
	return function makeGetEdgeOfNeighborInternal(date, offset = defaultOffset) {
		return getEdgeOfPeriod(getPeriod(date) + offset);
	};
}
function makeGetEnd(getBeginOfNextPeriod) {
	return function makeGetEndInternal(date) {
		return /* @__PURE__ */ new Date(getBeginOfNextPeriod(date).getTime() - 1);
	};
}
function makeGetRange(getStart, getEnd) {
	return function makeGetRangeInternal(date) {
		return [getStart(date), getEnd(date)];
	};
}
/**
* Simple getters - getting a property of a given point in time
*/
/**
* Gets year from a given date.
*
* @param {DateLike} date Date to get year from
* @returns {number} Year
*/
function getYear(date) {
	if (date instanceof Date) return date.getFullYear();
	if (typeof date === "number") return date;
	const year = Number.parseInt(date, 10);
	if (typeof date === "string" && !Number.isNaN(year)) return year;
	throw new Error(`Failed to get year from date: ${date}.`);
}
/**
* Gets month from a given date.
*
* @param {Date} date Date to get month from
* @returns {number} Month
*/
function getMonth(date) {
	if (date instanceof Date) return date.getMonth();
	throw new Error(`Failed to get month from date: ${date}.`);
}
/**
* Gets day of the month from a given date.
*
* @param {Date} date Date to get day of the month from
* @returns {number} Day of the month
*/
function getDate(date) {
	if (date instanceof Date) return date.getDate();
	throw new Error(`Failed to get year from date: ${date}.`);
}
/**
* Century
*/
/**
* Gets century start date from a given date.
*
* @param {DateLike} date Date to get century start from
* @returns {Date} Century start date
*/
function getCenturyStart(date) {
	const year = getYear(date);
	const centuryStartYear = year + (-year + 1) % 100;
	const centuryStartDate = /* @__PURE__ */ new Date();
	centuryStartDate.setFullYear(centuryStartYear, 0, 1);
	centuryStartDate.setHours(0, 0, 0, 0);
	return centuryStartDate;
}
/**
* Gets previous century start date from a given date.
*
* @param {DateLike} date Date to get previous century start from
* @param {number} [offset=-100] Offset in years to calculate previous century start from
* @returns {Date} Previous century start date
*/
var getPreviousCenturyStart = makeGetEdgeOfNeighbor(getYear, getCenturyStart, -100);
/**
* Gets next century start date from a given date.
*
* @param {DateLike} date Date to get next century start from
* @param {number} [offset=100] Offset in years to calculate next century start from
* @returns {Date} Next century start date
*/
var getNextCenturyStart = makeGetEdgeOfNeighbor(getYear, getCenturyStart, 100);
/**
* Gets century end date from a given date.
*
* @param {DateLike} date Date to get century end from
* @returns {Date} Century end date
*/
var getCenturyEnd = makeGetEnd(getNextCenturyStart);
/**
* Gets previous century end date from a given date.
*
* @param {DateLike} date Date to get previous century end from
* @param {number} [offset=-100] Offset in years to calculate previous century end from
* @returns {Date} Previous century end date
*/
var getPreviousCenturyEnd = makeGetEdgeOfNeighbor(getYear, getCenturyEnd, -100);
/**
* Gets century start and end dates from a given date.
*
* @param {DateLike} date Date to get century start and end from
* @returns {[Date, Date]} Century start and end dates
*/
var getCenturyRange = makeGetRange(getCenturyStart, getCenturyEnd);
/**
* Decade
*/
/**
* Gets decade start date from a given date.
*
* @param {DateLike} date Date to get decade start from
* @returns {Date} Decade start date
*/
function getDecadeStart(date) {
	const year = getYear(date);
	const decadeStartYear = year + (-year + 1) % 10;
	const decadeStartDate = /* @__PURE__ */ new Date();
	decadeStartDate.setFullYear(decadeStartYear, 0, 1);
	decadeStartDate.setHours(0, 0, 0, 0);
	return decadeStartDate;
}
/**
* Gets previous decade start date from a given date.
*
* @param {DateLike} date Date to get previous decade start from
* @param {number} [offset=-10] Offset in years to calculate previous decade start from
* @returns {Date} Previous decade start date
*/
var getPreviousDecadeStart = makeGetEdgeOfNeighbor(getYear, getDecadeStart, -10);
/**
* Gets next decade start date from a given date.
*
* @param {DateLike} date Date to get next decade start from
* @param {number} [offset=10] Offset in years to calculate next decade start from
* @returns {Date} Next decade start date
*/
var getNextDecadeStart = makeGetEdgeOfNeighbor(getYear, getDecadeStart, 10);
/**
* Gets decade end date from a given date.
*
* @param {DateLike} date Date to get decade end from
* @returns {Date} Decade end date
*/
var getDecadeEnd = makeGetEnd(getNextDecadeStart);
/**
* Gets previous decade end date from a given date.
*
* @param {DateLike} date Date to get previous decade end from
* @param {number} [offset=-10] Offset in years to calculate previous decade end from
* @returns {Date} Previous decade end date
*/
var getPreviousDecadeEnd = makeGetEdgeOfNeighbor(getYear, getDecadeEnd, -10);
/**
* Gets decade start and end dates from a given date.
*
* @param {DateLike} date Date to get decade start and end from
* @returns {[Date, Date]} Decade start and end dates
*/
var getDecadeRange = makeGetRange(getDecadeStart, getDecadeEnd);
/**
* Year
*/
/**
* Gets year start date from a given date.
*
* @param {DateLike} date Date to get year start from
* @returns {Date} Year start date
*/
function getYearStart(date) {
	const year = getYear(date);
	const yearStartDate = /* @__PURE__ */ new Date();
	yearStartDate.setFullYear(year, 0, 1);
	yearStartDate.setHours(0, 0, 0, 0);
	return yearStartDate;
}
/**
* Gets previous year start date from a given date.
*
* @param {DateLike} date Date to get previous year start from
* @param {number} [offset=-1] Offset in years to calculate previous year start from
* @returns {Date} Previous year start date
*/
var getPreviousYearStart = makeGetEdgeOfNeighbor(getYear, getYearStart, -1);
/**
* Gets next year start date from a given date.
*
* @param {DateLike} date Date to get next year start from
* @param {number} [offset=1] Offset in years to calculate next year start from
* @returns {Date} Next year start date
*/
var getNextYearStart = makeGetEdgeOfNeighbor(getYear, getYearStart, 1);
/**
* Gets year end date from a given date.
*
* @param {DateLike} date Date to get year end from
* @returns {Date} Year end date
*/
var getYearEnd = makeGetEnd(getNextYearStart);
/**
* Gets previous year end date from a given date.
*
* @param {DateLike} date Date to get previous year end from
* @param {number} [offset=-1] Offset in years to calculate previous year end from
* @returns {Date} Previous year end date
*/
var getPreviousYearEnd = makeGetEdgeOfNeighbor(getYear, getYearEnd, -1);
/**
* Gets year start and end dates from a given date.
*
* @param {DateLike} date Date to get year start and end from
* @returns {[Date, Date]} Year start and end dates
*/
var getYearRange = makeGetRange(getYearStart, getYearEnd);
/**
* Month
*/
function makeGetEdgeOfNeighborMonth(getEdgeOfPeriod, defaultOffset) {
	return function makeGetEdgeOfNeighborMonthInternal(date, offset = defaultOffset) {
		const year = getYear(date);
		const month = getMonth(date) + offset;
		const previousPeriod = /* @__PURE__ */ new Date();
		previousPeriod.setFullYear(year, month, 1);
		previousPeriod.setHours(0, 0, 0, 0);
		return getEdgeOfPeriod(previousPeriod);
	};
}
/**
* Gets month start date from a given date.
*
* @param {DateLike} date Date to get month start from
* @returns {Date} Month start date
*/
function getMonthStart(date) {
	const year = getYear(date);
	const month = getMonth(date);
	const monthStartDate = /* @__PURE__ */ new Date();
	monthStartDate.setFullYear(year, month, 1);
	monthStartDate.setHours(0, 0, 0, 0);
	return monthStartDate;
}
/**
* Gets previous month start date from a given date.
*
* @param {Date} date Date to get previous month start from
* @param {number} [offset=-1] Offset in months to calculate previous month start from
* @returns {Date} Previous month start date
*/
var getPreviousMonthStart = makeGetEdgeOfNeighborMonth(getMonthStart, -1);
/**
* Gets next month start date from a given date.
*
* @param {Date} date Date to get next month start from
* @param {number} [offset=1] Offset in months to calculate next month start from
* @returns {Date} Next month start date
*/
var getNextMonthStart = makeGetEdgeOfNeighborMonth(getMonthStart, 1);
/**
* Gets month end date from a given date.
*
* @param {Date} date Date to get month end from
* @returns {Date} Month end date
*/
var getMonthEnd = makeGetEnd(getNextMonthStart);
/**
* Gets previous month end date from a given date.
*
* @param {Date} date Date to get previous month end from
* @param {number} [offset=-1] Offset in months to calculate previous month end from
* @returns {Date} Previous month end date
*/
var getPreviousMonthEnd = makeGetEdgeOfNeighborMonth(getMonthEnd, -1);
/**
* Gets month start and end dates from a given date.
*
* @param {Date} date Date to get month start and end from
* @returns {[Date, Date]} Month start and end dates
*/
var getMonthRange = makeGetRange(getMonthStart, getMonthEnd);
/**
* Day
*/
function makeGetEdgeOfNeighborDay(getEdgeOfPeriod, defaultOffset) {
	return function makeGetEdgeOfNeighborDayInternal(date, offset = defaultOffset) {
		const year = getYear(date);
		const month = getMonth(date);
		const day = getDate(date) + offset;
		const previousPeriod = /* @__PURE__ */ new Date();
		previousPeriod.setFullYear(year, month, day);
		previousPeriod.setHours(0, 0, 0, 0);
		return getEdgeOfPeriod(previousPeriod);
	};
}
/**
* Gets day start date from a given date.
*
* @param {DateLike} date Date to get day start from
* @returns {Date} Day start date
*/
function getDayStart(date) {
	const year = getYear(date);
	const month = getMonth(date);
	const day = getDate(date);
	const dayStartDate = /* @__PURE__ */ new Date();
	dayStartDate.setFullYear(year, month, day);
	dayStartDate.setHours(0, 0, 0, 0);
	return dayStartDate;
}
/**
* Gets day end date from a given date.
*
* @param {Date} date Date to get day end from
* @returns {Date} Day end date
*/
var getDayEnd = makeGetEnd(makeGetEdgeOfNeighborDay(getDayStart, 1));
/**
* Gets day start and end dates from a given date.
*
* @param {DateLike} date Date to get day start and end from
* @returns {[Date, Date]} Day start and end dates
*/
var getDayRange = makeGetRange(getDayStart, getDayEnd);
/**
* Other
*/
/**
* Returns a number of days in a month of a given date.
*
* @param {Date} date Date
* @returns {number} Number of days in a month
*/
function getDaysInMonth(date) {
	return getDate(getMonthEnd(date));
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/shared/const.js
var CALENDAR_TYPES = {
	GREGORY: "gregory",
	HEBREW: "hebrew",
	ISLAMIC: "islamic",
	ISO_8601: "iso8601"
};
var CALENDAR_TYPE_LOCALES = {
	gregory: [
		"en-CA",
		"en-US",
		"es-AR",
		"es-BO",
		"es-CL",
		"es-CO",
		"es-CR",
		"es-DO",
		"es-EC",
		"es-GT",
		"es-HN",
		"es-MX",
		"es-NI",
		"es-PA",
		"es-PE",
		"es-PR",
		"es-SV",
		"es-VE",
		"pt-BR"
	],
	hebrew: ["he", "he-IL"],
	islamic: [
		"ar",
		"ar-AE",
		"ar-BH",
		"ar-DZ",
		"ar-EG",
		"ar-IQ",
		"ar-JO",
		"ar-KW",
		"ar-LY",
		"ar-OM",
		"ar-QA",
		"ar-SA",
		"ar-SD",
		"ar-SY",
		"ar-YE",
		"dv",
		"dv-MV",
		"ps",
		"ps-AR"
	]
};
var WEEKDAYS = [
	0,
	1,
	2,
	3,
	4,
	5,
	6
];
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/shared/dates.js
var SUNDAY = WEEKDAYS[0];
var FRIDAY = WEEKDAYS[5];
var SATURDAY = WEEKDAYS[6];
/**
* Gets day of the week of a given date.
* @param {Date} date Date.
* @param {CalendarType} [calendarType="iso8601"] Calendar type.
* @returns {number} Day of the week.
*/
function getDayOfWeek(date, calendarType = CALENDAR_TYPES.ISO_8601) {
	const weekday = date.getDay();
	switch (calendarType) {
		case CALENDAR_TYPES.ISO_8601: return (weekday + 6) % 7;
		case CALENDAR_TYPES.ISLAMIC: return (weekday + 1) % 7;
		case CALENDAR_TYPES.HEBREW:
		case CALENDAR_TYPES.GREGORY: return weekday;
		default: throw new Error("Unsupported calendar type.");
	}
}
/**
* Century
*/
/**
* Gets the year of the beginning of a century of a given date.
* @param {Date} date Date.
* @returns {number} Year of the beginning of a century.
*/
function getBeginOfCenturyYear(date) {
	return getYear(getCenturyStart(date));
}
/**
* Decade
*/
/**
* Gets the year of the beginning of a decade of a given date.
* @param {Date} date Date.
* @returns {number} Year of the beginning of a decade.
*/
function getBeginOfDecadeYear(date) {
	return getYear(getDecadeStart(date));
}
/**
* Week
*/
/**
* Returns the beginning of a given week.
*
* @param {Date} date Date.
* @param {CalendarType} [calendarType="iso8601"] Calendar type.
* @returns {Date} Beginning of a given week.
*/
function getBeginOfWeek(date, calendarType = CALENDAR_TYPES.ISO_8601) {
	const year = getYear(date);
	const monthIndex = getMonth(date);
	const day = date.getDate() - getDayOfWeek(date, calendarType);
	return new Date(year, monthIndex, day);
}
/**
* Gets week number according to ISO 8601 or US standard.
* In ISO 8601, Arabic and Hebrew week 1 is the one with January 4.
* In US calendar week 1 is the one with January 1.
*
* @param {Date} date Date.
* @param {CalendarType} [calendarType="iso8601"] Calendar type.
* @returns {number} Week number.
*/
function getWeekNumber(date, calendarType = CALENDAR_TYPES.ISO_8601) {
	const calendarTypeForWeekNumber = calendarType === CALENDAR_TYPES.GREGORY ? CALENDAR_TYPES.GREGORY : CALENDAR_TYPES.ISO_8601;
	const beginOfWeek = getBeginOfWeek(date, calendarType);
	let year = getYear(date) + 1;
	let dayInWeekOne;
	let beginOfFirstWeek;
	do {
		dayInWeekOne = new Date(year, 0, calendarTypeForWeekNumber === CALENDAR_TYPES.ISO_8601 ? 4 : 1);
		beginOfFirstWeek = getBeginOfWeek(dayInWeekOne, calendarType);
		year -= 1;
	} while (date < beginOfFirstWeek);
	return Math.round((beginOfWeek.getTime() - beginOfFirstWeek.getTime()) / 6048e5) + 1;
}
/**
* Others
*/
/**
* Returns the beginning of a given range.
*
* @param {RangeType} rangeType Range type (e.g. 'day')
* @param {Date} date Date.
* @returns {Date} Beginning of a given range.
*/
function getBegin(rangeType, date) {
	switch (rangeType) {
		case "century": return getCenturyStart(date);
		case "decade": return getDecadeStart(date);
		case "year": return getYearStart(date);
		case "month": return getMonthStart(date);
		case "day": return getDayStart(date);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
/**
* Returns the beginning of a previous given range.
*
* @param {RangeType} rangeType Range type (e.g. 'day')
* @param {Date} date Date.
* @returns {Date} Beginning of a previous given range.
*/
function getBeginPrevious(rangeType, date) {
	switch (rangeType) {
		case "century": return getPreviousCenturyStart(date);
		case "decade": return getPreviousDecadeStart(date);
		case "year": return getPreviousYearStart(date);
		case "month": return getPreviousMonthStart(date);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
/**
* Returns the beginning of a next given range.
*
* @param {RangeType} rangeType Range type (e.g. 'day')
* @param {Date} date Date.
* @returns {Date} Beginning of a next given range.
*/
function getBeginNext(rangeType, date) {
	switch (rangeType) {
		case "century": return getNextCenturyStart(date);
		case "decade": return getNextDecadeStart(date);
		case "year": return getNextYearStart(date);
		case "month": return getNextMonthStart(date);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
function getBeginPrevious2(rangeType, date) {
	switch (rangeType) {
		case "decade": return getPreviousDecadeStart(date, -100);
		case "year": return getPreviousYearStart(date, -10);
		case "month": return getPreviousMonthStart(date, -12);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
function getBeginNext2(rangeType, date) {
	switch (rangeType) {
		case "decade": return getNextDecadeStart(date, 100);
		case "year": return getNextYearStart(date, 10);
		case "month": return getNextMonthStart(date, 12);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
/**
* Returns the end of a given range.
*
* @param {RangeType} rangeType Range type (e.g. 'day')
* @param {Date} date Date.
* @returns {Date} End of a given range.
*/
function getEnd(rangeType, date) {
	switch (rangeType) {
		case "century": return getCenturyEnd(date);
		case "decade": return getDecadeEnd(date);
		case "year": return getYearEnd(date);
		case "month": return getMonthEnd(date);
		case "day": return getDayEnd(date);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
/**
* Returns the end of a previous given range.
*
* @param {RangeType} rangeType Range type (e.g. 'day')
* @param {Date} date Date.
* @returns {Date} End of a previous given range.
*/
function getEndPrevious(rangeType, date) {
	switch (rangeType) {
		case "century": return getPreviousCenturyEnd(date);
		case "decade": return getPreviousDecadeEnd(date);
		case "year": return getPreviousYearEnd(date);
		case "month": return getPreviousMonthEnd(date);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
function getEndPrevious2(rangeType, date) {
	switch (rangeType) {
		case "decade": return getPreviousDecadeEnd(date, -100);
		case "year": return getPreviousYearEnd(date, -10);
		case "month": return getPreviousMonthEnd(date, -12);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
/**
* Returns an array with the beginning and the end of a given range.
*
* @param {RangeType} rangeType Range type (e.g. 'day')
* @param {Date} date Date.
* @returns {Date[]} Beginning and end of a given range.
*/
function getRange(rangeType, date) {
	switch (rangeType) {
		case "century": return getCenturyRange(date);
		case "decade": return getDecadeRange(date);
		case "year": return getYearRange(date);
		case "month": return getMonthRange(date);
		case "day": return getDayRange(date);
		default: throw new Error(`Invalid rangeType: ${rangeType}`);
	}
}
/**
* Creates a range out of two values, ensuring they are in order and covering entire period ranges.
*
* @param {RangeType} rangeType Range type (e.g. 'day')
* @param {Date} date1 First date.
* @param {Date} date2 Second date.
* @returns {Date[]} Beginning and end of a given range.
*/
function getValueRange(rangeType, date1, date2) {
	const rawNextValue = [date1, date2].sort((a, b) => a.getTime() - b.getTime());
	return [getBegin(rangeType, rawNextValue[0]), getEnd(rangeType, rawNextValue[1])];
}
function toYearLabel(locale, formatYear$4, dates) {
	return dates.map((date) => (formatYear$4 || formatYear)(locale, date)).join(" – ");
}
/**
* @callback FormatYear
* @param {string} locale Locale.
* @param {Date} date Date.
* @returns {string} Formatted year.
*/
/**
* Returns a string labelling a century of a given date.
* For example, for 2017 it will return 2001-2100.
*
* @param {string} locale Locale.
* @param {FormatYear} formatYear Function to format a year.
* @param {Date|string|number} date Date or a year as a string or as a number.
* @returns {string} String labelling a century of a given date.
*/
function getCenturyLabel(locale, formatYear, date) {
	return toYearLabel(locale, formatYear, getCenturyRange(date));
}
/**
* Returns a string labelling a decade of a given date.
* For example, for 2017 it will return 2011-2020.
*
* @param {string} locale Locale.
* @param {FormatYear} formatYear Function to format a year.
* @param {Date|string|number} date Date or a year as a string or as a number.
* @returns {string} String labelling a decade of a given date.
*/
function getDecadeLabel(locale, formatYear, date) {
	return toYearLabel(locale, formatYear, getDecadeRange(date));
}
/**
* Returns a boolean determining whether a given date is the current day of the week.
*
* @param {Date} date Date.
* @returns {boolean} Whether a given date is the current day of the week.
*/
function isCurrentDayOfWeek(date) {
	return date.getDay() === (/* @__PURE__ */ new Date()).getDay();
}
/**
* Returns a boolean determining whether a given date is a weekend day.
*
* @param {Date} date Date.
* @param {CalendarType} [calendarType="iso8601"] Calendar type.
* @returns {boolean} Whether a given date is a weekend day.
*/
function isWeekend(date, calendarType = CALENDAR_TYPES.ISO_8601) {
	const weekday = date.getDay();
	switch (calendarType) {
		case CALENDAR_TYPES.ISLAMIC:
		case CALENDAR_TYPES.HEBREW: return weekday === FRIDAY || weekday === SATURDAY;
		case CALENDAR_TYPES.ISO_8601:
		case CALENDAR_TYPES.GREGORY: return weekday === SATURDAY || weekday === SUNDAY;
		default: throw new Error("Unsupported calendar type.");
	}
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/Calendar/Navigation.js
var className$6 = "react-calendar__navigation";
function Navigation({ activeStartDate, drillUp, formatMonthYear: formatMonthYear$2 = formatMonthYear, formatYear: formatYear$3 = formatYear, locale, maxDate, minDate, navigationAriaLabel = "", navigationAriaLive, navigationLabel, next2AriaLabel = "", next2Label = "»", nextAriaLabel = "", nextLabel = "›", prev2AriaLabel = "", prev2Label = "«", prevAriaLabel = "", prevLabel = "‹", setActiveStartDate, showDoubleView, view, views }) {
	const drillUpAvailable = views.indexOf(view) > 0;
	const shouldShowPrevNext2Buttons = view !== "century";
	const previousActiveStartDate = getBeginPrevious(view, activeStartDate);
	const previousActiveStartDate2 = shouldShowPrevNext2Buttons ? getBeginPrevious2(view, activeStartDate) : void 0;
	const nextActiveStartDate = getBeginNext(view, activeStartDate);
	const nextActiveStartDate2 = shouldShowPrevNext2Buttons ? getBeginNext2(view, activeStartDate) : void 0;
	const prevButtonDisabled = (() => {
		if (previousActiveStartDate.getFullYear() < 0) return true;
		const previousActiveEndDate = getEndPrevious(view, activeStartDate);
		return minDate && minDate >= previousActiveEndDate;
	})();
	const prev2ButtonDisabled = shouldShowPrevNext2Buttons && (() => {
		if (previousActiveStartDate2.getFullYear() < 0) return true;
		const previousActiveEndDate = getEndPrevious2(view, activeStartDate);
		return minDate && minDate >= previousActiveEndDate;
	})();
	const nextButtonDisabled = maxDate && maxDate < nextActiveStartDate;
	const next2ButtonDisabled = shouldShowPrevNext2Buttons && maxDate && maxDate < nextActiveStartDate2;
	function onClickPrevious() {
		setActiveStartDate(previousActiveStartDate, "prev");
	}
	function onClickPrevious2() {
		setActiveStartDate(previousActiveStartDate2, "prev2");
	}
	function onClickNext() {
		setActiveStartDate(nextActiveStartDate, "next");
	}
	function onClickNext2() {
		setActiveStartDate(nextActiveStartDate2, "next2");
	}
	function renderLabel(date) {
		const label = (() => {
			switch (view) {
				case "century": return getCenturyLabel(locale, formatYear$3, date);
				case "decade": return getDecadeLabel(locale, formatYear$3, date);
				case "year": return formatYear$3(locale, date);
				case "month": return formatMonthYear$2(locale, date);
				default: throw new Error(`Invalid view: ${view}.`);
			}
		})();
		return navigationLabel ? navigationLabel({
			date,
			label,
			locale: locale || getUserLocale() || void 0,
			view
		}) : label;
	}
	function renderButton() {
		const labelClassName = `${className$6}__label`;
		return (0, import_jsx_runtime.jsxs)("button", {
			"aria-label": navigationAriaLabel,
			"aria-live": navigationAriaLive,
			className: labelClassName,
			disabled: !drillUpAvailable,
			onClick: drillUp,
			style: { flexGrow: 1 },
			type: "button",
			children: [(0, import_jsx_runtime.jsx)("span", {
				className: `${labelClassName}__labelText ${labelClassName}__labelText--from`,
				children: renderLabel(activeStartDate)
			}), showDoubleView ? (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [(0, import_jsx_runtime.jsx)("span", {
				className: `${labelClassName}__divider`,
				children: " – "
			}), (0, import_jsx_runtime.jsx)("span", {
				className: `${labelClassName}__labelText ${labelClassName}__labelText--to`,
				children: renderLabel(nextActiveStartDate)
			})] }) : null]
		});
	}
	return (0, import_jsx_runtime.jsxs)("div", {
		className: className$6,
		children: [
			prev2Label !== null && shouldShowPrevNext2Buttons ? (0, import_jsx_runtime.jsx)("button", {
				"aria-label": prev2AriaLabel,
				className: `${className$6}__arrow ${className$6}__prev2-button`,
				disabled: prev2ButtonDisabled,
				onClick: onClickPrevious2,
				type: "button",
				children: prev2Label
			}) : null,
			prevLabel !== null && (0, import_jsx_runtime.jsx)("button", {
				"aria-label": prevAriaLabel,
				className: `${className$6}__arrow ${className$6}__prev-button`,
				disabled: prevButtonDisabled,
				onClick: onClickPrevious,
				type: "button",
				children: prevLabel
			}),
			renderButton(),
			nextLabel !== null && (0, import_jsx_runtime.jsx)("button", {
				"aria-label": nextAriaLabel,
				className: `${className$6}__arrow ${className$6}__next-button`,
				disabled: nextButtonDisabled,
				onClick: onClickNext,
				type: "button",
				children: nextLabel
			}),
			next2Label !== null && shouldShowPrevNext2Buttons ? (0, import_jsx_runtime.jsx)("button", {
				"aria-label": next2AriaLabel,
				className: `${className$6}__arrow ${className$6}__next2-button`,
				disabled: next2ButtonDisabled,
				onClick: onClickNext2,
				type: "button",
				children: next2Label
			}) : null
		]
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/Flex.js
function toPercent(num) {
	return `${num}%`;
}
function Flex({ children, className, count, direction, offset, style, wrap, ...otherProps }) {
	return (0, import_jsx_runtime.jsx)("div", {
		className,
		style: {
			display: "flex",
			flexDirection: direction,
			flexWrap: wrap ? "wrap" : "nowrap",
			...style
		},
		...otherProps,
		children: import_react.Children.map(children, (child, index) => {
			const marginInlineStart = offset && index === 0 ? toPercent(100 * offset / count) : null;
			return (0, import_react.cloneElement)(child, {
				...child.props,
				style: {
					flexBasis: toPercent(100 / count),
					flexShrink: 0,
					flexGrow: 0,
					overflow: "hidden",
					marginLeft: marginInlineStart,
					marginInlineStart,
					marginInlineEnd: 0
				}
			});
		})
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/shared/utils.js
/**
* Returns a value no smaller than min and no larger than max.
*
* @param {Date} value Value to return.
* @param {Date} min Minimum return value.
* @param {Date} max Maximum return value.
* @returns {Date} Value between min and max.
*/
function between(value, min, max) {
	if (min && min > value) return min;
	if (max && max < value) return max;
	return value;
}
function isValueWithinRange(value, range) {
	return range[0] <= value && range[1] >= value;
}
function isRangeWithinRange(greaterRange, smallerRange) {
	return greaterRange[0] <= smallerRange[0] && greaterRange[1] >= smallerRange[1];
}
function doRangesOverlap(range1, range2) {
	return isValueWithinRange(range1[0], range2) || isValueWithinRange(range1[1], range2);
}
function getRangeClassNames(valueRange, dateRange, baseClassName) {
	const isRange = doRangesOverlap(dateRange, valueRange);
	const classes = [];
	if (isRange) {
		classes.push(baseClassName);
		const isRangeStart = isValueWithinRange(valueRange[0], dateRange);
		const isRangeEnd = isValueWithinRange(valueRange[1], dateRange);
		if (isRangeStart) classes.push(`${baseClassName}Start`);
		if (isRangeEnd) classes.push(`${baseClassName}End`);
		if (isRangeStart && isRangeEnd) classes.push(`${baseClassName}BothEnds`);
	}
	return classes;
}
function isCompleteValue(value) {
	if (Array.isArray(value)) return value[0] !== null && value[1] !== null;
	return value !== null;
}
function getTileClasses(args) {
	if (!args) throw new Error("args is required");
	const { value, date, hover } = args;
	const className = "react-calendar__tile";
	const classes = [className];
	if (!date) return classes;
	const now = /* @__PURE__ */ new Date();
	const dateRange = (() => {
		if (Array.isArray(date)) return date;
		const { dateType } = args;
		if (!dateType) throw new Error("dateType is required when date is not an array of two dates");
		return getRange(dateType, date);
	})();
	if (isValueWithinRange(now, dateRange)) classes.push(`${className}--now`);
	if (!value || !isCompleteValue(value)) return classes;
	const valueRange = (() => {
		if (Array.isArray(value)) return value;
		const { valueType } = args;
		if (!valueType) throw new Error("valueType is required when value is not an array of two dates");
		return getRange(valueType, value);
	})();
	if (isRangeWithinRange(valueRange, dateRange)) classes.push(`${className}--active`);
	else if (doRangesOverlap(valueRange, dateRange)) classes.push(`${className}--hasActive`);
	const valueRangeClassNames = getRangeClassNames(valueRange, dateRange, `${className}--range`);
	classes.push(...valueRangeClassNames);
	if (hover && (Array.isArray(value) ? value : [value]).length === 1) {
		const hoverRangeClassNames = getRangeClassNames(hover > valueRange[0] ? [valueRange[0], hover] : [hover, valueRange[0]], dateRange, `${className}--hover`);
		classes.push(...hoverRangeClassNames);
	}
	return classes;
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/TileGroup.js
function TileGroup({ className, count = 3, dateTransform, dateType, end, hover, offset, renderTile, start, step = 1, value, valueType }) {
	const tiles = [];
	for (let point = start; point <= end; point += step) {
		const date = dateTransform(point);
		tiles.push(renderTile({
			classes: getTileClasses({
				date,
				dateType,
				hover,
				value,
				valueType
			}),
			date
		}));
	}
	return (0, import_jsx_runtime.jsx)(Flex, {
		className,
		count,
		offset,
		wrap: true,
		children: tiles
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/Tile.js
function Tile(props) {
	const { activeStartDate, children, classes, date, formatAbbr, locale, maxDate, maxDateTransform, minDate, minDateTransform, onClick, onMouseOver, style, tileClassName: tileClassNameProps, tileContent: tileContentProps, tileDisabled, view } = props;
	const tileClassName = (0, import_react.useMemo)(() => {
		return typeof tileClassNameProps === "function" ? tileClassNameProps({
			activeStartDate,
			date,
			view
		}) : tileClassNameProps;
	}, [
		activeStartDate,
		date,
		tileClassNameProps,
		view
	]);
	const tileContent = (0, import_react.useMemo)(() => {
		return typeof tileContentProps === "function" ? tileContentProps({
			activeStartDate,
			date,
			view
		}) : tileContentProps;
	}, [
		activeStartDate,
		date,
		tileContentProps,
		view
	]);
	return (0, import_jsx_runtime.jsxs)("button", {
		className: clsx(classes, tileClassName),
		disabled: minDate && minDateTransform(minDate) > date || maxDate && maxDateTransform(maxDate) < date || (tileDisabled === null || tileDisabled === void 0 ? void 0 : tileDisabled({
			activeStartDate,
			date,
			view
		})),
		onClick: onClick ? (event) => onClick(date, event) : void 0,
		onFocus: onMouseOver ? () => onMouseOver(date) : void 0,
		onMouseOver: onMouseOver ? () => onMouseOver(date) : void 0,
		style,
		type: "button",
		children: [formatAbbr ? (0, import_jsx_runtime.jsx)("abbr", {
			"aria-label": formatAbbr(locale, date),
			children
		}) : children, tileContent]
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/CenturyView/Decade.js
var className$5 = "react-calendar__century-view__decades__decade";
function Decade({ classes = [], currentCentury, formatYear: formatYear$2 = formatYear, ...otherProps }) {
	const { date, locale } = otherProps;
	const classesProps = [];
	if (classes) classesProps.push(...classes);
	classesProps.push(className$5);
	if (getCenturyStart(date).getFullYear() !== currentCentury) classesProps.push(`${className$5}--neighboringCentury`);
	return (0, import_jsx_runtime.jsx)(Tile, {
		...otherProps,
		classes: classesProps,
		maxDateTransform: getDecadeEnd,
		minDateTransform: getDecadeStart,
		view: "century",
		children: getDecadeLabel(locale, formatYear$2, date)
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/CenturyView/Decades.js
function Decades(props) {
	const { activeStartDate, hover, showNeighboringCentury, value, valueType, ...otherProps } = props;
	const start = getBeginOfCenturyYear(activeStartDate);
	const end = start + (showNeighboringCentury ? 119 : 99);
	return (0, import_jsx_runtime.jsx)(TileGroup, {
		className: "react-calendar__century-view__decades",
		dateTransform: getDecadeStart,
		dateType: "decade",
		end,
		hover,
		renderTile: ({ date, ...otherTileProps }) => (0, import_jsx_runtime.jsx)(Decade, {
			...otherProps,
			...otherTileProps,
			activeStartDate,
			currentCentury: start,
			date
		}, date.getTime()),
		start,
		step: 10,
		value,
		valueType
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/CenturyView.js
/**
* Displays a given century.
*/
function CenturyView(props) {
	function renderDecades() {
		return (0, import_jsx_runtime.jsx)(Decades, { ...props });
	}
	return (0, import_jsx_runtime.jsx)("div", {
		className: "react-calendar__century-view",
		children: renderDecades()
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/DecadeView/Year.js
var className$4 = "react-calendar__decade-view__years__year";
function Year({ classes = [], currentDecade, formatYear: formatYear$1 = formatYear, ...otherProps }) {
	const { date, locale } = otherProps;
	const classesProps = [];
	if (classes) classesProps.push(...classes);
	classesProps.push(className$4);
	if (getDecadeStart(date).getFullYear() !== currentDecade) classesProps.push(`${className$4}--neighboringDecade`);
	return (0, import_jsx_runtime.jsx)(Tile, {
		...otherProps,
		classes: classesProps,
		maxDateTransform: getYearEnd,
		minDateTransform: getYearStart,
		view: "decade",
		children: formatYear$1(locale, date)
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/DecadeView/Years.js
function Years(props) {
	const { activeStartDate, hover, showNeighboringDecade, value, valueType, ...otherProps } = props;
	const start = getBeginOfDecadeYear(activeStartDate);
	const end = start + (showNeighboringDecade ? 11 : 9);
	return (0, import_jsx_runtime.jsx)(TileGroup, {
		className: "react-calendar__decade-view__years",
		dateTransform: getYearStart,
		dateType: "year",
		end,
		hover,
		renderTile: ({ date, ...otherTileProps }) => (0, import_jsx_runtime.jsx)(Year, {
			...otherProps,
			...otherTileProps,
			activeStartDate,
			currentDecade: start,
			date
		}, date.getTime()),
		start,
		value,
		valueType
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/DecadeView.js
/**
* Displays a given decade.
*/
function DecadeView(props) {
	function renderYears() {
		return (0, import_jsx_runtime.jsx)(Years, { ...props });
	}
	return (0, import_jsx_runtime.jsx)("div", {
		className: "react-calendar__decade-view",
		children: renderYears()
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/MonthView/Day.js
var className$3 = "react-calendar__month-view__days__day";
function Day({ calendarType, classes = [], currentMonthIndex, formatDay: formatDay$1 = formatDay, formatLongDate: formatLongDate$1 = formatLongDate, ...otherProps }) {
	const { date, locale } = otherProps;
	const classesProps = [];
	if (classes) classesProps.push(...classes);
	classesProps.push(className$3);
	if (isWeekend(date, calendarType)) classesProps.push(`${className$3}--weekend`);
	if (date.getMonth() !== currentMonthIndex) classesProps.push(`${className$3}--neighboringMonth`);
	return (0, import_jsx_runtime.jsx)(Tile, {
		...otherProps,
		classes: classesProps,
		formatAbbr: formatLongDate$1,
		maxDateTransform: getDayEnd,
		minDateTransform: getDayStart,
		view: "month",
		children: formatDay$1(locale, date)
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/MonthView/Days.js
function Days(props) {
	const { activeStartDate, calendarType, hover, showFixedNumberOfWeeks, showNeighboringMonth, value, valueType, ...otherProps } = props;
	const year = getYear(activeStartDate);
	const monthIndex = getMonth(activeStartDate);
	const hasFixedNumberOfWeeks = showFixedNumberOfWeeks || showNeighboringMonth;
	const dayOfWeek = getDayOfWeek(activeStartDate, calendarType);
	const offset = hasFixedNumberOfWeeks ? 0 : dayOfWeek;
	/**
	* Defines on which day of the month the grid shall start. If we simply show current
	* month, we obviously start on day one, but if showNeighboringMonth is set to
	* true, we need to find the beginning of the week the first day of the month is in.
	*/
	const start = (hasFixedNumberOfWeeks ? -dayOfWeek : 0) + 1;
	/**
	* Defines on which day of the month the grid shall end. If we simply show current
	* month, we need to stop on the last day of the month, but if showNeighboringMonth
	* is set to true, we need to find the end of the week the last day of the month is in.
	*/
	const end = (() => {
		if (showFixedNumberOfWeeks) return start + 42 - 1;
		const daysInMonth = getDaysInMonth(activeStartDate);
		if (showNeighboringMonth) {
			const activeEndDate = /* @__PURE__ */ new Date();
			activeEndDate.setFullYear(year, monthIndex, daysInMonth);
			activeEndDate.setHours(0, 0, 0, 0);
			return daysInMonth + (7 - getDayOfWeek(activeEndDate, calendarType) - 1);
		}
		return daysInMonth;
	})();
	return (0, import_jsx_runtime.jsx)(TileGroup, {
		className: "react-calendar__month-view__days",
		count: 7,
		dateTransform: (day) => {
			const date = /* @__PURE__ */ new Date();
			date.setFullYear(year, monthIndex, day);
			return getDayStart(date);
		},
		dateType: "day",
		hover,
		end,
		renderTile: ({ date, ...otherTileProps }) => (0, import_jsx_runtime.jsx)(Day, {
			...otherProps,
			...otherTileProps,
			activeStartDate,
			calendarType,
			currentMonthIndex: monthIndex,
			date
		}, date.getTime()),
		offset,
		start,
		value,
		valueType
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/MonthView/Weekdays.js
var className$2 = "react-calendar__month-view__weekdays";
var weekdayClassName = `${className$2}__weekday`;
function Weekdays(props) {
	const { calendarType, formatShortWeekday: formatShortWeekday$1 = formatShortWeekday, formatWeekday: formatWeekday$1 = formatWeekday, locale, onMouseLeave } = props;
	const beginOfMonth = getMonthStart(/* @__PURE__ */ new Date());
	const year = getYear(beginOfMonth);
	const monthIndex = getMonth(beginOfMonth);
	const weekdays = [];
	for (let weekday = 1; weekday <= 7; weekday += 1) {
		const weekdayDate = new Date(year, monthIndex, weekday - getDayOfWeek(beginOfMonth, calendarType));
		const abbr = formatWeekday$1(locale, weekdayDate);
		weekdays.push((0, import_jsx_runtime.jsx)("div", {
			className: clsx(weekdayClassName, isCurrentDayOfWeek(weekdayDate) && `${weekdayClassName}--current`, isWeekend(weekdayDate, calendarType) && `${weekdayClassName}--weekend`),
			children: (0, import_jsx_runtime.jsx)("abbr", {
				"aria-label": abbr,
				title: abbr,
				children: formatShortWeekday$1(locale, weekdayDate).replace(".", "")
			})
		}, weekday));
	}
	return (0, import_jsx_runtime.jsx)(Flex, {
		className: className$2,
		count: 7,
		onFocus: onMouseLeave,
		onMouseOver: onMouseLeave,
		children: weekdays
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/MonthView/WeekNumber.js
var className$1 = "react-calendar__tile";
function WeekNumber(props) {
	const { onClickWeekNumber, weekNumber } = props;
	const children = (0, import_jsx_runtime.jsx)("span", { children: weekNumber });
	if (onClickWeekNumber) {
		const { date, onClickWeekNumber, weekNumber, ...otherProps } = props;
		return (0, import_jsx_runtime.jsx)("button", {
			...otherProps,
			className: className$1,
			onClick: (event) => onClickWeekNumber(weekNumber, date, event),
			type: "button",
			children
		});
	} else {
		const { date, onClickWeekNumber, weekNumber, ...otherProps } = props;
		return (0, import_jsx_runtime.jsx)("div", {
			...otherProps,
			className: className$1,
			children
		});
	}
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/MonthView/WeekNumbers.js
function WeekNumbers(props) {
	const { activeStartDate, calendarType, onClickWeekNumber, onMouseLeave, showFixedNumberOfWeeks } = props;
	const numberOfWeeks = (() => {
		if (showFixedNumberOfWeeks) return 6;
		const days = getDaysInMonth(activeStartDate) - (7 - getDayOfWeek(activeStartDate, calendarType));
		return 1 + Math.ceil(days / 7);
	})();
	const dates = (() => {
		const year = getYear(activeStartDate);
		const monthIndex = getMonth(activeStartDate);
		const day = getDate(activeStartDate);
		const result = [];
		for (let index = 0; index < numberOfWeeks; index += 1) result.push(getBeginOfWeek(new Date(year, monthIndex, day + index * 7), calendarType));
		return result;
	})();
	const weekNumbers = dates.map((date) => getWeekNumber(date, calendarType));
	return (0, import_jsx_runtime.jsx)(Flex, {
		className: "react-calendar__month-view__weekNumbers",
		count: numberOfWeeks,
		direction: "column",
		onFocus: onMouseLeave,
		onMouseOver: onMouseLeave,
		style: {
			flexBasis: "calc(100% * (1 / 8)",
			flexShrink: 0
		},
		children: weekNumbers.map((weekNumber, weekIndex) => {
			const date = dates[weekIndex];
			if (!date) throw new Error("date is not defined");
			return (0, import_jsx_runtime.jsx)(WeekNumber, {
				date,
				onClickWeekNumber,
				weekNumber
			}, weekNumber);
		})
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/MonthView.js
function getCalendarTypeFromLocale(locale) {
	if (locale) {
		for (const [calendarType, locales] of Object.entries(CALENDAR_TYPE_LOCALES)) if (locales.includes(locale)) return calendarType;
	}
	return CALENDAR_TYPES.ISO_8601;
}
/**
* Displays a given month.
*/
function MonthView(props) {
	const { activeStartDate, locale, onMouseLeave, showFixedNumberOfWeeks } = props;
	const { calendarType = getCalendarTypeFromLocale(locale), formatShortWeekday, formatWeekday, onClickWeekNumber, showWeekNumbers, ...childProps } = props;
	function renderWeekdays() {
		return (0, import_jsx_runtime.jsx)(Weekdays, {
			calendarType,
			formatShortWeekday,
			formatWeekday,
			locale,
			onMouseLeave
		});
	}
	function renderWeekNumbers() {
		if (!showWeekNumbers) return null;
		return (0, import_jsx_runtime.jsx)(WeekNumbers, {
			activeStartDate,
			calendarType,
			onClickWeekNumber,
			onMouseLeave,
			showFixedNumberOfWeeks
		});
	}
	function renderDays() {
		return (0, import_jsx_runtime.jsx)(Days, {
			calendarType,
			...childProps
		});
	}
	const className = "react-calendar__month-view";
	return (0, import_jsx_runtime.jsx)("div", {
		className: clsx(className, showWeekNumbers ? `${className}--weekNumbers` : ""),
		children: (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				alignItems: "flex-end"
			},
			children: [renderWeekNumbers(), (0, import_jsx_runtime.jsxs)("div", {
				style: {
					flexGrow: 1,
					width: "100%"
				},
				children: [renderWeekdays(), renderDays()]
			})]
		})
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/YearView/Month.js
var className = "react-calendar__year-view__months__month";
function Month({ classes = [], formatMonth: formatMonth$1 = formatMonth, formatMonthYear: formatMonthYear$1 = formatMonthYear, ...otherProps }) {
	const { date, locale } = otherProps;
	return (0, import_jsx_runtime.jsx)(Tile, {
		...otherProps,
		classes: [...classes, className],
		formatAbbr: formatMonthYear$1,
		maxDateTransform: getMonthEnd,
		minDateTransform: getMonthStart,
		view: "year",
		children: formatMonth$1(locale, date)
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/YearView/Months.js
function Months(props) {
	const { activeStartDate, hover, value, valueType, ...otherProps } = props;
	const start = 0;
	const end = 11;
	const year = getYear(activeStartDate);
	return (0, import_jsx_runtime.jsx)(TileGroup, {
		className: "react-calendar__year-view__months",
		dateTransform: (monthIndex) => {
			const date = /* @__PURE__ */ new Date();
			date.setFullYear(year, monthIndex, 1);
			return getMonthStart(date);
		},
		dateType: "month",
		end,
		hover,
		renderTile: ({ date, ...otherTileProps }) => (0, import_jsx_runtime.jsx)(Month, {
			...otherProps,
			...otherTileProps,
			activeStartDate,
			date
		}, date.getTime()),
		start,
		value,
		valueType
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/YearView.js
/**
* Displays a given year.
*/
function YearView(props) {
	function renderMonths() {
		return (0, import_jsx_runtime.jsx)(Months, { ...props });
	}
	return (0, import_jsx_runtime.jsx)("div", {
		className: "react-calendar__year-view",
		children: renderMonths()
	});
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/Calendar.js
var baseClassName = "react-calendar";
var allViews = [
	"century",
	"decade",
	"year",
	"month"
];
var allValueTypes = [
	"decade",
	"year",
	"month",
	"day"
];
var defaultMinDate = /* @__PURE__ */ new Date();
defaultMinDate.setFullYear(1, 0, 1);
defaultMinDate.setHours(0, 0, 0, 0);
var defaultMaxDate = /* @__PURE__ */ new Date(864e13);
function toDate(value) {
	if (value instanceof Date) return value;
	return new Date(value);
}
/**
* Returns views array with disallowed values cut off.
*/
function getLimitedViews(minDetail, maxDetail) {
	return allViews.slice(allViews.indexOf(minDetail), allViews.indexOf(maxDetail) + 1);
}
/**
* Determines whether a given view is allowed with currently applied settings.
*/
function isViewAllowed(view, minDetail, maxDetail) {
	return getLimitedViews(minDetail, maxDetail).indexOf(view) !== -1;
}
/**
* Gets either provided view if allowed by minDetail and maxDetail, or gets
* the default view if not allowed.
*/
function getView(view, minDetail, maxDetail) {
	if (!view) return maxDetail;
	if (isViewAllowed(view, minDetail, maxDetail)) return view;
	return maxDetail;
}
/**
* Returns value type that can be returned with currently applied settings.
*/
function getValueType(view) {
	return allValueTypes[allViews.indexOf(view)];
}
function getValue(value, index) {
	const rawValue = Array.isArray(value) ? value[index] : value;
	if (!rawValue) return null;
	const valueDate = toDate(rawValue);
	if (Number.isNaN(valueDate.getTime())) throw new Error(`Invalid date: ${value}`);
	return valueDate;
}
function getDetailValue({ value, minDate, maxDate, maxDetail }, index) {
	const valuePiece = getValue(value, index);
	if (!valuePiece) return null;
	const valueType = getValueType(maxDetail);
	return between((() => {
		switch (index) {
			case 0: return getBegin(valueType, valuePiece);
			case 1: return getEnd(valueType, valuePiece);
			default: throw new Error(`Invalid index value: ${index}`);
		}
	})(), minDate, maxDate);
}
var getDetailValueFrom = (args) => getDetailValue(args, 0);
var getDetailValueTo = (args) => getDetailValue(args, 1);
var getDetailValueArray = (args) => [getDetailValueFrom, getDetailValueTo].map((fn) => fn(args));
function getActiveStartDate({ maxDate, maxDetail, minDate, minDetail, value, view }) {
	return getBegin(getView(view, minDetail, maxDetail), getDetailValueFrom({
		value,
		minDate,
		maxDate,
		maxDetail
	}) || /* @__PURE__ */ new Date());
}
function getInitialActiveStartDate({ activeStartDate, defaultActiveStartDate, defaultValue, defaultView, maxDate, maxDetail, minDate, minDetail, value, view }) {
	const rangeType = getView(view, minDetail, maxDetail);
	const valueFrom = activeStartDate || defaultActiveStartDate;
	if (valueFrom) return getBegin(rangeType, valueFrom);
	return getActiveStartDate({
		maxDate,
		maxDetail,
		minDate,
		minDetail,
		value: value || defaultValue,
		view: view || defaultView
	});
}
function getIsSingleValue(value) {
	return value && (!Array.isArray(value) || value.length === 1);
}
function areDatesEqual(date1, date2) {
	return date1 instanceof Date && date2 instanceof Date && date1.getTime() === date2.getTime();
}
//#endregion
//#region ../../node_modules/.pnpm/react-calendar@6.0.1_@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/react-calendar/dist/index.js
var dist_default = (0, import_react.forwardRef)(function Calendar(props, ref) {
	const { activeStartDate: activeStartDateProps, allowPartialRange, calendarType, className, "data-testid": dataTestId, defaultActiveStartDate, defaultValue, defaultView, formatDay, formatLongDate, formatMonth, formatMonthYear, formatShortWeekday, formatWeekday, formatYear, goToRangeStartOnSelect = true, inputRef, locale, maxDate = defaultMaxDate, maxDetail = "month", minDate = defaultMinDate, minDetail = "century", navigationAriaLabel, navigationAriaLive, navigationLabel, next2AriaLabel, next2Label, nextAriaLabel, nextLabel, onActiveStartDateChange, onChange: onChangeProps, onClickDay, onClickDecade, onClickMonth, onClickWeekNumber, onClickYear, onDrillDown, onDrillUp, onViewChange, prev2AriaLabel, prev2Label, prevAriaLabel, prevLabel, returnValue = "start", selectRange, showDoubleView, showFixedNumberOfWeeks, showNavigation = true, showNeighboringCentury, showNeighboringDecade, showNeighboringMonth = true, showWeekNumbers, tileClassName, tileContent, tileDisabled, value: valueProps, view: viewProps } = props;
	const [activeStartDateState, setActiveStartDateState] = (0, import_react.useState)(defaultActiveStartDate);
	const [hoverState, setHoverState] = (0, import_react.useState)(null);
	const [valueState, setValueState] = (0, import_react.useState)(Array.isArray(defaultValue) ? defaultValue.map((el) => el !== null ? toDate(el) : null) : defaultValue !== null && defaultValue !== void 0 ? toDate(defaultValue) : null);
	const [viewState, setViewState] = (0, import_react.useState)(defaultView);
	const activeStartDate = activeStartDateProps || activeStartDateState || getInitialActiveStartDate({
		activeStartDate: activeStartDateProps,
		defaultActiveStartDate,
		defaultValue,
		defaultView,
		maxDate,
		maxDetail,
		minDate,
		minDetail,
		value: valueProps,
		view: viewProps
	});
	const value = (() => {
		const rawValue = (() => {
			if (selectRange && getIsSingleValue(valueState)) return valueState;
			return valueProps !== void 0 ? valueProps : valueState;
		})();
		if (!rawValue) return null;
		return Array.isArray(rawValue) ? rawValue.map((el) => el !== null ? toDate(el) : null) : rawValue !== null ? toDate(rawValue) : null;
	})();
	const valueType = getValueType(maxDetail);
	const view = getView(viewProps || viewState, minDetail, maxDetail);
	const views = getLimitedViews(minDetail, maxDetail);
	const hover = selectRange ? hoverState : null;
	const drillDownAvailable = views.indexOf(view) < views.length - 1;
	const drillUpAvailable = views.indexOf(view) > 0;
	const getProcessedValue = (0, import_react.useCallback)((value) => {
		return (() => {
			switch (returnValue) {
				case "start": return getDetailValueFrom;
				case "end": return getDetailValueTo;
				case "range": return getDetailValueArray;
				default: throw new Error("Invalid returnValue.");
			}
		})()({
			maxDate,
			maxDetail,
			minDate,
			value
		});
	}, [
		maxDate,
		maxDetail,
		minDate,
		returnValue
	]);
	const setActiveStartDate = (0, import_react.useCallback)((nextActiveStartDate, action) => {
		setActiveStartDateState(nextActiveStartDate);
		const args = {
			action,
			activeStartDate: nextActiveStartDate,
			value,
			view
		};
		if (onActiveStartDateChange && !areDatesEqual(activeStartDate, nextActiveStartDate)) onActiveStartDateChange(args);
	}, [
		activeStartDate,
		onActiveStartDateChange,
		value,
		view
	]);
	const onClickTile = (0, import_react.useCallback)((value, event) => {
		const callback = (() => {
			switch (view) {
				case "century": return onClickDecade;
				case "decade": return onClickYear;
				case "year": return onClickMonth;
				case "month": return onClickDay;
				default: throw new Error(`Invalid view: ${view}.`);
			}
		})();
		if (callback) callback(value, event);
	}, [
		onClickDay,
		onClickDecade,
		onClickMonth,
		onClickYear,
		view
	]);
	const drillDown = (0, import_react.useCallback)((nextActiveStartDate, event) => {
		if (!drillDownAvailable) return;
		onClickTile(nextActiveStartDate, event);
		const nextView = views[views.indexOf(view) + 1];
		if (!nextView) throw new Error("Attempted to drill down from the lowest view.");
		setActiveStartDateState(nextActiveStartDate);
		setViewState(nextView);
		const args = {
			action: "drillDown",
			activeStartDate: nextActiveStartDate,
			value,
			view: nextView
		};
		if (onActiveStartDateChange && !areDatesEqual(activeStartDate, nextActiveStartDate)) onActiveStartDateChange(args);
		if (onViewChange && view !== nextView) onViewChange(args);
		if (onDrillDown) onDrillDown(args);
	}, [
		activeStartDate,
		drillDownAvailable,
		onActiveStartDateChange,
		onClickTile,
		onDrillDown,
		onViewChange,
		value,
		view,
		views
	]);
	const drillUp = (0, import_react.useCallback)(() => {
		if (!drillUpAvailable) return;
		const nextView = views[views.indexOf(view) - 1];
		if (!nextView) throw new Error("Attempted to drill up from the highest view.");
		const nextActiveStartDate = getBegin(nextView, activeStartDate);
		setActiveStartDateState(nextActiveStartDate);
		setViewState(nextView);
		const args = {
			action: "drillUp",
			activeStartDate: nextActiveStartDate,
			value,
			view: nextView
		};
		if (onActiveStartDateChange && !areDatesEqual(activeStartDate, nextActiveStartDate)) onActiveStartDateChange(args);
		if (onViewChange && view !== nextView) onViewChange(args);
		if (onDrillUp) onDrillUp(args);
	}, [
		activeStartDate,
		drillUpAvailable,
		onActiveStartDateChange,
		onDrillUp,
		onViewChange,
		value,
		view,
		views
	]);
	const onChange = (0, import_react.useCallback)((rawNextValue, event) => {
		const previousValue = value;
		onClickTile(rawNextValue, event);
		const isFirstValueInRange = selectRange && !getIsSingleValue(previousValue);
		let nextValue;
		if (selectRange) {
			if (isFirstValueInRange) nextValue = getBegin(valueType, rawNextValue);
			else {
				if (!previousValue) throw new Error("previousValue is required");
				if (Array.isArray(previousValue)) throw new Error("previousValue must not be an array");
				nextValue = getValueRange(valueType, previousValue, rawNextValue);
			}
		} else nextValue = getProcessedValue(rawNextValue);
		const nextActiveStartDate = !selectRange || isFirstValueInRange || goToRangeStartOnSelect ? getActiveStartDate({
			maxDate,
			maxDetail,
			minDate,
			minDetail,
			value: nextValue,
			view
		}) : null;
		event.persist();
		setActiveStartDateState(nextActiveStartDate);
		setValueState(nextValue);
		const args = {
			action: "onChange",
			activeStartDate: nextActiveStartDate,
			value: nextValue,
			view
		};
		if (onActiveStartDateChange && !areDatesEqual(activeStartDate, nextActiveStartDate)) onActiveStartDateChange(args);
		if (onChangeProps) {
			if (selectRange) {
				if (!getIsSingleValue(nextValue)) onChangeProps(nextValue || null, event);
				else if (allowPartialRange) {
					if (Array.isArray(nextValue)) throw new Error("value must not be an array");
					onChangeProps([nextValue || null, null], event);
				}
			} else onChangeProps(nextValue || null, event);
		}
	}, [
		activeStartDate,
		allowPartialRange,
		getProcessedValue,
		goToRangeStartOnSelect,
		maxDate,
		maxDetail,
		minDate,
		minDetail,
		onActiveStartDateChange,
		onChangeProps,
		onClickTile,
		selectRange,
		value,
		valueType,
		view
	]);
	function onMouseOver(nextHover) {
		setHoverState(nextHover);
	}
	function onMouseLeave() {
		setHoverState(null);
	}
	(0, import_react.useImperativeHandle)(ref, () => ({
		activeStartDate,
		drillDown,
		drillUp,
		onChange,
		setActiveStartDate,
		value,
		view
	}), [
		activeStartDate,
		drillDown,
		drillUp,
		onChange,
		setActiveStartDate,
		value,
		view
	]);
	function renderContent(next) {
		const commonProps = {
			activeStartDate: next ? getBeginNext(view, activeStartDate) : getBegin(view, activeStartDate),
			hover,
			locale,
			maxDate,
			minDate,
			onClick: drillDownAvailable ? drillDown : onChange,
			onMouseOver: selectRange ? onMouseOver : void 0,
			tileClassName,
			tileContent,
			tileDisabled,
			value,
			valueType
		};
		switch (view) {
			case "century": return (0, import_jsx_runtime.jsx)(CenturyView, {
				formatYear,
				showNeighboringCentury,
				...commonProps
			});
			case "decade": return (0, import_jsx_runtime.jsx)(DecadeView, {
				formatYear,
				showNeighboringDecade,
				...commonProps
			});
			case "year": return (0, import_jsx_runtime.jsx)(YearView, {
				formatMonth,
				formatMonthYear,
				...commonProps
			});
			case "month": return (0, import_jsx_runtime.jsx)(MonthView, {
				calendarType,
				formatDay,
				formatLongDate,
				formatShortWeekday,
				formatWeekday,
				onClickWeekNumber,
				onMouseLeave: selectRange ? onMouseLeave : void 0,
				showFixedNumberOfWeeks: typeof showFixedNumberOfWeeks !== "undefined" ? showFixedNumberOfWeeks : showDoubleView,
				showNeighboringMonth,
				showWeekNumbers,
				...commonProps
			});
			default: throw new Error(`Invalid view: ${view}.`);
		}
	}
	function renderNavigation() {
		if (!showNavigation) return null;
		return (0, import_jsx_runtime.jsx)(Navigation, {
			activeStartDate,
			drillUp,
			formatMonthYear,
			formatYear,
			locale,
			maxDate,
			minDate,
			navigationAriaLabel,
			navigationAriaLive,
			navigationLabel,
			next2AriaLabel,
			next2Label,
			nextAriaLabel,
			nextLabel,
			prev2AriaLabel,
			prev2Label,
			prevAriaLabel,
			prevLabel,
			setActiveStartDate,
			showDoubleView,
			view,
			views
		});
	}
	return (0, import_jsx_runtime.jsxs)("div", {
		className: clsx(baseClassName, selectRange && (Array.isArray(value) ? value : [value]).length === 1 && `${baseClassName}--selectRange`, showDoubleView && `${baseClassName}--doubleView`, className),
		"data-testid": dataTestId,
		ref: inputRef,
		children: [renderNavigation(), (0, import_jsx_runtime.jsxs)("div", {
			className: `${baseClassName}__viewContainer`,
			onBlur: selectRange ? onMouseLeave : void 0,
			onMouseLeave: selectRange ? onMouseLeave : void 0,
			children: [renderContent(), showDoubleView ? renderContent(true) : null]
		})]
	});
});
//#endregion
//#region src/components/admin/CalendarPanel.tsx
function dateKey(value) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: "Asia/Macau",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(new Date(value));
}
function monthRange(anchor) {
	const year = anchor.getFullYear(), month = anchor.getMonth();
	return {
		from: (/* @__PURE__ */ new Date(Date.UTC(year, month, 1) - 288e5)).toISOString(),
		to: (/* @__PURE__ */ new Date(Date.UTC(year, month + 1, 1) - 288e5 - 1)).toISOString()
	};
}
function CalendarPanel({ locale }) {
	const [anchor, setAnchor] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [selected, setSelected] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [items, setItems] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const range = (0, import_react.useMemo)(() => monthRange(anchor), [anchor]);
	(0, import_react.useEffect)(() => {
		let live = true;
		setLoading(true);
		setError("");
		(async () => {
			try {
				const found = [];
				let cursor = null;
				for (let page = 0; page < 20; page++) {
					const query = new URLSearchParams({
						from: range.from,
						to: range.to,
						limit: "50"
					});
					if (cursor) query.set("cursor", cursor);
					const result = await adminFetch(`/api/v1/admin/bookings?${query}`, { locale });
					found.push(...result.items);
					cursor = result.nextCursor;
					if (!cursor) break;
				}
				if (live) setItems(found);
			} catch (err) {
				if (live) setError(localizeCaughtError(err, locale));
			} finally {
				if (live) setLoading(false);
			}
		})();
		return () => {
			live = false;
		};
	}, [range, locale]);
	const byDay = /* @__PURE__ */ new Map();
	for (const item of items) {
		const key = dateKey(item.pickupAt);
		byDay.set(key, [...byDay.get(key) ?? [], item]);
	}
	const selectedItems = byDay.get(dateKey(selected)) ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "admin-calendar-page",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-list-toolbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "admin-eyebrow",
						children: t(locale, "cal.eyebrow")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "cal.heading") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "muted",
						children: t(locale, "cal.lead")
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn btn--primary",
					href: "/admin/bookings",
					children: t(locale, "cal.viewAll")
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "admin-feedback admin-feedback--error",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-calendar-layout",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "admin-card admin-calendar-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(dist_default, {
						locale: adminDateLocale(locale),
						view: "month",
						minDetail: "month",
						maxDetail: "month",
						showNeighboringMonth: false,
						value: selected,
						onClickDay: setSelected,
						onActiveStartDateChange: ({ activeStartDate }) => {
							if (activeStartDate) setAnchor(activeStartDate);
						},
						tileContent: ({ date, view }) => view === "month" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "admin-calendar-count",
							children: byDay.get(dateKey(date))?.length || ""
						}) : null,
						tileClassName: ({ date, view }) => view === "month" && byDay.has(dateKey(date)) ? "admin-calendar-has-bookings" : void 0
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "admin-card admin-agenda",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "admin-eyebrow",
							children: t(locale, "cal.agenda")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: selected.toLocaleDateString(adminDateLocale(locale), {
							day: "numeric",
							month: "long",
							year: "numeric"
						}) }),
						loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "cal.loading") }) : selectedItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "muted",
							children: t(locale, "cal.empty")
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "admin-agenda-list",
							children: selectedItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `/admin/bookings/${item.reference}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatWhen(item.pickupAt, locale) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.pickupLocation }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t(locale, "cal.itemMeta", {
										reference: item.reference,
										status: prefixedLabel(locale, "status", item.status),
										count: item.passengerCount
									}) })
								]
							}, item.reference))
						})
					]
				})]
			})
		]
	});
}
//#endregion
//#region src/pages/admin/calendar.astro
var calendar_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Calendar,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Calendar = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Calendar;
	const locale = adminLocaleFromCookies(Astro.cookies);
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.calendar",
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "CalendarPanel", CalendarPanel, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/CalendarPanel.tsx",
		"client:component-export": "CalendarPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/calendar.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/calendar.astro";
var $$url = "/admin/calendar";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/calendar@_@astro
var page = () => calendar_exports;
//#endregion
export { page };
