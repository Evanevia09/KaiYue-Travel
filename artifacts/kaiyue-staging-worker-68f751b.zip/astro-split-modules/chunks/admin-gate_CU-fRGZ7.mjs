globalThis.process ??= {};
globalThis.process.env ??= {};
import { d as AppError } from "./src_BRRiv8WF.mjs";
//#region src/lib/server/admin-gate.ts
var LIVE_ADMIN_PATHS = [
	"/admin",
	"/api/admin",
	"/api/v1/admin"
];
var PASSWORD_ADMIN_PATHS = [
	"/login",
	"/setup-admin",
	"/api/auth"
];
var ACCESS_ADMIN_HOST = "admin.kaiyuemacau.com";
var CANONICAL_PUBLIC_ORIGIN = "https://kaiyuemacau.com";
/**
* Public production hostnames. Password admin is fail-closed here unless
* Access is unset and a future TEMP_ADMIN_EXPIRES_AT + ADMIN_EMAILS pair is
* explicitly configured. The staging workers.dev host must not appear here.
*/
var PRODUCTION_HOSTS = [
	"kaiyuemacau.com",
	"www.kaiyuemacau.com",
	"kaiyue-travel.scalingsmb.workers.dev"
];
var STAGING_HOSTS = ["kaiyue-travel-staging.kai-yue.workers.dev"];
function requestHost(request) {
	return new URL(request.url).hostname.toLowerCase();
}
function isAccessAdminHost(request) {
	return requestHost(request) === ACCESS_ADMIN_HOST;
}
function isProductionHost(request) {
	return PRODUCTION_HOSTS.includes(requestHost(request));
}
function isStagingHost(request) {
	return STAGING_HOSTS.includes(requestHost(request));
}
function isLoopbackHost(request) {
	const host = requestHost(request);
	return host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]" || host.endsWith(".localhost");
}
function isLocalRuntime(env) {
	const environment = (env.ENVIRONMENT ?? "").trim().toLowerCase();
	const envFlag = (env.ENV ?? "").trim().toLowerCase();
	return environment === "development" || environment === "local" || envFlag === "local";
}
function isPreviewRuntime(env, request) {
	if (request && (isProductionHost(request) || isAccessAdminHost(request))) return false;
	if ((env.ENVIRONMENT ?? "").trim().toLowerCase() === "preview") return true;
	if (request && isStagingHost(request)) return true;
	if ((env.ENVIRONMENT ?? "").trim().toLowerCase() === "production") return false;
	if (!request) return false;
	const host = requestHost(request);
	return host.endsWith(".workers.dev") && !PRODUCTION_HOSTS.includes(host);
}
function isLocalAdminSurface(env, request) {
	if (isProductionHost(request) || isAccessAdminHost(request) || isStagingHost(request)) return false;
	if (!isLoopbackHost(request)) return false;
	return isLocalRuntime(env);
}
function emailSignupAllowed(env, request) {
	return isLocalAdminSurface(env, request);
}
function accessConfigured(env) {
	return Boolean(env.ACCESS_TEAM_DOMAIN?.trim() && env.ACCESS_AUD?.trim());
}
/**
* Cloudflare Access, when configured, is the only non-local admin identity.
* Password login stays available on loopback development so operators can work
* without a tunnel.
*/
function accessTakesOver(env, request) {
	return !isLocalAdminSurface(env, request) && (isAccessAdminHost(request) || accessConfigured(env));
}
function passwordAdminPath(pathname) {
	return PASSWORD_ADMIN_PATHS.some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`));
}
function isProtectedAdminPath(pathname) {
	return passwordAdminPath(pathname) || LIVE_ADMIN_PATHS.some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`));
}
function temporaryPasswordConfigured(env) {
	if (!(env.ADMIN_EMAILS ?? "").split(",").map((email) => email.trim()).some(Boolean)) return false;
	const raw = env.TEMP_ADMIN_EXPIRES_AT?.trim();
	if (!raw) return false;
	const expiresAt = Date.parse(raw);
	return Number.isFinite(expiresAt) && Date.now() < expiresAt;
}
function passwordAdminAllowed(env, request) {
	if (isAccessAdminHost(request)) return false;
	if (accessConfigured(env) && !isLocalAdminSurface(env, request)) return false;
	if (isLocalAdminSurface(env, request)) return true;
	if (!temporaryPasswordConfigured(env)) return false;
	if (isProductionHost(request)) return true;
	return isPreviewRuntime(env, request) || isStagingHost(request);
}
function assertLiveAdminSurface(env, pathname, request) {
	if (!isProtectedAdminPath(pathname)) return;
	if (isLocalAdminSurface(env, request)) return;
	if (accessTakesOver(env, request)) {
		if (passwordAdminPath(pathname) || !accessConfigured(env)) throw new AppError("FORBIDDEN", "Admin access is not configured.");
		return;
	}
	if (passwordAdminAllowed(env, request)) {
		if (pathname === "/setup-admin") throw new AppError("FORBIDDEN", "Operator setup is disabled.");
		return;
	}
	throw new AppError("FORBIDDEN", "Admin access is not configured.");
}
function forbiddenResponse(message = "Admin access is not configured.") {
	return new Response(JSON.stringify({ error: {
		code: "FORBIDDEN",
		message,
		requestId: "gate"
	} }), {
		status: 403,
		headers: {
			"content-type": "application/json; charset=utf-8",
			"cache-control": "no-store"
		}
	});
}
//#endregion
export { assertLiveAdminSurface as a, isAccessAdminHost as c, isProductionHost as d, isProtectedAdminPath as f, accessTakesOver as i, isLocalAdminSurface as l, temporaryPasswordConfigured as m, CANONICAL_PUBLIC_ORIGIN as n, emailSignupAllowed as o, passwordAdminAllowed as p, accessConfigured as r, forbiddenResponse as s, ACCESS_ADMIN_HOST as t, isLocalRuntime as u };
