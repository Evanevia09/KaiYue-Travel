globalThis.process ??= {};
globalThis.process.env ??= {};
//#region src/lib/server/db.ts
async function first(db, sql, ...params) {
	return await db.prepare(sql).bind(...params).first() ?? null;
}
async function all(db, sql, ...params) {
	return (await db.prepare(sql).bind(...params).all()).results ?? [];
}
async function run(db, sql, ...params) {
	return db.prepare(sql).bind(...params).run();
}
function nowIso() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
//#endregion
export { run as i, first as n, nowIso as r, all as t };
