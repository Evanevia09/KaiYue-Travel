globalThis.process ??= {};
globalThis.process.env ??= {};
import { d as AppError, h as destinationRequired, n as OFFER_IMAGE_CACHE_SECONDS, t as getPublicConfig } from "./src_BRRiv8WF.mjs";
import { a as assertLiveAdminSurface } from "./admin-gate_CU-fRGZ7.mjs";
import { n as requireSameOrigin, t as requireAdmin } from "./auth_D0SXpiEz.mjs";
import { a as getAdminOffer, c as listPublicOffers, d as setMainOfferPhoto, f as unpublishOffer, h as parseOfferImageDimension, i as deleteOfferPhoto, l as publishOffer, m as offerPhotoVersion, n as createOffer, o as getPublicOffer, p as updateOffer, r as deleteOffer, s as listAdminOffers, t as addOfferPhoto, u as readOfferPhoto } from "./service_DalvdZP-.mjs";
import { i as run, n as first, r as nowIso, t as all } from "./db_BJi_UM06.mjs";
import { a as handleAdminBookingsList, c as handleAdminContactsList, d as createBooking, f as getBookingByReference, i as handleAdminBookingStatus, l as createContact, n as adminSummary, o as handleAdminContactDetail, p as noticeHours, r as handleAdminBookingDetail, s as handleAdminContactStatus, t as addNote, u as bookingToAdmin } from "./admin_DYkS9rEP.mjs";
import { c as readJson, i as errorResponse, l as requestIdFrom, o as json } from "./rate-limit_BIbPyTWs.mjs";
//#region src/lib/server/offers/routes.ts
function match$1(pathname, pattern) {
	const pathParts = pathname.split("/").filter(Boolean);
	const patternParts = pattern.split("/").filter(Boolean);
	if (pathParts.length !== patternParts.length) return null;
	const params = {};
	for (const [index, part] of patternParts.entries()) {
		const value = pathParts[index];
		if (!value) return null;
		if (part.startsWith(":")) {
			params[part.slice(1)] = decodeURIComponent(value);
			continue;
		}
		if (part !== value) return null;
	}
	return params;
}
function methodNotAllowed() {
	throw new AppError("VALIDATION_FAILED", "Method not allowed.", { status: 405 });
}
async function readUpload(request) {
	if (!(request.headers.get("content-type") ?? "").includes("multipart/form-data")) throw new AppError("VALIDATION_FAILED", "Send the photo as multipart form data.", { fields: { photo: "Send the photo as multipart form data." } });
	const form = await request.formData();
	const file = form.get("photo") ?? form.get("file");
	if (!(file instanceof File)) throw new AppError("VALIDATION_FAILED", "Choose a JPEG, PNG, or WebP image.", { fields: { photo: "Choose a JPEG, PNG, or WebP image." } });
	const thumb = form.get("thumbnail");
	return {
		bytes: new Uint8Array(await file.arrayBuffer()),
		type: file.type || "application/octet-stream",
		thumbnail: thumb instanceof File ? {
			bytes: new Uint8Array(await thumb.arrayBuffer()),
			type: thumb.type || file.type
		} : void 0,
		width: parseOfferImageDimension(form.get("width")),
		height: parseOfferImageDimension(form.get("height"))
	};
}
function photoResponse(body, contentType, options = { immutable: false }) {
	const copy = new Uint8Array(body);
	const cacheControl = options.immutable ? options.publicPhoto ? `public, max-age=${OFFER_IMAGE_CACHE_SECONDS}, immutable` : `private, max-age=${OFFER_IMAGE_CACHE_SECONDS}, immutable` : "private, no-store";
	const headers = new Headers({
		"content-type": contentType,
		"cache-control": cacheControl,
		"x-content-type-options": "nosniff"
	});
	if (options.immutable && options.publicPhoto) {
		headers.set("cdn-cache-control", `public, max-age=${OFFER_IMAGE_CACHE_SECONDS}, immutable`);
		headers.set("cloudflare-cdn-cache-control", `public, max-age=${OFFER_IMAGE_CACHE_SECONDS}, immutable`);
	} else {
		headers.set("cdn-cache-control", "no-store");
		headers.set("cloudflare-cdn-cache-control", "no-store");
	}
	if (options.version) headers.set("etag", `"${options.version}"`);
	return new Response(copy, {
		status: 200,
		headers
	});
}
async function serveOfferPhoto(env, offerId, photoId, options = {}) {
	const object = await readOfferPhoto(env, offerId, photoId, options);
	const version = offerPhotoVersion(object.photo);
	return photoResponse(object.body, object.contentType, {
		immutable: Boolean(options.version),
		publicPhoto: options.publicOnly,
		version
	});
}
async function handlePublicOfferRoutes(request, env, requestId, pathname) {
	if (request.method === "GET" && pathname === "/api/v1/offers") return json(await listPublicOffers(env), 200, requestId);
	const detail = match$1(pathname, "/api/v1/offers/:id");
	if (detail) {
		if (request.method !== "GET") methodNotAllowed();
		return json(await getPublicOffer(env, detail.id), 200, requestId);
	}
	const thumbVersioned = match$1(pathname, "/api/v1/offers/:id/photos/:photoId/thumb/:hash");
	if (thumbVersioned) {
		if (request.method !== "GET") methodNotAllowed();
		return serveOfferPhoto(env, thumbVersioned.id, thumbVersioned.photoId, {
			publicOnly: true,
			variant: "thumb",
			version: thumbVersioned.hash
		});
	}
	const versioned = match$1(pathname, "/api/v1/offers/:id/photos/:photoId/:hash");
	if (versioned) {
		if (request.method !== "GET") methodNotAllowed();
		return serveOfferPhoto(env, versioned.id, versioned.photoId, {
			publicOnly: true,
			version: versioned.hash
		});
	}
	const photo = match$1(pathname, "/api/v1/offers/:id/photos/:photoId");
	if (photo) {
		if (request.method !== "GET") methodNotAllowed();
		return serveOfferPhoto(env, photo.id, photo.photoId, { publicOnly: true });
	}
	return null;
}
async function handleAdminOfferRoutes(request, env, requestId, pathname, actor) {
	const base = pathname.startsWith("/api/v1/admin/offers") ? "/api/v1/admin/offers" : pathname.startsWith("/api/admin/offers") ? "/api/admin/offers" : null;
	if (!base) return null;
	if (pathname === base) {
		if (request.method === "GET") return json(await listAdminOffers(env), 200, requestId);
		if (request.method === "POST") return json(await createOffer(env, await readJson(request), actor.id, requestId), 201, requestId);
		methodNotAllowed();
	}
	const publish = match$1(pathname, `${base}/:id/publish`);
	if (publish) {
		if (request.method !== "POST") methodNotAllowed();
		return json(await publishOffer(env, publish.id, actor.id, requestId), 200, requestId);
	}
	const unpublish = match$1(pathname, `${base}/:id/unpublish`);
	if (unpublish) {
		if (request.method !== "POST") methodNotAllowed();
		return json(await unpublishOffer(env, unpublish.id, actor.id, requestId), 200, requestId);
	}
	const mainPhoto = match$1(pathname, `${base}/:id/photos/:photoId/main`);
	if (mainPhoto) {
		if (request.method !== "POST" && request.method !== "PATCH") methodNotAllowed();
		return json(await setMainOfferPhoto(env, mainPhoto.id, mainPhoto.photoId, actor.id, requestId), 200, requestId);
	}
	const thumbVersioned = match$1(pathname, `${base}/:id/photos/:photoId/thumb/:hash`);
	if (thumbVersioned) {
		if (request.method !== "GET") methodNotAllowed();
		return serveOfferPhoto(env, thumbVersioned.id, thumbVersioned.photoId, {
			variant: "thumb",
			version: thumbVersioned.hash
		});
	}
	const versioned = match$1(pathname, `${base}/:id/photos/:photoId/:hash`);
	if (versioned) {
		if (request.method !== "GET") methodNotAllowed();
		return serveOfferPhoto(env, versioned.id, versioned.photoId, { version: versioned.hash });
	}
	const photo = match$1(pathname, `${base}/:id/photos/:photoId`);
	if (photo) {
		if (request.method === "GET") return serveOfferPhoto(env, photo.id, photo.photoId);
		if (request.method === "DELETE") return json(await deleteOfferPhoto(env, photo.id, photo.photoId, actor.id, requestId), 200, requestId);
		methodNotAllowed();
	}
	const photos = match$1(pathname, `${base}/:id/photos`);
	if (photos) {
		if (request.method !== "POST") methodNotAllowed();
		return json(await addOfferPhoto(env, photos.id, await readUpload(request), actor.id, requestId), 201, requestId);
	}
	const detail = match$1(pathname, `${base}/:id`);
	if (detail) {
		if (request.method === "GET") return json(await getAdminOffer(env, detail.id), 200, requestId);
		if (request.method === "PATCH") return json(await updateOffer(env, detail.id, await readJson(request), actor.id, requestId), 200, requestId);
		if (request.method === "DELETE") return json(await deleteOffer(env, detail.id, actor.id, requestId), 200, requestId);
		methodNotAllowed();
	}
	return null;
}
//#endregion
//#region src/lib/server/dispatch.ts
function inputObject(input) {
	if (!input || typeof input !== "object" || Array.isArray(input)) throw new AppError("VALIDATION_FAILED", "Check the booking details.");
	return input;
}
function nextTimestamp(previous) {
	return new Date(Math.max(Date.now(), Date.parse(previous) + 1)).toISOString();
}
function text(value, label, max, required = false) {
	if (value !== null && typeof value !== "string") throw new AppError("VALIDATION_FAILED", `Check ${label}.`);
	const trimmed = (value ?? "").trim();
	if (trimmed.length > max || required && trimmed.length < 2) throw new AppError("VALIDATION_FAILED", `Check ${label}.`);
	return trimmed || null;
}
async function audit$1(db, row, kind, fields, actorId, requestId, updatedAt) {
	return db.prepare(`INSERT INTO audit_events (id, entity_type, entity_id, event_type, actor_id, from_value, to_value, request_id, created_at)
    VALUES (?, 'booking', ?, ?, ?, NULL, ?, ?, ?)`).bind(crypto.randomUUID(), row.id, kind, actorId, JSON.stringify(fields), requestId, updatedAt);
}
async function editBooking(db, reference, input, actorId, requestId) {
	const row = await getBookingByReference(db, reference);
	if (!row) throw new AppError("NOT_FOUND", "Booking not found.");
	const data = inputObject(input);
	if (data.expectedUpdatedAt !== row.updated_at) throw new AppError("CONFLICT", "This booking changed. Refresh and try again.");
	const pickupLocation = text(data.pickupLocation, "pickup location", 200, true);
	const destination = text(data.destination, "destination", 200, destinationRequired(row.service_type));
	const pickupAt = typeof data.pickupAt === "string" && !Number.isNaN(Date.parse(data.pickupAt)) ? new Date(data.pickupAt).toISOString() : null;
	const returnAt = data.returnAt ? typeof data.returnAt === "string" && !Number.isNaN(Date.parse(data.returnAt)) ? new Date(data.returnAt).toISOString() : null : null;
	if (!pickupAt || data.returnAt && !returnAt || returnAt && returnAt <= pickupAt) throw new AppError("VALIDATION_FAILED", "Check pickup and return times.");
	const passengers = data.passengerCount;
	if (typeof passengers !== "number" || !Number.isInteger(passengers) || passengers < 1 || passengers > 14) throw new AppError("VALIDATION_FAILED", "Passengers must be between 1 and 14.");
	if (row.vehicle_id) {
		const assignedVehicle = await first(db, "SELECT * FROM vehicles WHERE id = ?", row.vehicle_id);
		if (assignedVehicle && passengers > assignedVehicle.passenger_capacity) throw new AppError("VALIDATION_FAILED", "Passenger count exceeds the assigned vehicle capacity.");
	}
	const contactName = text(data.contactName, "name", 100);
	const phone = text(data.phone, "phone", 32);
	const email = text(data.email, "email", 160);
	if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new AppError("VALIDATION_FAILED", "Enter a valid email.");
	const message = text(data.message, "message", 2e3) ?? "";
	const updatedAt = nextTimestamp(row.updated_at);
	const fields = [
		"pickupLocation",
		"destination",
		"pickupAt",
		"returnAt",
		"passengerCount",
		"contactName",
		"phone",
		"email",
		"message"
	].filter((name) => {
		const dbKey = {
			pickupLocation: "pickup_location",
			pickupAt: "pickup_at",
			returnAt: "return_at",
			passengerCount: "passenger_count",
			contactName: "contact_name"
		}[name] ?? name;
		const next = {
			pickupLocation,
			destination,
			pickupAt,
			returnAt,
			passengerCount: passengers,
			contactName,
			phone,
			email,
			message
		}[name];
		return row[dbKey] !== next;
	});
	if (fields.length === 0) return { booking: bookingToAdmin(row) };
	await db.batch([db.prepare(`UPDATE bookings SET pickup_location=?, destination=?, pickup_at=?, return_at=?, passenger_count=?, contact_name=?, phone=?, phone_display=?, email=?, message=?, updated_at=? WHERE id=? AND updated_at=?`).bind(pickupLocation, destination, pickupAt, returnAt, passengers, contactName, phone, phone, email, message, updatedAt, row.id, row.updated_at), await audit$1(db, row, "details_edit", fields, actorId, requestId, updatedAt)]);
	const updated = await getBookingByReference(db, reference);
	return { booking: bookingToAdmin(updated) };
}
async function assignBooking(db, reference, input, actorId, requestId) {
	const row = await getBookingByReference(db, reference);
	if (!row) throw new AppError("NOT_FOUND", "Booking not found.");
	const data = inputObject(input);
	if (data.expectedUpdatedAt !== row.updated_at) throw new AppError("CONFLICT", "This booking changed. Refresh and try again.");
	const driverId = data.driverId === null ? null : typeof data.driverId === "string" ? data.driverId : void 0;
	const vehicleId = data.vehicleId === null ? null : typeof data.vehicleId === "string" ? data.vehicleId : void 0;
	if (driverId === void 0 || vehicleId === void 0 || Boolean(driverId) !== Boolean(vehicleId)) throw new AppError("VALIDATION_FAILED", "Choose both a driver and vehicle, or clear both.");
	if (driverId && vehicleId) {
		const [driver, vehicle] = await Promise.all([first(db, "SELECT * FROM drivers WHERE id = ?", driverId), first(db, "SELECT * FROM vehicles WHERE id = ?", vehicleId)]);
		if (!driver?.active || !vehicle?.active) throw new AppError("VALIDATION_FAILED", "Choose active driver and vehicle records.");
		if (vehicle.passenger_capacity < row.passenger_count) throw new AppError("VALIDATION_FAILED", "Vehicle capacity is below passenger count.");
	}
	if (row.driver_id === driverId && row.vehicle_id === vehicleId) return { booking: bookingToAdmin(row) };
	const updatedAt = nextTimestamp(row.updated_at);
	await db.batch([db.prepare("UPDATE bookings SET driver_id=?, vehicle_id=?, updated_at=? WHERE id=? AND updated_at=?").bind(driverId, vehicleId, updatedAt, row.id, row.updated_at), await audit$1(db, row, "assignment_change", ["driverId", "vehicleId"], actorId, requestId, updatedAt)]);
	const updated = await getBookingByReference(db, reference);
	return { booking: bookingToAdmin(updated) };
}
//#endregion
//#region src/lib/server/inventory.ts
function objectInput(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new AppError("VALIDATION_FAILED", "Check the record details.");
	return value;
}
function requiredText(value, field, max) {
	const text = typeof value === "string" ? value.trim() : "";
	if (text.length < 2 || text.length > max) throw new AppError("VALIDATION_FAILED", `Enter a valid ${field}.`, { fields: { [field]: `Use 2–${max} characters.` } });
	return text;
}
function optionalText(value, field, max) {
	if (value === null || value === "" || value === void 0) return null;
	if (typeof value !== "string" || value.trim().length > max) throw new AppError("VALIDATION_FAILED", `Enter a valid ${field}.`);
	return value.trim() || null;
}
function phone(value, field, required = false) {
	const text = optionalText(value, field, 32);
	if (required && !text) throw new AppError("VALIDATION_FAILED", `Enter a ${field}.`, { fields: { [field]: "Required." } });
	if (text && !/^\+?[0-9][0-9 +().-]{5,31}$/.test(text)) throw new AppError("VALIDATION_FAILED", `Enter a valid ${field}.`);
	return text;
}
function email(value) {
	const text = optionalText(value, "email", 160)?.toLowerCase() ?? null;
	if (text && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text)) throw new AppError("VALIDATION_FAILED", "Enter a valid email address.");
	return text;
}
function active(value, fallback) {
	if (value === void 0) return fallback;
	if (value === true) return 1;
	if (value === false) return 0;
	throw new AppError("VALIDATION_FAILED", "Choose an active state.");
}
function capacity(value) {
	if (!Number.isInteger(value) || Number(value) < 1 || Number(value) > 14) throw new AppError("VALIDATION_FAILED", "Passenger capacity must be between 1 and 14.");
	return Number(value);
}
function driverToAdmin(row) {
	return {
		id: row.id,
		name: row.name,
		phone: row.phone,
		email: row.email,
		notes: row.notes,
		active: Boolean(row.active),
		updatedAt: row.updated_at
	};
}
function vehicleToAdmin(row) {
	return {
		id: row.id,
		plateNumber: row.plate_number,
		makeModel: row.make_model,
		passengerCapacity: row.passenger_capacity,
		contactName: row.contact_name,
		contactPhone: row.contact_phone,
		notes: row.notes,
		active: Boolean(row.active),
		updatedAt: row.updated_at
	};
}
async function audit(db, resourceType, resourceId, eventType, changedFields, actorId, requestId) {
	await run(db, `INSERT INTO inventory_audit_events
      (id, resource_type, resource_id, event_type, actor_id, changed_fields, request_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, crypto.randomUUID(), resourceType, resourceId, eventType, JSON.stringify(changedFields), actorId, requestId, nowIso());
}
async function listDrivers(db) {
	return (await all(db, "SELECT * FROM drivers ORDER BY active DESC, name ASC LIMIT 200")).map(driverToAdmin);
}
async function listVehicles(db) {
	return (await all(db, "SELECT * FROM vehicles ORDER BY active DESC, plate_number ASC LIMIT 200")).map(vehicleToAdmin);
}
async function createDriver(db, input, actorId, requestId) {
	const data = objectInput(input);
	const id = crypto.randomUUID();
	const name = requiredText(data.name, "name", 100);
	const contactPhone = phone(data.phone, "phone", true);
	const contactEmail = email(data.email);
	const notes = optionalText(data.notes, "notes", 500);
	const isActive = active(data.active, 1);
	const createdAt = nowIso();
	await run(db, `INSERT INTO drivers (id, name, phone, email, notes, active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, id, name, contactPhone, contactEmail, notes, isActive, createdAt, createdAt);
	await audit(db, "driver", id, "created", [
		"name",
		"phone",
		"email",
		"notes"
	], actorId, requestId);
	return driverToAdmin(await first(db, "SELECT * FROM drivers WHERE id = ?", id));
}
async function updateDriver(db, id, input, actorId, requestId) {
	const previous = await first(db, "SELECT * FROM drivers WHERE id = ?", id);
	if (!previous) throw new AppError("NOT_FOUND", "Driver not found.");
	const data = objectInput(input);
	const next = {
		name: data.name === void 0 ? previous.name : requiredText(data.name, "name", 100),
		phone: data.phone === void 0 ? previous.phone : phone(data.phone, "phone", true),
		email: data.email === void 0 ? previous.email : email(data.email),
		notes: data.notes === void 0 ? previous.notes : optionalText(data.notes, "notes", 500),
		active: active(data.active, previous.active)
	};
	const changed = Object.keys(next).filter((key) => next[key] !== previous[key]);
	if (!changed.length) return driverToAdmin(previous);
	await run(db, "UPDATE drivers SET name = ?, phone = ?, email = ?, notes = ?, active = ?, updated_at = ? WHERE id = ?", next.name, next.phone, next.email, next.notes, next.active, nowIso(), id);
	await audit(db, "driver", id, "updated", changed, actorId, requestId);
	return driverToAdmin(await first(db, "SELECT * FROM drivers WHERE id = ?", id));
}
async function createVehicle(db, input, actorId, requestId) {
	const data = objectInput(input);
	const id = crypto.randomUUID();
	const plate = requiredText(data.plateNumber, "plateNumber", 32).toUpperCase();
	const model = requiredText(data.makeModel, "makeModel", 100);
	const seats = capacity(data.passengerCapacity);
	const contactName = optionalText(data.contactName, "contactName", 100);
	const contactPhone = phone(data.contactPhone, "contactPhone");
	const notes = optionalText(data.notes, "notes", 500);
	const isActive = active(data.active, 1);
	const createdAt = nowIso();
	try {
		await run(db, `INSERT INTO vehicles (id, plate_number, make_model, passenger_capacity, contact_name, contact_phone, notes, active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, id, plate, model, seats, contactName, contactPhone, notes, isActive, createdAt, createdAt);
	} catch (error) {
		if (String(error).includes("UNIQUE")) throw new AppError("CONFLICT", "A vehicle with this plate already exists.");
		throw error;
	}
	await audit(db, "vehicle", id, "created", [
		"plateNumber",
		"makeModel",
		"passengerCapacity",
		"contactName",
		"contactPhone",
		"notes"
	], actorId, requestId);
	return vehicleToAdmin(await first(db, "SELECT * FROM vehicles WHERE id = ?", id));
}
async function updateVehicle(db, id, input, actorId, requestId) {
	const previous = await first(db, "SELECT * FROM vehicles WHERE id = ?", id);
	if (!previous) throw new AppError("NOT_FOUND", "Vehicle not found.");
	const data = objectInput(input);
	const next = {
		plate_number: data.plateNumber === void 0 ? previous.plate_number : requiredText(data.plateNumber, "plateNumber", 32).toUpperCase(),
		make_model: data.makeModel === void 0 ? previous.make_model : requiredText(data.makeModel, "makeModel", 100),
		passenger_capacity: data.passengerCapacity === void 0 ? previous.passenger_capacity : capacity(data.passengerCapacity),
		contact_name: data.contactName === void 0 ? previous.contact_name : optionalText(data.contactName, "contactName", 100),
		contact_phone: data.contactPhone === void 0 ? previous.contact_phone : phone(data.contactPhone, "contactPhone"),
		notes: data.notes === void 0 ? previous.notes : optionalText(data.notes, "notes", 500),
		active: active(data.active, previous.active)
	};
	const changed = Object.keys(next).filter((key) => next[key] !== previous[key]);
	if (!changed.length) return vehicleToAdmin(previous);
	try {
		await run(db, "UPDATE vehicles SET plate_number = ?, make_model = ?, passenger_capacity = ?, contact_name = ?, contact_phone = ?, notes = ?, active = ?, updated_at = ? WHERE id = ?", next.plate_number, next.make_model, next.passenger_capacity, next.contact_name, next.contact_phone, next.notes, next.active, nowIso(), id);
	} catch (error) {
		if (String(error).includes("UNIQUE")) throw new AppError("CONFLICT", "A vehicle with this plate already exists.");
		throw error;
	}
	await audit(db, "vehicle", id, "updated", changed, actorId, requestId);
	return vehicleToAdmin(await first(db, "SELECT * FROM vehicles WHERE id = ?", id));
}
//#endregion
//#region src/lib/server/router.ts
function match(pathname, pattern) {
	const pathParts = pathname.split("/").filter(Boolean);
	const patternParts = pattern.split("/").filter(Boolean);
	if (pathParts.length !== patternParts.length) return null;
	const params = {};
	for (const [index, part] of patternParts.entries()) {
		const value = pathParts[index];
		if (!value) return null;
		if (part.startsWith(":")) {
			params[part.slice(1)] = decodeURIComponent(value);
			continue;
		}
		if (part !== value) return null;
	}
	return params;
}
async function handleApi(request, env, existingRequestId) {
	const requestId = requestIdFrom(request, existingRequestId);
	const { pathname } = new URL(request.url);
	try {
		if (request.method === "GET" && pathname === "/api/v1/config/public") return json(getPublicConfig({
			timezone: env.BUSINESS_TIMEZONE,
			noticeHours: noticeHours(env)
		}), 200, requestId);
		if (request.method === "POST" && pathname === "/api/v1/bookings") return await createBooking(request, env, requestId);
		if (request.method === "POST" && pathname === "/api/v1/contacts") return await createContact(request, env, requestId);
		const publicOffers = await handlePublicOfferRoutes(request, env, requestId, pathname);
		if (publicOffers) return publicOffers;
		if (pathname.startsWith("/api/admin") || pathname.startsWith("/api/v1/admin")) {
			assertLiveAdminSurface(env, pathname, request);
			requireSameOrigin(request, env);
			const actor = await requireAdmin(request, env);
			const adminOffers = await handleAdminOfferRoutes(request, env, requestId, pathname, actor);
			if (adminOffers) return adminOffers;
			if (request.method === "GET" && pathname === "/api/v1/admin/summary") return json(await adminSummary(env), 200, requestId);
			if (request.method === "GET" && pathname === "/api/v1/admin/bookings") return json(await handleAdminBookingsList(request, env), 200, requestId);
			if (pathname === "/api/v1/admin/drivers") {
				if (request.method === "GET") return json({ items: await listDrivers(env.DB) }, 200, requestId);
				if (request.method === "POST") return json({ item: await createDriver(env.DB, await readJson(request), actor.id, requestId) }, 201, requestId);
			}
			const driverParams = match(pathname, "/api/v1/admin/drivers/:id");
			if (request.method === "PATCH" && driverParams) return json({ item: await updateDriver(env.DB, driverParams.id, await readJson(request), actor.id, requestId) }, 200, requestId);
			if (pathname === "/api/v1/admin/vehicles") {
				if (request.method === "GET") return json({ items: await listVehicles(env.DB) }, 200, requestId);
				if (request.method === "POST") return json({ item: await createVehicle(env.DB, await readJson(request), actor.id, requestId) }, 201, requestId);
			}
			const vehicleParams = match(pathname, "/api/v1/admin/vehicles/:id");
			if (request.method === "PATCH" && vehicleParams) return json({ item: await updateVehicle(env.DB, vehicleParams.id, await readJson(request), actor.id, requestId) }, 200, requestId);
			if (request.method === "POST" && pathname === "/api/v1/admin/bookings") return await createBooking(request, env, requestId);
			const bookingDetailParams = match(pathname, "/api/v1/admin/bookings/:reference");
			if (request.method === "GET" && bookingDetailParams) return json(await handleAdminBookingDetail(env, bookingDetailParams.reference), 200, requestId);
			if (request.method === "PATCH" && bookingDetailParams) return json(await editBooking(env.DB, bookingDetailParams.reference, await readJson(request), actor.id, requestId), 200, requestId);
			const bookingAssignmentParams = match(pathname, "/api/v1/admin/bookings/:reference/assignment");
			if (request.method === "PATCH" && bookingAssignmentParams) return json(await assignBooking(env.DB, bookingAssignmentParams.reference, await readJson(request), actor.id, requestId), 200, requestId);
			const bookingStatusParams = match(pathname, "/api/v1/admin/bookings/:reference/status");
			if (request.method === "PATCH" && bookingStatusParams) return json(await handleAdminBookingStatus(request, env, bookingStatusParams.reference, actor.id, requestId), 200, requestId);
			const bookingNoteParams = match(pathname, "/api/v1/admin/bookings/:reference/notes");
			if (request.method === "POST" && bookingNoteParams) {
				const booking = await getBookingByReference(env.DB, bookingNoteParams.reference);
				if (!booking) throw new AppError("NOT_FOUND", "Booking not found.");
				const body = await readJson(request);
				return json(await addNote(env.DB, "booking", booking.id, body.body ?? "", actor.id), 201, requestId);
			}
			if (request.method === "GET" && pathname === "/api/v1/admin/contacts") return json(await handleAdminContactsList(request, env), 200, requestId);
			const contactDetailParams = match(pathname, "/api/v1/admin/contacts/:id");
			if (request.method === "GET" && contactDetailParams) return json(await handleAdminContactDetail(env, contactDetailParams.id), 200, requestId);
			const contactStatusParams = match(pathname, "/api/v1/admin/contacts/:id/status");
			if (request.method === "PATCH" && contactStatusParams) return json(await handleAdminContactStatus(request, env, contactStatusParams.id, actor.id, requestId), 200, requestId);
			const contactNoteParams = match(pathname, "/api/v1/admin/contacts/:id/notes");
			if (request.method === "POST" && contactNoteParams) {
				const detail = await handleAdminContactDetail(env, contactNoteParams.id);
				const body = await readJson(request);
				return json(await addNote(env.DB, "contact", detail.contact.id, body.body ?? "", actor.id), 201, requestId);
			}
			throw new AppError("NOT_FOUND", "Admin route not found.");
		}
		throw new AppError("NOT_FOUND", "Not found.");
	} catch (error) {
		return errorResponse(error, requestId);
	}
}
//#endregion
export { handleApi as t };
