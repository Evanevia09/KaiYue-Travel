globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as _id__exports } from "./_id__Djan-Z50.mjs";
//#region \0virtual:astro:page:src/pages/special-offers/[id]@_@astro
var page = () => _id__exports;
//#endregion
export { page };
