globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll } from "./rolldown-runtime_BDykq6kg.mjs";
import { n as createAdminSessionAuth, t as allowedAdminEmails } from "./admin-session_CiBIbtuM.mjs";
import { d as AppError } from "./src_BRRiv8WF.mjs";
import { a as assertLiveAdminSurface, l as isLocalAdminSurface, m as temporaryPasswordConfigured, o as emailSignupAllowed, p as passwordAdminAllowed, s as forbiddenResponse } from "./admin-gate_CU-fRGZ7.mjs";
import { i as errorResponse, l as requestIdFrom, r as clientIp, t as enforceAdminSignInRateLimit } from "./rate-limit_BIbPyTWs.mjs";
import { env } from "cloudflare:workers";
//#region src/pages/api/auth/[...all].ts
var ____all__exports = /* @__PURE__ */ __exportAll({
	ALL: () => ALL,
	prerender: () => false
});
function equalSecret(input, expected) {
	if (input.length !== expected.length) return false;
	let difference = 0;
	for (let index = 0; index < expected.length; index++) difference |= input.charCodeAt(index) ^ expected.charCodeAt(index);
	return difference === 0;
}
var ALL = async ({ request }) => {
	const pathname = new URL(request.url).pathname;
	const requestId = requestIdFrom(request);
	try {
		assertLiveAdminSurface(env, pathname, request);
	} catch {
		return forbiddenResponse();
	}
	if (!passwordAdminAllowed(env, request)) return forbiddenResponse();
	if (!isLocalAdminSurface(env, request) && !temporaryPasswordConfigured(env)) return forbiddenResponse();
	const signup = pathname === "/api/auth/sign-up/email";
	if (pathname === "/api/auth/sign-in/email" && request.method === "POST") try {
		await enforceAdminSignInRateLimit(env.DB, clientIp(request));
	} catch (error) {
		return errorResponse(error, requestId);
	}
	if (signup) {
		if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });
		const token = env.ADMIN_SETUP_TOKEN;
		if (!emailSignupAllowed(env, request) || !token || token.length < 32 || !equalSecret(request.headers.get("x-admin-setup-token") ?? "", token)) return new Response("Not found", { status: 404 });
		if (request.headers.get("origin") !== new URL(env.PUBLIC_SITE_URL || request.url).origin) return new Response("Forbidden", { status: 403 });
		if (((await env.DB.prepare("SELECT COUNT(*) AS count FROM \"user\"").first())?.count ?? 0) > 0) return new Response("Setup already completed", { status: 409 });
		let body;
		try {
			body = await request.clone().json();
		} catch {
			return new Response("Invalid JSON", { status: 400 });
		}
		if (typeof body.email !== "string" || !allowedAdminEmails(env).has(body.email.trim().toLowerCase())) return new Response("Forbidden", { status: 403 });
	}
	try {
		return createAdminSessionAuth(env, signup, request).handler(request);
	} catch (error) {
		if (error instanceof AppError) return errorResponse(error, requestId);
		throw error;
	}
};
//#endregion
//#region \0virtual:astro:page:src/pages/api/auth/[...all]@_@ts
var page = () => ____all__exports;
//#endregion
export { page };
