globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, K as createAstro, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, l as prefixedLabel, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, r as formatWhen, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
import { n as adminSummary } from "./admin_DYkS9rEP.mjs";
import { env } from "cloudflare:workers";
//#region src/components/admin/DashboardPanel.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function DashboardPanel({ initial, locale }) {
	const [data, setData] = (0, import_react.useState)(initial ?? null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (initial) return;
		adminFetch("/api/v1/admin/summary", { locale }).then(setData).catch((err) => setError(localizeCaughtError(err, locale)));
	}, [initial, locale]);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		children: error
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "dash.loading") });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "muted",
			children: t(locale, "dash.timezone", { timezone: data.timezone })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "admin-kpis",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "admin-kpi admin-kpi--accent",
					href: "/admin/bookings?status=enquiry",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "admin-kpi__label",
							children: t(locale, "dash.newToday")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: data.newBookingsToday }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "dash.bookingEnquiries") })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "admin-kpi",
					href: "/admin/bookings?status=assigned",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "admin-kpi__label",
							children: t(locale, "dash.upcoming")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: data.assignedUpcoming }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "dash.assignedBookings") })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "admin-kpi",
					href: "/admin/bookings?status=completed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "admin-kpi__label",
							children: t(locale, "dash.thisMonth")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: data.completedThisMonth }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "dash.completed") })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "admin-kpi",
					href: "/admin/bookings?status=cancelled",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "admin-kpi__label",
							children: t(locale, "dash.thisMonth")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: data.cancelledThisMonth }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "dash.cancelled") })
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "admin-dashboard-grid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "admin-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "admin-card__heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "admin-kpi__label",
						children: t(locale, "dash.operations")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "dash.recent") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/admin/bookings",
						children: t(locale, "dash.viewAll")
					})]
				}), data.recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "dash.empty") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "admin-recent-list",
					children: data.recent.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `/admin/bookings/${item.reference}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.pickupLocation }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.destination ? ` → ${item.destination}` : ` · ${t(locale, "dash.hourly")}` })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge badge--${item.status}`,
							children: prefixedLabel(locale, "status", item.status)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: formatWhen(item.pickupAt, locale) })] })]
					}, item.reference))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "admin-card admin-card--compact",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "admin-kpi__label",
						children: t(locale, "dash.attention")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: data.notificationFailures }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "dash.emailReview") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: data.newInquiries }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/admin/contacts?status=new",
						children: t(locale, "dash.generalEnquiries")
					}) })
				]
			})]
		})
	] });
}
//#endregion
//#region src/pages/admin/index.astro
var admin_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Index,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Index = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Index;
	const locale = adminLocaleFromCookies(Astro.cookies);
	let summary = null;
	try {
		summary = await adminSummary(env);
	} catch {
		summary = null;
	}
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.dashboard",
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "DashboardPanel", DashboardPanel, {
		"client:load": true,
		"locale": locale,
		"initial": summary,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/DashboardPanel.tsx",
		"client:component-export": "DashboardPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/index.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/index.astro";
var $$url = "/admin";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/index@_@astro
var page = () => admin_exports;
//#endregion
export { page };
