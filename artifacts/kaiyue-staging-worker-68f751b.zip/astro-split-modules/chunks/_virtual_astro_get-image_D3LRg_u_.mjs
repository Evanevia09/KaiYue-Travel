globalThis.process ??= {};
globalThis.process.env ??= {};
import { c as createConsoleLogger } from "./sequence_Cusz3XDW.mjs";
import { t as level } from "./_virtual_astro_logger_DARKlz-P.mjs";
import { i as getImage$1 } from "./assets_8MzTfRju.mjs";
//#region \0virtual:astro:get-image
var imageConfig = {
	"endpoint": {
		"route": "/_image",
		"entrypoint": "@astrojs/cloudflare/image-passthrough-endpoint"
	},
	"service": {
		"entrypoint": "astro/assets/services/noop",
		"config": {}
	},
	"dangerouslyProcessSVG": false,
	"domains": [],
	"remotePatterns": [],
	"responsiveStyles": false
};
Object.defineProperty(imageConfig, "assetQueryParams", {
	value: void 0,
	enumerable: false,
	configurable: true
});
var _astroLogger = createConsoleLogger({ level });
var _runtimeLogger = {
	info: (message) => _astroLogger.info(null, message),
	warn: (message) => _astroLogger.warn(null, message),
	error: (message) => _astroLogger.error(null, message)
};
var getImage = async (options) => await getImage$1(options, imageConfig, _runtimeLogger);
//#endregion
export { getImage };
