globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll } from "./rolldown-runtime_BDykq6kg.mjs";
import { t as handleApi } from "./router_2SeUne1g.mjs";
import { env } from "cloudflare:workers";
//#region src/pages/api/admin/[...path].ts
var ____path__exports = /* @__PURE__ */ __exportAll({
	ALL: () => ALL,
	prerender: () => false
});
var ALL = async ({ request, locals }) => {
	return handleApi(request, env, locals.requestId);
};
//#endregion
//#region \0virtual:astro:page:src/pages/api/admin/[...path]@_@ts
var page = () => ____path__exports;
//#endregion
export { page };
