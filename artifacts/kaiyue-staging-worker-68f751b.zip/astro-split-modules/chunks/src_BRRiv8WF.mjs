globalThis.process ??= {};
globalThis.process.env ??= {};
import { Ft as _enum, Gt as number, Jt as preprocess, Kt as object, Rt as boolean, Ut as literal, Zt as string } from "./sequence_Cusz3XDW.mjs";
//#region ../../packages/contracts/src/phone.ts
function normalizePhone(input) {
	const trimmed = input.trim();
	const plus = trimmed.startsWith("+");
	const digits = trimmed.replace(/\D/g, "");
	return plus ? `+${digits}` : digits;
}
function isPlausiblePhone(normalized) {
	const digits = normalized.replace(/\D/g, "");
	return digits.length >= 8 && digits.length <= 15;
}
//#endregion
//#region ../../packages/contracts/src/booking.ts
var SERVICE_TYPES = [
	"airport_transfer",
	"hotel_transfer",
	"point_to_point",
	"hourly_charter",
	"city_tour",
	"sightseeing",
	"corporate",
	"custom"
];
var VEHICLE_PREFERENCES = [
	"no_preference",
	"executive_van",
	"sedan"
];
var BOOKING_SOURCE_MODES = [
	"embedded",
	"bottom-sheet",
	"page"
];
var COMMUNICATION_CHANNELS = ["whatsapp", "email"];
function isMacauTourGuidePackage(tourPackageId) {
	return tourPackageId === "half-day" || tourPackageId === "full-day";
}
var optionalText$1 = (max) => string().trim().max(max).optional().transform((value) => value && value.length > 0 ? value : void 0);
var bookingCreateSchema = object({
	serviceType: _enum(SERVICE_TYPES),
	pickupLocation: string().trim().min(2).max(160),
	destination: optionalText$1(160),
	pickupAt: string().datetime({ offset: true }),
	returnAt: string().datetime({ offset: true }).optional(),
	passengerCount: number().int().min(1).max(14),
	durationHours: number().int().min(2).max(12).optional(),
	luggageCount: number().int().min(0).max(20).optional(),
	handCarryCount: number().int().min(0).max(20).optional(),
	vehiclePreference: _enum(VEHICLE_PREFERENCES).optional(),
	communicationChannel: _enum(COMMUNICATION_CHANNELS),
	contactName: optionalText$1(80),
	phone: optionalText$1(32),
	email: string().trim().email().max(160).optional().or(literal("")).transform((value) => value ? value : void 0),
	company: optionalText$1(120),
	message: string().trim().max(800).default(""),
	notes: optionalText$1(800),
	tourPackageId: string().trim().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(80).optional(),
	tourPackageTitle: string().trim().min(1).max(160).optional(),
	tourDurationHours: number().int().min(1).max(24).optional(),
	offerId: string().uuid().optional(),
	offerTitle: string().trim().min(1).max(160).optional(),
	tourGuideRequested: boolean().optional(),
	locale: string().trim().min(2).max(16).default("en"),
	sourcePage: string().trim().min(1).max(200),
	sourceTrigger: string().trim().min(1).max(80),
	sourceMode: _enum(BOOKING_SOURCE_MODES),
	privacyAccepted: boolean().optional(),
	website: string().max(0).optional()
}).superRefine((value, ctx) => {
	if (destinationRequired(value.serviceType) && !value.destination) ctx.addIssue({
		code: "custom",
		path: ["destination"],
		message: "Enter a destination."
	});
	if (value.serviceType === "city_tour" && value.returnAt) ctx.addIssue({
		code: "custom",
		path: ["returnAt"],
		message: "City tours do not include a return time."
	});
	if (value.serviceType === "city_tour" && (!value.tourPackageId || !value.tourPackageTitle)) ctx.addIssue({
		code: "custom",
		path: ["tourPackageId"],
		message: "Choose a tour package."
	});
	if (value.offerId && !value.offerTitle) ctx.addIssue({
		code: "custom",
		path: ["offerTitle"],
		message: "Choose a published special offer."
	});
	if (value.offerTitle && !value.offerId) ctx.addIssue({
		code: "custom",
		path: ["offerId"],
		message: "Choose a published special offer."
	});
	if (isMacauTourGuidePackage(value.tourPackageId) && !value.offerId && value.tourGuideRequested == null) ctx.addIssue({
		code: "custom",
		path: ["tourGuideRequested"],
		message: "Choose whether you would like a professional Macau tour guide."
	});
	if (value.serviceType === "hourly_charter" && value.durationHours == null) ctx.addIssue({
		code: "custom",
		path: ["durationHours"],
		message: "Choose how many hours you need."
	});
	const pickup = Date.parse(value.pickupAt);
	if (Number.isNaN(pickup)) {
		ctx.addIssue({
			code: "custom",
			path: ["pickupAt"],
			message: "Enter a valid pickup time."
		});
		return;
	}
	if (value.returnAt) {
		const returnAt = Date.parse(value.returnAt);
		if (Number.isNaN(returnAt) || returnAt <= pickup) ctx.addIssue({
			code: "custom",
			path: ["returnAt"],
			message: "Return time must be after pickup."
		});
	}
	if (value.communicationChannel === "email" && !value.contactName) ctx.addIssue({
		code: "custom",
		path: ["contactName"],
		message: "Enter your name."
	});
	if (value.communicationChannel === "email" && !value.email) ctx.addIssue({
		code: "custom",
		path: ["email"],
		message: "Enter your email address."
	});
	if (value.communicationChannel === "whatsapp" && !value.phone) ctx.addIssue({
		code: "custom",
		path: ["phone"],
		message: "Enter your WhatsApp number."
	});
	if (value.phone) {
		if (!isPlausiblePhone(normalizePhone(value.phone))) ctx.addIssue({
			code: "custom",
			path: ["phone"],
			message: "Enter a valid phone number with country code."
		});
	}
}).transform((value) => ({
	...value,
	phone: value.phone ? normalizePhone(value.phone) : void 0,
	phoneDisplay: value.phone?.trim(),
	email: value.email?.toLowerCase()
}));
function destinationRequired(serviceType) {
	return serviceType !== "hourly_charter" && serviceType !== "city_tour";
}
function validatePickupNotice(pickupAt, noticeHours, now = /* @__PURE__ */ new Date()) {
	const pickup = Date.parse(pickupAt);
	if (Number.isNaN(pickup)) return "Enter a valid pickup time.";
	if (pickup < now.getTime() + noticeHours * 60 * 60 * 1e3) return noticeHours > 0 ? `Pickup must be at least ${noticeHours} hours from now.` : "Pickup must be in the future.";
}
//#endregion
//#region ../../packages/contracts/src/contact.ts
var INQUIRY_TYPES = [
	"general",
	"corporate",
	"partnership",
	"media"
];
var optionalText = (max) => string().trim().max(max).optional().transform((value) => value && value.length > 0 ? value : void 0);
var contactCreateSchema = object({
	inquiryType: _enum(INQUIRY_TYPES),
	name: string().trim().min(2).max(80),
	phone: string().trim().min(8).max(32),
	email: string().trim().email().max(160).optional().or(literal("")).transform((value) => value ? value : void 0),
	company: optionalText(120),
	message: string().trim().min(10).max(2e3),
	locale: string().trim().min(2).max(16).default("en"),
	sourcePage: string().trim().min(1).max(200),
	privacyAccepted: literal(true),
	website: string().max(0).optional()
}).superRefine((value, ctx) => {
	if (value.inquiryType === "corporate" && !value.company) ctx.addIssue({
		code: "custom",
		path: ["company"],
		message: "Company name is required for corporate inquiries."
	});
	if (!isPlausiblePhone(normalizePhone(value.phone))) ctx.addIssue({
		code: "custom",
		path: ["phone"],
		message: "Enter a valid phone number with country code."
	});
}).transform((value) => ({
	...value,
	phone: normalizePhone(value.phone),
	phoneDisplay: value.phone.trim(),
	email: value.email?.toLowerCase()
}));
//#endregion
//#region ../../packages/contracts/src/errors.ts
var AppError = class extends Error {
	code;
	status;
	fields;
	expose;
	constructor(code, message, options) {
		super(message, { cause: options?.cause });
		this.name = "AppError";
		this.code = code;
		this.status = options?.status ?? statusForCode(code);
		this.fields = options?.fields;
		this.expose = options?.expose ?? true;
	}
};
function statusForCode(code) {
	switch (code) {
		case "VALIDATION_FAILED": return 422;
		case "UNAUTHORIZED": return 401;
		case "FORBIDDEN": return 403;
		case "NOT_FOUND": return 404;
		case "CONFLICT":
		case "IDEMPOTENCY_CONFLICT":
		case "INVALID_TRANSITION": return 409;
		case "RATE_LIMITED": return 429;
		case "UNAVAILABLE": return 503;
		default: return 500;
	}
}
function toErrorBody(error, requestId) {
	return { error: {
		code: error.code,
		message: error.expose ? error.message : "Something went wrong. Please try again.",
		...error.fields ? { fields: error.fields } : {},
		requestId
	} };
}
var OFFER_DESCRIPTION_MAX = 2e3;
var OFFER_TERMS_MAX = 4e3;
var OFFER_IMAGE_MAX_BYTES = 5242880;
var OFFER_ORIGINAL_MAX_BYTES = 26214400;
var OFFER_IMAGE_MAX_EDGE = 1600;
var OFFER_IMAGE_CACHE_SECONDS = 31536e3;
var OFFER_IMAGE_TYPES = [
	"image/jpeg",
	"image/png",
	"image/webp"
];
function scaledOfferImageSize(width, height, maxEdge) {
	const longEdge = Math.max(width, height);
	if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return {
		width: maxEdge,
		height: Math.round(maxEdge * .68)
	};
	if (longEdge <= maxEdge) return {
		width: Math.round(width),
		height: Math.round(height)
	};
	const scale = maxEdge / longEdge;
	return {
		width: Math.max(1, Math.round(width * scale)),
		height: Math.max(1, Math.round(height * scale))
	};
}
var emptyToUndefined = (value) => {
	if (value == null) return void 0;
	if (typeof value === "string" && value.trim() === "") return void 0;
	return value;
};
var offerWriteSchema = object({
	title: string().trim().min(1).max(120),
	description: string().trim().min(1).max(OFFER_DESCRIPTION_MAX),
	priceFrom: preprocess(emptyToUndefined, number().positive().finite().max(1e6).optional()),
	terms: preprocess(emptyToUndefined, string().trim().max(OFFER_TERMS_MAX).optional())
});
function isOfferReady(offer) {
	return offer.title.trim().length > 0 && offer.description.trim().length > 0 && offer.photos.length > 0 && offer.photos.some((photo) => photo.isMain);
}
function isCompleteOffer(offer) {
	return offer.status === "published" && isOfferReady(offer);
}
var SERVICE_LABELS = {
	airport_transfer: "Airport transfer",
	hotel_transfer: "Hotel transfer",
	point_to_point: "Point to point",
	hourly_charter: "Hourly charter",
	city_tour: "City tour",
	sightseeing: "Macau sightseeing",
	corporate: "Corporate transport",
	custom: "Custom request"
};
var INQUIRY_LABELS = {
	general: "General inquiry",
	corporate: "Corporate / B2B",
	partnership: "Partnership",
	media: "Media"
};
function getPublicConfig(overrides) {
	return {
		timezone: overrides?.timezone ?? "Asia/Macau",
		locale: "en",
		noticeHours: overrides?.noticeHours ?? 24,
		serviceTypes: SERVICE_TYPES,
		inquiryTypes: INQUIRY_TYPES,
		serviceLabels: SERVICE_LABELS,
		inquiryLabels: INQUIRY_LABELS,
		confirmationCopy: "Your request has been received and is awaiting confirmation from our team. This is not a confirmed booking."
	};
}
//#endregion
export { validatePickupNotice as _, OFFER_IMAGE_TYPES as a, isOfferReady as c, AppError as d, toErrorBody as f, isMacauTourGuidePackage as g, destinationRequired as h, OFFER_IMAGE_MAX_EDGE as i, offerWriteSchema as l, bookingCreateSchema as m, OFFER_IMAGE_CACHE_SECONDS as n, OFFER_ORIGINAL_MAX_BYTES as o, contactCreateSchema as p, OFFER_IMAGE_MAX_BYTES as r, isCompleteOffer as s, getPublicConfig as t, scaledOfferImageSize as u };
