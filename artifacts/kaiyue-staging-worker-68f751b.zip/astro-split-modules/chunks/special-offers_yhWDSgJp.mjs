globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as $$SpecialOffers$1 } from "./special-offers_j9OPXfni.mjs";
//#region src/pages/[locale]/special-offers.astro
var special_offers_exports = /* @__PURE__ */ __exportAll({
	default: () => $$SpecialOffers,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
var $$SpecialOffers = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "SpecialOffers", $$SpecialOffers$1, {})}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/[locale]/special-offers.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/[locale]/special-offers.astro";
var $$url = "/[locale]/special-offers";
//#endregion
//#region \0virtual:astro:page:src/pages/[locale]/special-offers@_@astro
var page = () => special_offers_exports;
//#endregion
export { page };
