globalThis.process ??= {};
globalThis.process.env ??= {};
//#region ../../packages/contracts/src/ids.ts
var REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function createRequestId() {
	return `req_${crypto.randomUUID().replaceAll("-", "").slice(0, 20)}`;
}
function createIdempotencyKey() {
	return crypto.randomUUID();
}
function createPublicReference(prefix) {
	const bytes = /* @__PURE__ */ new Uint8Array(8);
	crypto.getRandomValues(bytes);
	return `${prefix}-${Array.from(bytes, (byte) => REFERENCE_ALPHABET[byte % 32]).join("")}`;
}
function createBookingReference() {
	return createPublicReference("KY");
}
function createContactReference() {
	return createPublicReference("INQ");
}
async function sha256Hex(value) {
	const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
	return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
//#endregion
export { sha256Hex as a, createRequestId as i, createContactReference as n, createIdempotencyKey as r, createBookingReference as t };
