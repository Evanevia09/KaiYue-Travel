globalThis.process ??= {};
globalThis.process.env ??= {};
//#region src/lib/i18n.ts
var localeTags = {
	en: "en",
	pt: "pt-PT",
	"zh-Hant": "zh-Hant"
};
var localeNames = {
	en: "English",
	pt: "Português",
	"zh-Hant": "繁體中文"
};
function localeFromPath(pathname) {
	const first = pathname.split("/")[1];
	return first === "pt" || first === "zh-Hant" ? first : "en";
}
function stripLocale(pathname) {
	const locale = localeFromPath(pathname);
	if (locale === "en") return pathname;
	return pathname.slice(locale.length + 1) || "/";
}
function localePath(pathname, locale) {
	const base = stripLocale(pathname);
	if (locale === "en") return base;
	return `/${locale}${base === "/" ? "" : base}`;
}
//#endregion
export { stripLocale as a, localeTags as i, localeNames as n, localePath as r, localeFromPath as t };
