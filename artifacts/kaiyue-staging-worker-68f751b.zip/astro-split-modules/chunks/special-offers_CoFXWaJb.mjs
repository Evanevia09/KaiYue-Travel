globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as special_offers_exports } from "./special-offers_j9OPXfni.mjs";
//#region \0virtual:astro:page:src/pages/special-offers@_@astro
var page = () => special_offers_exports;
//#endregion
export { page };
