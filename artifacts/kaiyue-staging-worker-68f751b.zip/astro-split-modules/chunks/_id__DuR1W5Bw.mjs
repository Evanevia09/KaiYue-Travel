globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, K as createAstro, M as renderTemplate, N as maybeRenderHead } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import "./src_BRRiv8WF.mjs";
import { i as CONTACT_TRANSITIONS } from "./status_WsaHno69.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, l as prefixedLabel, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, r as formatWhen, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
//#region src/components/admin/ContactDetailPanel.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function ContactDetailPanel({ id, locale }) {
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	async function load() {
		setDetail(await adminFetch(`/api/v1/admin/contacts/${id}`, { locale }));
	}
	(0, import_react.useEffect)(() => {
		load().catch((err) => setError(localizeCaughtError(err, locale)));
	}, [id, locale]);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		children: error
	});
	if (!detail) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "contact.loading") });
	const next = CONTACT_TRANSITIONS[detail.contact.status] ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `badge badge--${detail.contact.status}`,
					children: prefixedLabel(locale, "status", detail.contact.status)
				}),
				" ",
				"· ",
				prefixedLabel(locale, "inquiry", detail.contact.inquiryType)
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				detail.contact.name,
				detail.contact.company ? ` · ${detail.contact.company}` : "",
				" · ",
				detail.contact.phone
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: detail.contact.message }),
			next.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn--secondary",
				onClick: () => {
					adminFetch(`/api/v1/admin/contacts/${id}/status`, {
						method: "PATCH",
						locale,
						body: JSON.stringify({ status })
					}).then(() => load()).catch((err) => setError(localizeCaughtError(err, locale)));
				},
				children: t(locale, "contact.mark", { status: prefixedLabel(locale, "status", status) })
			}, status)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "form",
				onSubmit: (event) => {
					event.preventDefault();
					adminFetch(`/api/v1/admin/contacts/${id}/notes`, {
						method: "POST",
						locale,
						body: JSON.stringify({ body: note })
					}).then(() => {
						setNote("");
						return load();
					}).catch((err) => setError(localizeCaughtError(err, locale)));
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "contact-note",
						children: t(locale, "contact.note")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "contact-note",
						value: note,
						onChange: (event) => setNote(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn btn--secondary",
						children: t(locale, "contact.saveNote")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: detail.notes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				item.body,
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "muted",
					children: formatWhen(item.created_at, locale)
				})
			] }, item.id)) })
		]
	});
}
//#endregion
//#region src/pages/admin/contacts/[id].astro
var _id__exports = /* @__PURE__ */ __exportAll({
	default: () => $$Id,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Id = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Id;
	const locale = adminLocaleFromCookies(Astro.cookies);
	const id = Astro.params.id ?? "";
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.inquiry",
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<p><a href="/admin/contacts">${t(locale, "contacts.back")}</a></p>${renderComponent($$result, "ContactDetailPanel", ContactDetailPanel, {
		"client:load": true,
		"locale": locale,
		"id": id,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/ContactDetailPanel.tsx",
		"client:component-export": "ContactDetailPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/contacts/[id].astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/contacts/[id].astro";
var $$url = "/admin/contacts/[id]";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/contacts/[id]@_@astro
var page = () => _id__exports;
//#endregion
export { page };
