globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, K as createAstro, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, l as prefixedLabel, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, r as formatWhen, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
//#region src/components/admin/ContactsPanel.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function ContactsPanel({ locale, initialStatus = "" }) {
	const [status, setStatus] = (0, import_react.useState)(initialStatus);
	const [items, setItems] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const query = status ? `?status=${encodeURIComponent(status)}` : "";
		adminFetch(`/api/v1/admin/contacts${query}`, { locale }).then((data) => setItems(data.items)).catch((err) => setError(localizeCaughtError(err, locale)));
	}, [status, locale]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "filters",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
				t(locale, "contacts.status"),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: status,
					onChange: (event) => setStatus(event.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: t(locale, "contacts.all")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "new",
							children: t(locale, "status.new")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "replied",
							children: t(locale, "status.replied")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "closed",
							children: t(locale, "status.closed")
						})
					]
				})
			] })
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "alert",
			children: error
		}) : null,
		items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "contacts.loading") }) : null,
		items?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "contacts.empty") }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: items?.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: `/admin/contacts/${item.id}`,
				children: item.reference
			}),
			" ·",
			" ",
			prefixedLabel(locale, "inquiry", item.inquiryType),
			" · ",
			item.name,
			item.company ? ` / ${item.company}` : "",
			" · ",
			formatWhen(item.createdAt, locale),
			" ·",
			" ",
			prefixedLabel(locale, "status", item.status)
		] }, item.id)) })
	] });
}
//#endregion
//#region src/pages/admin/contacts/index.astro
var contacts_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Index,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Index = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Index;
	const locale = adminLocaleFromCookies(Astro.cookies);
	const status = Astro.url.searchParams.get("status") ?? "";
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.contacts",
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "ContactsPanel", ContactsPanel, {
		"client:load": true,
		"locale": locale,
		"initialStatus": status,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/ContactsPanel.tsx",
		"client:component-export": "ContactsPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/contacts/index.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/contacts/index.astro";
var $$url = "/admin/contacts";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/contacts/index@_@astro
var page = () => contacts_exports;
//#endregion
export { page };
