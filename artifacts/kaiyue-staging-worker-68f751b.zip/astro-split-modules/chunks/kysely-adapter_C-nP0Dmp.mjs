globalThis.process ??= {};
globalThis.process.env ??= {};
import { r as createKyselyAdapter, s as kyselyAdapter } from "./admin-session_CiBIbtuM.mjs";
export { createKyselyAdapter, kyselyAdapter };
