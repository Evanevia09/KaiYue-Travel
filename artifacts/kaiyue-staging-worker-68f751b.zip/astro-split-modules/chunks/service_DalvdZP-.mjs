globalThis.process ??= {};
globalThis.process.env ??= {};
import { a as OFFER_IMAGE_TYPES, c as isOfferReady, d as AppError, l as offerWriteSchema, s as isCompleteOffer } from "./src_BRRiv8WF.mjs";
import { i as run, r as nowIso, t as all } from "./db_BJi_UM06.mjs";
//#region src/lib/server/offers/images.ts
var SIGNATURES = {
	"image/jpeg": [
		255,
		216,
		255
	],
	"image/png": [
		137,
		80,
		78,
		71,
		13,
		10,
		26,
		10
	]
};
function startsWith(bytes, signature) {
	return signature.every((value, index) => bytes[index] === value);
}
function isWebp(bytes) {
	if (bytes.length < 12) return false;
	const header = new TextDecoder().decode(bytes.slice(0, 4));
	const format = new TextDecoder().decode(bytes.slice(8, 12));
	return header === "RIFF" && format === "WEBP";
}
function looksLikeSvg(bytes) {
	const head = new TextDecoder().decode(bytes.slice(0, 256)).replace(/^\uFEFF/, "").trimStart().toLowerCase();
	return head.startsWith("<svg") || head.startsWith("<?xml");
}
function detectImageType(bytes) {
	if (looksLikeSvg(bytes)) return null;
	if (startsWith(bytes, SIGNATURES["image/jpeg"])) return "image/jpeg";
	if (startsWith(bytes, SIGNATURES["image/png"])) return "image/png";
	if (isWebp(bytes)) return "image/webp";
	return null;
}
function assertOfferImage(bytes, declaredType) {
	if (bytes.byteLength === 0) throw new AppError("VALIDATION_FAILED", "Choose a JPEG, PNG, or WebP image.", { fields: { photo: "Choose a JPEG, PNG, or WebP image." } });
	if (bytes.byteLength > 5242880) throw new AppError("VALIDATION_FAILED", "Each photo must be 5 MB or smaller.", { fields: { photo: "Each photo must be 5 MB or smaller." } });
	const detected = detectImageType(bytes);
	const mime = declaredType.split(";")[0]?.trim().toLowerCase() ?? "";
	if (!detected || !OFFER_IMAGE_TYPES.includes(mime) || detected !== mime) throw new AppError("VALIDATION_FAILED", "Only JPEG, PNG, or WebP files are accepted.", { fields: { photo: "Only JPEG, PNG, or WebP files are accepted." } });
	return detected;
}
async function hashOfferImage(bytes) {
	const digest = await crypto.subtle.digest("SHA-256", Uint8Array.from(bytes));
	return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("").slice(0, 20);
}
function offerObjectKey(offerId, photoId, contentHash, contentType, variant = "full") {
	return `offers/${offerId}/${photoId}/${contentHash}${variant === "thumb" ? ".thumb" : ""}.${contentType === "image/jpeg" ? "jpg" : contentType === "image/png" ? "png" : "webp"}`;
}
function parseOfferImageDimension(value) {
	if (typeof value !== "string" || value.trim() === "") return null;
	const parsed = Number(value);
	if (!Number.isInteger(parsed) || parsed < 1 || parsed > 2e4) return null;
	return parsed;
}
//#endregion
//#region src/lib/server/offers/objects.ts
function createMemoryObjectStore() {
	const objects = /* @__PURE__ */ new Map();
	return {
		async put(key, bytes, contentType) {
			objects.set(key, {
				body: bytes,
				contentType
			});
		},
		async get(key) {
			const value = objects.get(key);
			return value ? {
				body: value.body,
				contentType: value.contentType
			} : null;
		},
		async delete(key) {
			objects.delete(key);
		},
		async deleteMany(keys) {
			for (const key of keys) objects.delete(key);
		}
	};
}
function createR2ObjectStore(bucket) {
	return {
		async put(key, bytes, contentType) {
			await bucket.put(key, bytes, { httpMetadata: { contentType } });
		},
		async get(key) {
			const object = await bucket.get(key);
			if (!object) return null;
			return {
				body: new Uint8Array(await object.arrayBuffer()),
				contentType: object.httpMetadata?.contentType || "application/octet-stream"
			};
		},
		async delete(key) {
			await bucket.delete(key);
		},
		async deleteMany(keys) {
			const unique = [...new Set(keys.filter(Boolean))];
			for (const key of unique) await bucket.delete(key);
		}
	};
}
//#endregion
//#region src/lib/server/offers/store.ts
function mapPhoto(row) {
	const contentHash = row.content_hash?.trim() || row.id;
	return {
		id: row.id,
		offerId: row.offer_id,
		objectKey: row.object_key,
		thumbObjectKey: row.thumb_object_key?.trim() || row.object_key,
		contentType: row.content_type,
		contentHash,
		isMain: row.is_main === 1,
		sortOrder: row.sort_order,
		width: row.width,
		height: row.height,
		byteSize: row.byte_size,
		createdAt: row.created_at
	};
}
function offerPhotoVersion(photo) {
	return photo.contentHash?.trim() || photo.id;
}
function offerPhotoObjectKeys(photo) {
	return [...new Set([photo.objectKey, photo.thumbObjectKey].filter(Boolean))];
}
function offerPhotoUrls(offerId, photo, options = {}) {
	const version = offerPhotoVersion(photo);
	const base = options.admin ? `/api/admin/offers/${offerId}/photos` : `/api/v1/offers/${offerId}/photos`;
	return {
		url: `${base}/${photo.id}/${version}`,
		thumbUrl: `${base}/${photo.id}/thumb/${version}`
	};
}
function mapOffer(row, photos) {
	return {
		id: row.id,
		status: row.status,
		title: row.title,
		description: row.description,
		priceFrom: row.price_from,
		terms: row.terms,
		createdAt: row.created_at,
		updatedAt: row.updated_at,
		photos: photos.sort((a, b) => a.sortOrder - b.sortOrder || a.createdAt.localeCompare(b.createdAt))
	};
}
function toAdminOffer(offer) {
	return {
		...offer,
		complete: isOfferReady(offer),
		photos: offer.photos.map((photo) => ({
			...photo,
			...offerPhotoUrls(offer.id, photo, { admin: true })
		}))
	};
}
function toPublicOffer(offer) {
	const main = offer.photos.find((photo) => photo.isMain) ?? offer.photos[0];
	const mainUrls = main ? offerPhotoUrls(offer.id, main) : null;
	return {
		id: offer.id,
		title: offer.title,
		description: offer.description,
		priceFrom: offer.priceFrom,
		terms: offer.terms ?? "",
		photos: offer.photos.map((photo) => ({
			id: photo.id,
			contentType: photo.contentType,
			isMain: photo.isMain,
			width: photo.width,
			height: photo.height,
			...offerPhotoUrls(offer.id, photo)
		})),
		mainPhotoUrl: mainUrls?.url ?? null,
		mainPhotoThumbUrl: mainUrls?.thumbUrl ?? null,
		mainPhotoWidth: main?.width ?? null,
		mainPhotoHeight: main?.height ?? null,
		updatedAt: offer.updatedAt
	};
}
function createMemoryOfferStore(seed = []) {
	const offers = new Map(seed.map((offer) => [offer.id, structuredClone(offer)]));
	const audits = [];
	const requireOffer = (id) => {
		const offer = offers.get(id);
		if (!offer) throw new AppError("NOT_FOUND", "Offer not found.");
		return offer;
	};
	return {
		async list() {
			return [...offers.values()].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
		},
		async listPublished() {
			return (await this.list()).filter((offer) => offer.status === "published");
		},
		async get(id) {
			const offer = offers.get(id);
			return offer ? structuredClone(offer) : null;
		},
		async create(input) {
			const now = nowIso();
			const offer = {
				id: crypto.randomUUID(),
				status: "draft",
				title: input.title,
				description: input.description,
				priceFrom: input.priceFrom ?? null,
				terms: input.terms ?? null,
				createdAt: now,
				updatedAt: now,
				photos: []
			};
			offers.set(offer.id, offer);
			return structuredClone(offer);
		},
		async update(id, input) {
			const offer = requireOffer(id);
			offer.title = input.title;
			offer.description = input.description;
			offer.priceFrom = input.priceFrom ?? null;
			offer.terms = input.terms ?? null;
			offer.updatedAt = nowIso();
			return structuredClone(offer);
		},
		async setStatus(id, status, audit) {
			const offer = requireOffer(id);
			if (status === "published" && !isOfferReady(offer)) throw new AppError("VALIDATION_FAILED", "Publish requires a title, description, and a main photo.");
			offer.status = status;
			offer.updatedAt = nowIso();
			if (audit) audits.push({
				...audit,
				offerId: id,
				createdAt: nowIso()
			});
			return structuredClone(offer);
		},
		async delete(id) {
			const offer = requireOffer(id);
			offers.delete(id);
			return structuredClone(offer);
		},
		async addPhoto(offerId, photo) {
			const offer = requireOffer(offerId);
			const record = {
				id: photo.id ?? crypto.randomUUID(),
				offerId,
				objectKey: photo.objectKey,
				thumbObjectKey: photo.thumbObjectKey || photo.objectKey,
				contentType: photo.contentType,
				contentHash: photo.contentHash,
				isMain: photo.isMain || offer.photos.length === 0,
				sortOrder: offer.photos.length,
				width: photo.width ?? null,
				height: photo.height ?? null,
				byteSize: photo.byteSize ?? null,
				createdAt: nowIso()
			};
			if (record.isMain) offer.photos = offer.photos.map((item) => ({
				...item,
				isMain: false
			}));
			offer.photos.push(record);
			offer.updatedAt = nowIso();
			return structuredClone(offer);
		},
		async removePhoto(offerId, photoId) {
			const offer = requireOffer(offerId);
			const photo = offer.photos.find((item) => item.id === photoId);
			if (!photo) throw new AppError("NOT_FOUND", "Photo not found.");
			offer.photos = offer.photos.filter((item) => item.id !== photoId);
			if (photo.isMain && offer.photos[0]) offer.photos[0].isMain = true;
			offer.updatedAt = nowIso();
			return {
				offer: structuredClone(offer),
				objectKeys: offerPhotoObjectKeys(photo)
			};
		},
		async setMainPhoto(offerId, photoId) {
			const offer = requireOffer(offerId);
			if (!offer.photos.some((item) => item.id === photoId)) throw new AppError("NOT_FOUND", "Photo not found.");
			offer.photos = offer.photos.map((item) => ({
				...item,
				isMain: item.id === photoId
			}));
			offer.updatedAt = nowIso();
			return structuredClone(offer);
		},
		async recordAudit(input) {
			audits.push({
				...input,
				createdAt: nowIso()
			});
		}
	};
}
async function loadMany(db, status) {
	const rows = status ? await all(db, "SELECT * FROM offers WHERE status = ? ORDER BY updated_at DESC", status) : await all(db, "SELECT * FROM offers ORDER BY updated_at DESC");
	if (rows.length === 0) return [];
	const photoRows = status === "published" ? await all(db, `SELECT offer_photos.* FROM offer_photos
           INNER JOIN offers ON offers.id = offer_photos.offer_id
           WHERE offers.status = 'published'
           ORDER BY offer_photos.sort_order ASC, offer_photos.created_at ASC`) : await all(db, "SELECT * FROM offer_photos ORDER BY sort_order ASC, created_at ASC");
	const photosByOffer = /* @__PURE__ */ new Map();
	for (const photo of photoRows) {
		const list = photosByOffer.get(photo.offer_id) ?? [];
		list.push(mapPhoto(photo));
		photosByOffer.set(photo.offer_id, list);
	}
	return rows.map((row) => mapOffer(row, photosByOffer.get(row.id) ?? []));
}
function createD1OfferStore(db) {
	async function loadRow(id) {
		const [offerResult, photoResult] = await db.batch([db.prepare("SELECT * FROM offers WHERE id = ?").bind(id), db.prepare("SELECT * FROM offer_photos WHERE offer_id = ? ORDER BY sort_order ASC, created_at ASC").bind(id)]);
		return {
			row: (offerResult?.results)?.[0] ?? null,
			photos: (photoResult?.results ?? []).map(mapPhoto)
		};
	}
	async function load(id) {
		const { row, photos } = await loadRow(id);
		if (!row) throw new AppError("NOT_FOUND", "Offer not found.");
		return mapOffer(row, photos);
	}
	return {
		async list() {
			return loadMany(db);
		},
		async listPublished() {
			return loadMany(db, "published");
		},
		async get(id) {
			const { row, photos } = await loadRow(id);
			return row ? mapOffer(row, photos) : null;
		},
		async create(input) {
			const id = crypto.randomUUID();
			const now = nowIso();
			await run(db, `INSERT INTO offers (id, status, title, description, price_from, terms, created_at, updated_at)
         VALUES (?, 'draft', ?, ?, ?, ?, ?, ?)`, id, input.title, input.description, input.priceFrom ?? null, input.terms ?? null, now, now);
			return load(id);
		},
		async update(id, input) {
			const now = nowIso();
			if ((await run(db, `UPDATE offers SET title = ?, description = ?, price_from = ?, terms = ?, updated_at = ? WHERE id = ?`, input.title, input.description, input.priceFrom ?? null, input.terms ?? null, now, id)).meta.changes === 0) throw new AppError("NOT_FOUND", "Offer not found.");
			return load(id);
		},
		async setStatus(id, status, audit) {
			const current = await load(id);
			if (status === "published" && !isOfferReady(current)) throw new AppError("VALIDATION_FAILED", "Publish requires a title, description, and a main photo.");
			const now = nowIso();
			const statements = [db.prepare("UPDATE offers SET status = ?, updated_at = ? WHERE id = ?").bind(status, now, id)];
			if (audit) statements.push(db.prepare(`INSERT INTO offer_audit_events (id, offer_id, event_type, actor_id, from_value, to_value, request_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(crypto.randomUUID(), id, audit.eventType, audit.actorId, audit.fromValue ?? null, audit.toValue ?? null, audit.requestId, now));
			await db.batch(statements);
			return {
				...current,
				status,
				updatedAt: now
			};
		},
		async delete(id) {
			const current = await load(id);
			await run(db, "DELETE FROM offer_photos WHERE offer_id = ?", id);
			await run(db, "DELETE FROM offers WHERE id = ?", id);
			return current;
		},
		async addPhoto(offerId, photo) {
			const existing = await load(offerId);
			const id = photo.id ?? crypto.randomUUID();
			const isMain = photo.isMain || existing.photos.length === 0;
			if (isMain) await run(db, "UPDATE offer_photos SET is_main = 0 WHERE offer_id = ?", offerId);
			await run(db, `INSERT INTO offer_photos (
           id, offer_id, object_key, thumb_object_key, content_type, content_hash,
           is_main, sort_order, width, height, byte_size, created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, id, offerId, photo.objectKey, photo.thumbObjectKey || photo.objectKey, photo.contentType, photo.contentHash, isMain ? 1 : 0, existing.photos.length, photo.width ?? null, photo.height ?? null, photo.byteSize ?? null, nowIso());
			await run(db, "UPDATE offers SET updated_at = ? WHERE id = ?", nowIso(), offerId);
			return load(offerId);
		},
		async removePhoto(offerId, photoId) {
			const offer = await load(offerId);
			const photo = offer.photos.find((item) => item.id === photoId);
			if (!photo) throw new AppError("NOT_FOUND", "Photo not found.");
			await run(db, "DELETE FROM offer_photos WHERE id = ? AND offer_id = ?", photoId, offerId);
			if (photo.isMain) {
				const remaining = offer.photos.filter((item) => item.id !== photoId);
				if (remaining[0]) await run(db, "UPDATE offer_photos SET is_main = 1 WHERE id = ?", remaining[0].id);
			}
			await run(db, "UPDATE offers SET updated_at = ? WHERE id = ?", nowIso(), offerId);
			return {
				offer: await load(offerId),
				objectKeys: offerPhotoObjectKeys(photo)
			};
		},
		async setMainPhoto(offerId, photoId) {
			const offer = await load(offerId);
			if (!offer.photos.some((item) => item.id === photoId)) throw new AppError("NOT_FOUND", "Photo not found.");
			const now = nowIso();
			await db.batch([
				db.prepare("UPDATE offer_photos SET is_main = 0 WHERE offer_id = ?").bind(offerId),
				db.prepare("UPDATE offer_photos SET is_main = 1 WHERE id = ? AND offer_id = ?").bind(photoId, offerId),
				db.prepare("UPDATE offers SET updated_at = ? WHERE id = ?").bind(now, offerId)
			]);
			return {
				...offer,
				updatedAt: now,
				photos: offer.photos.map((item) => ({
					...item,
					isMain: item.id === photoId
				}))
			};
		},
		async recordAudit(input) {
			await run(db, `INSERT INTO offer_audit_events (id, offer_id, event_type, actor_id, from_value, to_value, request_id, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, crypto.randomUUID(), input.offerId, input.eventType, input.actorId, input.fromValue ?? null, input.toValue ?? null, input.requestId, nowIso());
		}
	};
}
//#endregion
//#region src/lib/server/offers/service.ts
function offerRuntime(env) {
	return {
		store: env.offerStore ?? (env.DB ? createD1OfferStore(env.DB) : createMemoryOfferStore()),
		objects: env.objectStore ?? (env.OFFERS_BUCKET ? createR2ObjectStore(env.OFFERS_BUCKET) : createMemoryObjectStore())
	};
}
function parseOfferWrite(input) {
	const parsed = offerWriteSchema.safeParse(input);
	if (!parsed.success) {
		const fields = {};
		for (const issue of parsed.error.issues) fields[issue.path.join(".") || "form"] ??= issue.message;
		throw new AppError("VALIDATION_FAILED", "Check the highlighted fields.", { fields });
	}
	return parsed.data;
}
async function listAdminOffers(env) {
	const { store } = offerRuntime(env);
	return { items: (await store.list()).map(toAdminOffer) };
}
async function getAdminOffer(env, id) {
	const offer = await offerRuntime(env).store.get(id);
	if (!offer) throw new AppError("NOT_FOUND", "Offer not found.");
	return { item: toAdminOffer(offer) };
}
async function listPublicOffers(env) {
	const { store } = offerRuntime(env);
	return { items: (await store.listPublished()).filter((offer) => isCompleteOffer(offer)).map(toPublicOffer) };
}
async function getPublicOffer(env, id) {
	const offer = await offerRuntime(env).store.get(id);
	if (!offer || !isCompleteOffer(offer)) throw new AppError("NOT_FOUND", "Offer not found.");
	return { item: toPublicOffer(offer) };
}
async function createOffer(env, input, actorId, requestId) {
	const { store } = offerRuntime(env);
	const offer = await store.create(parseOfferWrite(input));
	await store.recordAudit({
		offerId: offer.id,
		eventType: "created",
		actorId,
		requestId,
		toValue: "draft"
	});
	return { item: toAdminOffer(offer) };
}
async function updateOffer(env, id, input, actorId, requestId) {
	const { store } = offerRuntime(env);
	const offer = await store.update(id, parseOfferWrite(input));
	await store.recordAudit({
		offerId: id,
		eventType: "updated",
		actorId,
		requestId
	});
	return { item: toAdminOffer(offer) };
}
async function publishOffer(env, id, actorId, requestId) {
	const { store } = offerRuntime(env);
	return { item: toAdminOffer(await store.setStatus(id, "published", {
		eventType: "published",
		actorId,
		requestId,
		fromValue: "draft",
		toValue: "published"
	})) };
}
async function unpublishOffer(env, id, actorId, requestId) {
	const { store } = offerRuntime(env);
	return { item: toAdminOffer(await store.setStatus(id, "draft", {
		eventType: "unpublished",
		actorId,
		requestId,
		fromValue: "published",
		toValue: "draft"
	})) };
}
async function deleteOffer(env, id, actorId, requestId) {
	const { store, objects } = offerRuntime(env);
	const offer = await store.delete(id);
	await objects.deleteMany(offer.photos.flatMap((photo) => offerPhotoObjectKeys(photo)));
	await store.recordAudit({
		offerId: id,
		eventType: "deleted",
		actorId,
		requestId,
		fromValue: offer.status
	});
	return {
		deleted: true,
		id
	};
}
async function addOfferPhoto(env, offerId, file, actorId, requestId) {
	const contentType = assertOfferImage(file.bytes, file.type);
	const { store, objects } = offerRuntime(env);
	const existing = await store.get(offerId);
	if (!existing) throw new AppError("NOT_FOUND", "Offer not found.");
	const photoId = crypto.randomUUID();
	const contentHash = await hashOfferImage(file.bytes);
	const objectKey = offerObjectKey(offerId, photoId, contentHash, contentType);
	const storedKeys = [objectKey];
	await objects.put(objectKey, file.bytes, contentType);
	let thumbObjectKey = objectKey;
	try {
		if (file.thumbnail) {
			const thumbType = assertOfferImage(file.thumbnail.bytes, file.thumbnail.type);
			thumbObjectKey = offerObjectKey(offerId, photoId, contentHash, thumbType, "thumb");
			await objects.put(thumbObjectKey, file.thumbnail.bytes, thumbType);
			storedKeys.push(thumbObjectKey);
		}
		const offer = await store.addPhoto(offerId, {
			id: photoId,
			objectKey,
			thumbObjectKey,
			contentType,
			contentHash,
			isMain: existing.photos.length === 0,
			width: file.width ?? null,
			height: file.height ?? null,
			byteSize: file.bytes.byteLength
		});
		await store.recordAudit({
			offerId,
			eventType: "photo_added",
			actorId,
			requestId
		});
		return { item: toAdminOffer(offer) };
	} catch (error) {
		await objects.deleteMany(storedKeys);
		throw error;
	}
}
async function deleteOfferPhoto(env, offerId, photoId, actorId, requestId) {
	const { store, objects } = offerRuntime(env);
	const { offer, objectKeys } = await store.removePhoto(offerId, photoId);
	await objects.deleteMany(objectKeys);
	await store.recordAudit({
		offerId,
		eventType: "photo_deleted",
		actorId,
		requestId
	});
	return { item: toAdminOffer(offer) };
}
async function setMainOfferPhoto(env, offerId, photoId, actorId, requestId) {
	const { store } = offerRuntime(env);
	const offer = await store.setMainPhoto(offerId, photoId);
	await store.recordAudit({
		offerId,
		eventType: "main_photo",
		actorId,
		requestId,
		toValue: photoId
	});
	return { item: toAdminOffer(offer) };
}
async function readOfferPhoto(env, offerId, photoId, options = {}) {
	const { store, objects } = offerRuntime(env);
	const offer = await store.get(offerId);
	if (!offer) throw new AppError("NOT_FOUND", "Offer not found.");
	if (options.publicOnly && !isCompleteOffer(offer)) throw new AppError("NOT_FOUND", "Offer not found.");
	const photo = offer.photos.find((item) => item.id === photoId);
	if (!photo) throw new AppError("NOT_FOUND", "Photo not found.");
	if (options.version && options.version !== offerPhotoVersion(photo)) throw new AppError("NOT_FOUND", "Photo not found.");
	const objectKey = options.variant === "thumb" ? photo.thumbObjectKey : photo.objectKey;
	const object = await objects.get(objectKey);
	if (!object) throw new AppError("NOT_FOUND", "Photo not found.");
	return {
		...object,
		photo
	};
}
//#endregion
export { getAdminOffer as a, listPublicOffers as c, setMainOfferPhoto as d, unpublishOffer as f, parseOfferImageDimension as h, deleteOfferPhoto as i, publishOffer as l, offerPhotoVersion as m, createOffer as n, getPublicOffer as o, updateOffer as p, deleteOffer as r, listAdminOffers as s, addOfferPhoto as t, readOfferPhoto as u };
