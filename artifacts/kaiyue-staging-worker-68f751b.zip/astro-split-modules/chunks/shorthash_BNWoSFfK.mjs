globalThis.process ??= {};
globalThis.process.env ??= {};
//#region ../../node_modules/.pnpm/piccolore@0.1.3/node_modules/piccolore/dist/index.js
var e = globalThis.process || {};
var t = e.argv || [];
var n = e.env || {};
var r = !(n.NO_COLOR || t.includes(`--no-color`)) && (!!n.FORCE_COLOR || t.includes(`--color`) || e.platform === `win32` || (e.stdout || {}).isTTY && n.TERM !== `dumb` || !!n.CI);
var i = (e, t, n = e) => (r) => {
	let i = `` + r, o = i.indexOf(t, e.length);
	return ~o ? e + a(i, t, n, o) + t : e + i + t;
};
var a = (e, t, n, r) => {
	let i = ``, a = 0;
	do
		i += e.substring(a, r) + n, a = r + t.length, r = e.indexOf(t, a);
	while (~r);
	return i + e.substring(a);
};
var o = (e = r) => {
	let t = e ? i : () => String;
	return {
		isColorSupported: e,
		reset: t(`\x1B[0m`, `\x1B[0m`),
		bold: t(`\x1B[1m`, `\x1B[22m`, `\x1B[22m\x1B[1m`),
		dim: t(`\x1B[2m`, `\x1B[22m`, `\x1B[22m\x1B[2m`),
		italic: t(`\x1B[3m`, `\x1B[23m`),
		underline: t(`\x1B[4m`, `\x1B[24m`),
		inverse: t(`\x1B[7m`, `\x1B[27m`),
		hidden: t(`\x1B[8m`, `\x1B[28m`),
		strikethrough: t(`\x1B[9m`, `\x1B[29m`),
		black: t(`\x1B[30m`, `\x1B[39m`),
		red: t(`\x1B[31m`, `\x1B[39m`),
		green: t(`\x1B[32m`, `\x1B[39m`),
		yellow: t(`\x1B[33m`, `\x1B[39m`),
		blue: t(`\x1B[34m`, `\x1B[39m`),
		magenta: t(`\x1B[35m`, `\x1B[39m`),
		cyan: t(`\x1B[36m`, `\x1B[39m`),
		white: t(`\x1B[37m`, `\x1B[39m`),
		gray: t(`\x1B[90m`, `\x1B[39m`),
		bgBlack: t(`\x1B[40m`, `\x1B[49m`),
		bgRed: t(`\x1B[41m`, `\x1B[49m`),
		bgGreen: t(`\x1B[42m`, `\x1B[49m`),
		bgYellow: t(`\x1B[43m`, `\x1B[49m`),
		bgBlue: t(`\x1B[44m`, `\x1B[49m`),
		bgMagenta: t(`\x1B[45m`, `\x1B[49m`),
		bgCyan: t(`\x1B[46m`, `\x1B[49m`),
		bgWhite: t(`\x1B[47m`, `\x1B[49m`),
		blackBright: t(`\x1B[90m`, `\x1B[39m`),
		redBright: t(`\x1B[91m`, `\x1B[39m`),
		greenBright: t(`\x1B[92m`, `\x1B[39m`),
		yellowBright: t(`\x1B[93m`, `\x1B[39m`),
		blueBright: t(`\x1B[94m`, `\x1B[39m`),
		magentaBright: t(`\x1B[95m`, `\x1B[39m`),
		cyanBright: t(`\x1B[96m`, `\x1B[39m`),
		whiteBright: t(`\x1B[97m`, `\x1B[39m`),
		bgBlackBright: t(`\x1B[100m`, `\x1B[49m`),
		bgRedBright: t(`\x1B[101m`, `\x1B[49m`),
		bgGreenBright: t(`\x1B[102m`, `\x1B[49m`),
		bgYellowBright: t(`\x1B[103m`, `\x1B[49m`),
		bgBlueBright: t(`\x1B[104m`, `\x1B[49m`),
		bgMagentaBright: t(`\x1B[105m`, `\x1B[49m`),
		bgCyanBright: t(`\x1B[106m`, `\x1B[49m`),
		bgWhiteBright: t(`\x1B[107m`, `\x1B[49m`)
	};
};
var s = o();
//#endregion
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/runtime/server/shorthash.js
/**
* shortdash - https://github.com/bibig/node-shorthash
*
* @license
*
* (The MIT License)
*
* Copyright (c) 2013 Bibig <bibig@me.com>
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/
var dictionary = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY";
var binary = 61;
function bitwise(str) {
	let hash = 0;
	if (str.length === 0) return hash;
	for (let i = 0; i < str.length; i++) {
		const ch = str.charCodeAt(i);
		hash = (hash << 5) - hash + ch;
		hash = hash & hash;
	}
	return hash;
}
function shorthash(text) {
	let num;
	let result = "";
	let integer = bitwise(text);
	const sign = integer < 0 ? "Z" : "";
	integer = Math.abs(integer);
	while (integer >= binary) {
		num = integer % binary;
		integer = Math.floor(integer / binary);
		result = dictionary[num] + result;
	}
	if (integer > 0) result = dictionary[integer] + result;
	return sign + result;
}
//#endregion
export { s as n, shorthash as t };
