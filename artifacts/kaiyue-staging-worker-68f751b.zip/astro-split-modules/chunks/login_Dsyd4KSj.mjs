globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, F as addAttribute, I as defineScriptVars, K as createAstro, M as renderTemplate, P as renderHead } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, n as ADMIN_LOCALE_COOKIE, r as ADMIN_LOCALE_STORAGE_KEY, t as AdminLocaleSwitch, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { t as authClient } from "./auth-client_cZN3pWpe.mjs";
import { env } from "cloudflare:workers";
//#region src/components/admin/LoginForm.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function LoginForm({ locale }) {
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "admin-login-form",
		onSubmit: (event) => {
			event.preventDefault();
			const form = new FormData(event.currentTarget);
			setBusy(true);
			setError("");
			authClient.signIn.email({
				email: String(form.get("email")),
				password: String(form.get("password"))
			}).then(({ error }) => {
				if (error) {
					if (error.status === 429) {
						setError(t(locale, "login.errorRateLimited"));
						return;
					}
					if (error.message?.toLowerCase().includes("expired")) {
						setError(t(locale, "login.errorExpired"));
						return;
					}
					if (error.status === 403) {
						setError(t(locale, "login.errorUnavailable"));
						return;
					}
					setError(t(locale, "login.errorCredentials"));
					return;
				}
				window.location.assign("/admin");
			}).catch(() => setError(t(locale, "login.errorUnavailable"))).finally(() => setBusy(false));
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [t(locale, "login.email"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "email",
					type: "email",
					autoComplete: "username",
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [t(locale, "login.password"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "password",
					type: "password",
					autoComplete: "current-password",
					minLength: 16,
					required: true
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "admin-feedback admin-feedback--error",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn btn--primary",
				disabled: busy,
				children: busy ? t(locale, "login.submitting") : t(locale, "login.submit")
			})
		]
	});
}
//#endregion
//#region src/pages/login.astro
var login_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Login,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Login = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Login;
	const locale = adminLocaleFromCookies(Astro.cookies);
	return renderTemplate`<html${addAttribute(locale === "zh-Hant" ? "zh-Hant" : "en", "lang")}><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow"><link rel="icon" href="/favicon.ico" sizes="any"><link rel="icon" href="/images/mark.svg" type="image/svg+xml"><title>
      ${t(locale, "title.login")}
    </title><script>(function(){${defineScriptVars({
		cookieName: ADMIN_LOCALE_COOKIE,
		storageKey: ADMIN_LOCALE_STORAGE_KEY
	})}
      (() => {
        try {
          const stored = localStorage.getItem(storageKey);
          if (stored !== "en" && stored !== "zh-Hant") return;
          const cookie = document.cookie
            .split("; ")
            .find((row) => row.startsWith(cookieName + "="))
            ?.split("=")[1];
          if (cookie === stored) return;
          const secure = location.protocol === "https:" ? "; Secure" : "";
          document.cookie = \`\${cookieName}=\${stored}; Path=/; Max-Age=31536000; SameSite=Lax\${secure}\`;
          location.reload();
        } catch {
          /* ignore */
        }
      })();
    })();<\/script>${renderHead($$result)}</head><body class="admin-login-page"><main class="admin-login-card"><div class="admin-login-toolbar"><a class="admin-login-brand" href="/">Kai Yue <span>${t(locale, "brand.operations")}</span></a>${renderComponent($$result, "AdminLocaleSwitch", AdminLocaleSwitch, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/AdminLocaleSwitch.tsx",
		"client:component-export": "AdminLocaleSwitch"
	})}</div><p class="admin-eyebrow">${t(locale, "login.eyebrow")}</p><h1>${t(locale, "login.heading")}</h1><p class="muted">${t(locale, "login.help")}</p>${renderComponent($$result, "LoginForm", LoginForm, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/LoginForm.tsx",
		"client:component-export": "LoginForm"
	})}${env.ENVIRONMENT === "development" && renderTemplate`<p class="admin-login-help">${t(locale, "login.setupHelp")} <a href="/setup-admin">${t(locale, "login.setupLink")}</a>.</p>`}</main></body></html>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/login.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/login.astro";
var $$url = "/login";
//#endregion
//#region \0virtual:astro:page:src/pages/login@_@astro
var page = () => login_exports;
//#endregion
export { page };
