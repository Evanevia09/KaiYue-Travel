globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as $$Id$1 } from "./_id__Djan-Z50.mjs";
//#region src/pages/[locale]/special-offers/[id].astro
var _id__exports = /* @__PURE__ */ __exportAll({
	default: () => $$Id,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
var $$Id = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "SpecialOffer", $$Id$1, {})}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/[locale]/special-offers/[id].astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/[locale]/special-offers/[id].astro";
var $$url = "/[locale]/special-offers/[id]";
//#endregion
//#region \0virtual:astro:page:src/pages/[locale]/special-offers/[id]@_@astro
var page = () => _id__exports;
//#endregion
export { page };
