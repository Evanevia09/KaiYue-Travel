globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll } from "./rolldown-runtime_BDykq6kg.mjs";
import { D as Fragment, E as renderComponent, F as addAttribute, K as createAstro, M as renderTemplate, N as maybeRenderHead } from "./sequence_Cusz3XDW.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { i as renderScript, n as $$BaseLayout, r as $$PageHero, t as specialOfferUi } from "./special-offer-copy_CwYnkDzr.mjs";
import { t as localeFromPath } from "./i18n_s2qAaY1r.mjs";
import { c as listPublicOffers } from "./service_DalvdZP-.mjs";
import { env } from "cloudflare:workers";
//#region src/pages/404.astro
var $$404 = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, {
		"title": "Page not found",
		"noindex": true
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "PageHero", $$PageHero, {
		"eyebrow": "Error",
		"title": "Page not found",
		"lede": "That address is not part of the site."
	}, { "actions": ($$result) => renderTemplate`${maybeRenderHead($$result)}<a class="btn btn--primary" href="/">Home</a><a class="btn btn--secondary" href="/contact">Contact us</a>` })}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/404.astro", void 0);
//#endregion
//#region src/components/content/SpecialOfferPage.astro
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$SpecialOfferPage = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$SpecialOfferPage;
	const { offer, publishedOffers } = Astro.props;
	const locale = localeFromPath(Astro.url.pathname);
	const copy = specialOfferUi(locale);
	const photos = [...offer.photos].sort((a, b) => Number(b.isMain) - Number(a.isMain));
	const heroSrc = offer.mainPhotoUrl ?? photos[0]?.url ?? "/images/illustrative/city-tours-hero.jpg";
	const widgetOffers = publishedOffers?.length ? publishedOffers : [{
		id: offer.id,
		title: offer.title
	}];
	const seoDescription = offer.description.length > 180 ? `${offer.description.slice(0, 177).trim()}…` : offer.description;
	return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, {
		"title": offer.title,
		"description": seoDescription,
		"ogImage": heroSrc,
		"preserveMetadata": true,
		"bookingEnabled": true,
		"showMobileBook": false,
		"specialOffers": widgetOffers,
		"data-astro-cid-5bkf547u": true
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "PageHero", $$PageHero, {
		"id": "offer-hero",
		"className": "hero--tour-package",
		"title": offer.title,
		"lede": offer.description,
		"imageSrc": heroSrc,
		"imageAlt": offer.title,
		"preserveCopy": true,
		"data-astro-cid-5bkf547u": true
	}, { "booking": ($$result) => renderTemplate`${renderComponent($$result, "BookingEmbedded", null, {
		"slot": "booking",
		"client:only": "react",
		"sourcePage": Astro.url.pathname,
		"enquiryKind": "special_offer",
		"tourPackageId": offer.id,
		"tourPackageTitle": offer.title,
		"data-astro-cid-5bkf547u": true,
		"client:component-hydration": "only",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/booking/BookingEmbedded.tsx",
		"client:component-export": "BookingEmbedded"
	})}` })}${maybeRenderHead($$result)}<section class="section product" aria-labelledby="product-title" data-no-localize data-astro-cid-5bkf547u><div class="wrap product__grid" data-astro-cid-5bkf547u><div class="product-gallery" data-product-gallery data-astro-cid-5bkf547u><div class="product-gallery__stage" data-astro-cid-5bkf547u><img data-gallery-main${addAttribute(photos[0]?.url ?? heroSrc, "src")}${addAttribute(offer.title, "alt")}${addAttribute(photos[0]?.width ?? 1200, "width")}${addAttribute(photos[0]?.height ?? 900, "height")} decoding="async" data-astro-cid-5bkf547u></div>${photos.length > 1 && renderTemplate`<div class="product-gallery__thumbs" role="group"${addAttribute(copy.photos, "aria-label")} data-astro-cid-5bkf547u>${photos.map((photo, index) => renderTemplate`<button type="button" data-gallery-thumb${addAttribute(photo.url, "data-src")}${addAttribute(offer.title, "data-alt")}${addAttribute(index === 0 ? "true" : "false", "aria-pressed")}${addAttribute(`${copy.showPhoto} ${index + 1}`, "aria-label")} data-astro-cid-5bkf547u><img${addAttribute(photo.thumbUrl ?? photo.url, "src")} alt="" width="240" height="160" loading="lazy" decoding="async" data-astro-cid-5bkf547u></button>`)}</div>`}</div><div class="product__info" data-astro-cid-5bkf547u><p class="product__fact" data-astro-cid-5bkf547u>${copy.serviceValue}</p><h2 id="product-title" data-astro-cid-5bkf547u>${offer.title}</h2>${offer.priceFrom != null && renderTemplate`<div class="product-price" data-astro-cid-5bkf547u><p class="product-price__label" data-astro-cid-5bkf547u>${copy.from}</p><p class="product-price__value" data-astro-cid-5bkf547u>${offer.priceFrom}</p></div>`}<h3 data-astro-cid-5bkf547u>${copy.descriptionHeading}</h3><p class="product__description" data-astro-cid-5bkf547u>${offer.description}</p>${offer.terms ? renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result) => renderTemplate`<h3 data-astro-cid-5bkf547u>${copy.terms}</h3><p class="product__description" data-astro-cid-5bkf547u>${offer.terms}</p>` })}` : null}<a class="btn btn--primary product-book" href="#offer-hero" data-astro-cid-5bkf547u>${copy.book}</a></div></div></section>` })}${renderScript($$result, "/agent/repos/KaiYue-Travel/apps/web/src/components/content/SpecialOfferPage.astro?astro&type=script&index=0&lang.ts")}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/components/content/SpecialOfferPage.astro", void 0);
//#endregion
//#region src/pages/special-offers/[id].astro
var _id__exports = /* @__PURE__ */ __exportAll({
	default: () => $$Id,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Id = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Id;
	Astro.response.headers.set("Cache-Control", "private, no-store, no-cache, must-revalidate");
	Astro.response.headers.set("CDN-Cache-Control", "no-store");
	Astro.response.headers.set("Cloudflare-CDN-Cache-Control", "no-store");
	const id = Astro.params.id;
	let items = [];
	try {
		items = (await listPublicOffers(env)).items;
	} catch {
		items = [];
	}
	const item = id ? items.find((offer) => offer.id === id) : void 0;
	const photos = item ? item.photos.map((photo) => ({
		id: photo.id,
		url: photo.url,
		thumbUrl: photo.thumbUrl,
		isMain: photo.isMain,
		width: photo.width,
		height: photo.height
	})).sort((a, b) => Number(b.isMain) - Number(a.isMain)) : [];
	const page = item && photos.length > 0 ? {
		publishedOffers: items.map((offer) => ({
			id: offer.id,
			title: offer.title
		})),
		offer: {
			id: item.id,
			title: item.title,
			description: item.description,
			priceFrom: item.priceFrom,
			terms: item.terms,
			photos,
			mainPhotoUrl: item.mainPhotoUrl
		}
	} : null;
	if (!page) Astro.response.status = 404;
	return renderTemplate`${page ? renderTemplate`${renderComponent($$result, "SpecialOfferPage", $$SpecialOfferPage, {
		"publishedOffers": page.publishedOffers,
		"offer": page.offer
	})}` : renderTemplate`${renderComponent($$result, "NotFound", $$404, {})}`}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/special-offers/[id].astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/special-offers/[id].astro";
var $$url = "/special-offers/[id]";
//#endregion
export { _id__exports as n, $$Id as t };
