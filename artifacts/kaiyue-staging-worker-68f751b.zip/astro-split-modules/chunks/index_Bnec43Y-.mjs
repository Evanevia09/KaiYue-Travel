globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, K as createAstro, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, l as prefixedLabel, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, r as formatWhen, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
//#region src/components/admin/BookingsPanel.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function BookingsPanel({ locale, initialStatus = "" }) {
	const [status, setStatus] = (0, import_react.useState)(initialStatus);
	const [items, setItems] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(0);
	const [cursors, setCursors] = (0, import_react.useState)([null]);
	const [nextCursor, setNextCursor] = (0, import_react.useState)(null);
	const [total, setTotal] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)("");
	const [showCreate, setShowCreate] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let live = true;
		const query = new URLSearchParams({ limit: "15" });
		if (status) query.set("status", status);
		if (cursors[page]) query.set("cursor", cursors[page]);
		setItems(null);
		adminFetch(`/api/v1/admin/bookings?${query}`, { locale }).then((data) => {
			if (live) {
				setItems(data.items);
				setNextCursor(data.nextCursor);
				setTotal(data.total);
				setError("");
			}
		}).catch((err) => setError(localizeCaughtError(err, locale)));
		return () => {
			live = false;
		};
	}, [
		status,
		page,
		cursors,
		locale
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "admin-list-toolbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "admin-eyebrow",
					children: t(locale, "bookings.eyebrow")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "bookings.heading") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "muted",
					children: t(locale, "bookings.lead")
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn--primary",
				onClick: () => setShowCreate((value) => !value),
				children: showCreate ? t(locale, "bookings.closeForm") : t(locale, "bookings.add")
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "filters admin-filters",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
				t(locale, "bookings.status"),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: status,
					onChange: (event) => {
						setStatus(event.target.value);
						setPage(0);
						setCursors([null]);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: t(locale, "bookings.statusAll")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "enquiry",
							children: t(locale, "status.enquiry")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "assigned",
							children: t(locale, "status.assigned")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "completed",
							children: t(locale, "status.completed")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "cancelled",
							children: t(locale, "status.cancelled")
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "admin-results-count",
				children: t(locale, total === 1 ? "bookings.countOne" : "bookings.countMany", { count: total })
			})]
		}),
		showCreate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "admin-card admin-create-form",
			onSubmit: (event) => {
				event.preventDefault();
				const form = new FormData(event.currentTarget);
				setSaving(true);
				setError("");
				adminFetch("/api/v1/admin/bookings", {
					method: "POST",
					headers: { "idempotency-key": crypto.randomUUID() },
					locale,
					body: JSON.stringify({
						serviceType: form.get("serviceType"),
						pickupLocation: form.get("pickupLocation"),
						destination: form.get("destination"),
						pickupAt: new Date(String(form.get("pickupAt"))).toISOString(),
						passengerCount: Number(form.get("passengerCount")),
						communicationChannel: "whatsapp",
						contactName: form.get("contactName"),
						phone: form.get("phone"),
						message: form.get("message"),
						sourcePage: "/admin/bookings",
						sourceTrigger: "admin-manual",
						sourceMode: "page",
						locale: "en"
					})
				}).then((created) => {
					window.location.href = `/admin/bookings/${created.reference}`;
				}).catch((err) => setError(localizeCaughtError(err, locale))).finally(() => setSaving(false));
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "admin-card__heading",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "admin-kpi__label",
						children: t(locale, "bookings.manual")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "bookings.addHeading") })] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "booking-fields",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [t(locale, "bookings.service"), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								name: "serviceType",
								defaultValue: "point_to_point",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "point_to_point",
									children: t(locale, "service.point_to_point")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "airport_transfer",
									children: t(locale, "service.airport_transfer")
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [t(locale, "bookings.pickupAt"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "pickupAt",
								type: "datetime-local",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [t(locale, "bookings.pickupLocation"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "pickupLocation",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [t(locale, "bookings.destination"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "destination",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [t(locale, "bookings.customerName"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { name: "contactName" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [t(locale, "bookings.phone"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { name: "phone" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [t(locale, "bookings.passengers"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "passengerCount",
								type: "number",
								min: "1",
								max: "14",
								defaultValue: "1",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field field--full",
							children: [t(locale, "bookings.remarks"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								name: "message",
								required: true
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn--primary",
					disabled: saving,
					children: saving ? t(locale, "bookings.saving") : t(locale, "bookings.save")
				})
			]
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "alert",
			children: error
		}) : null,
		items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "bookings.loading") }) : null,
		items?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "bookings.empty") }) : null,
		items && items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "admin-card admin-table-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "table-wrap",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "admin-bookings-table",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "bookings.colBooking") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "bookings.colPickup") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "bookings.colJourney") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "bookings.colCustomer") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "bookings.colDispatch") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "bookings.colStatus") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: t(locale, "bookings.open")
						}) })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "admin-reference",
							href: `/admin/bookings/${item.reference}`,
							children: item.reference
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatWhen(item.pickupAt, locale) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t(locale, item.passengerCount === 1 ? "bookings.passengerOne" : "bookings.passengerMany", { count: item.passengerCount }) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.pickupLocation }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
								"→",
								" ",
								item.destination || item.offerTitle || t(locale, "bookings.hourlyService")
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.offerTitle ? t(locale, "bookings.specialOffer", { title: item.offerTitle }) : prefixedLabel(locale, "service", item.serviceType) })
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.contactName || t(locale, "bookings.unnamed") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.phone || item.email || prefixedLabel(locale, "channel", item.communicationChannel) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: item.driverId && item.vehicleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "admin-dispatch-ready",
							children: t(locale, "bookings.driverAssigned")
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "admin-dispatch-pending",
							children: t(locale, "bookings.notAssigned")
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `badge badge--${item.status}`,
							children: prefixedLabel(locale, "status", item.status)
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "admin-row-link",
							href: `/admin/bookings/${item.reference}`,
							"aria-label": t(locale, "bookings.openAria", { reference: item.reference }),
							children: t(locale, "bookings.view")
						}) })
					] }, item.reference)) })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-pagination",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "bookings.showing", {
					from: page * 15 + 1,
					to: page * 15 + items.length,
					total
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn--secondary",
						disabled: page === 0,
						onClick: () => setPage(page - 1),
						children: t(locale, "bookings.previous")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "bookings.page", { page: page + 1 }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn--secondary",
						disabled: !nextCursor,
						onClick: () => {
							if (nextCursor) {
								setCursors([...cursors.slice(0, page + 1), nextCursor]);
								setPage(page + 1);
							}
						},
						children: t(locale, "bookings.next")
					})
				] })]
			})]
		}) : null
	] });
}
//#endregion
//#region src/pages/admin/bookings/index.astro
var bookings_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Index,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Index = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Index;
	const locale = adminLocaleFromCookies(Astro.cookies);
	const status = Astro.url.searchParams.get("status") ?? "";
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.bookings",
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "BookingsPanel", BookingsPanel, {
		"client:load": true,
		"locale": locale,
		"initialStatus": status,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/BookingsPanel.tsx",
		"client:component-export": "BookingsPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/bookings/index.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/bookings/index.astro";
var $$url = "/admin/bookings";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/bookings/index@_@astro
var page = () => bookings_exports;
//#endregion
export { page };
