globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, F as addAttribute, K as createAstro, M as renderTemplate, P as renderHead } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { l as isLocalAdminSurface } from "./admin-gate_CU-fRGZ7.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, t as AdminLocaleSwitch, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { env } from "cloudflare:workers";
//#region src/components/admin/SetupForm.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function SetupForm({ locale }) {
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		role: "status",
		children: [
			t(locale, "setup.done"),
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/login",
				children: t(locale, "setup.signIn")
			}),
			"."
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "admin-login-form",
		onSubmit: (event) => {
			event.preventDefault();
			const form = new FormData(event.currentTarget);
			setBusy(true);
			setError("");
			fetch("/api/auth/sign-up/email", {
				method: "POST",
				headers: {
					"content-type": "application/json",
					"x-admin-setup-token": String(form.get("setupToken"))
				},
				body: JSON.stringify({
					name: form.get("name"),
					email: form.get("email"),
					password: form.get("password")
				})
			}).then(async (response) => {
				if (!response.ok) throw new Error(response.status === 409 ? t(locale, "setup.exists") : t(locale, "setup.failed"));
				setDone(true);
			}).catch((err) => setError(err.message)).finally(() => setBusy(false));
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [t(locale, "setup.name"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "name",
					autoComplete: "name",
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [t(locale, "setup.email"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "email",
					type: "email",
					autoComplete: "username",
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [t(locale, "setup.password"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "password",
					type: "password",
					autoComplete: "new-password",
					minLength: 16,
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [t(locale, "setup.token"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "setupToken",
					type: "password",
					autoComplete: "off",
					required: true
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "admin-feedback admin-feedback--error",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn btn--primary",
				disabled: busy,
				children: busy ? t(locale, "setup.creating") : t(locale, "setup.submit")
			})
		]
	});
}
//#endregion
//#region src/pages/setup-admin.astro
var setup_admin_exports = /* @__PURE__ */ __exportAll({
	default: () => $$SetupAdmin,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$SetupAdmin = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$SetupAdmin;
	const locale = adminLocaleFromCookies(Astro.cookies);
	if (!isLocalAdminSurface(env, Astro.request)) return new Response(t(locale, "setup.disabled"), {
		status: 403,
		headers: {
			"content-type": "text/plain; charset=utf-8",
			"cache-control": "no-store"
		}
	});
	return renderTemplate`<html${addAttribute(locale === "zh-Hant" ? "zh-Hant" : "en", "lang")}><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow"><link rel="icon" href="/favicon.ico" sizes="any"><link rel="icon" href="/images/mark.svg" type="image/svg+xml"><title>
      ${t(locale, "title.setup")}
    </title>${renderHead($$result)}</head><body class="admin-login-page"><main class="admin-login-card"><div class="admin-login-toolbar"><a class="admin-login-brand" href="/">Kai Yue <span>${t(locale, "brand.operations")}</span></a>${renderComponent($$result, "AdminLocaleSwitch", AdminLocaleSwitch, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/AdminLocaleSwitch.tsx",
		"client:component-export": "AdminLocaleSwitch"
	})}</div><p class="admin-eyebrow">${t(locale, "setup.eyebrow")}</p><h1>${t(locale, "setup.heading")}</h1><p class="muted">${t(locale, "setup.help")}</p>${renderComponent($$result, "SetupForm", SetupForm, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/SetupForm.tsx",
		"client:component-export": "SetupForm"
	})}<p><a href="/login">${t(locale, "setup.back")}</a></p></main></body></html>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/setup-admin.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/setup-admin.astro";
var $$url = "/setup-admin";
//#endregion
//#region \0virtual:astro:page:src/pages/setup-admin@_@astro
var page = () => setup_admin_exports;
//#endregion
export { page };
