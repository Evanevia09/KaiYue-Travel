globalThis.process ??= {};
globalThis.process.env ??= {};
import { t as getInstalledRenderScope } from "./scope_CfZQcAg3.mjs";
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/core/render-scope/record.js
function recordContentEntryRender(filePath) {
	if (!filePath) return;
	getInstalledRenderScope()?.getStore()?.contentEntries?.add(filePath);
}
function recordStaticImage(image) {
	getInstalledRenderScope()?.getStore()?.staticImages?.push(image);
}
//#endregion
export { recordStaticImage as n, recordContentEntryRender as t };
