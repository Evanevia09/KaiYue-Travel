globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, K as createAstro, M as renderTemplate, N as maybeRenderHead } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import "./src_BRRiv8WF.mjs";
import { n as BOOKING_TRANSITIONS } from "./status_WsaHno69.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, l as prefixedLabel, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, r as formatWhen, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
//#region src/components/admin/BookingDetailPanel.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var macauInput = (value) => value ? new Date(new Date(value).getTime() + 288e5).toISOString().slice(0, 16) : "";
var toIso = (value) => value ? (/* @__PURE__ */ new Date(`${value}:00+08:00`)).toISOString() : null;
function BookingDetailPanel({ reference, locale }) {
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [drivers, setDrivers] = (0, import_react.useState)([]);
	const [vehicles, setVehicles] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(false);
	async function load() {
		const [a, b, c] = await Promise.all([
			adminFetch(`/api/v1/admin/bookings/${reference}`, { locale }),
			adminFetch("/api/v1/admin/drivers", { locale }),
			adminFetch("/api/v1/admin/vehicles", { locale })
		]);
		setDetail(a);
		setDrivers(b.items);
		setVehicles(c.items);
	}
	(0, import_react.useEffect)(() => {
		load().catch((err) => setError(localizeCaughtError(err, locale)));
	}, [reference, locale]);
	async function action(task, success) {
		setSaving(true);
		setError("");
		setNotice("");
		try {
			await task();
			await load();
			setNotice(success);
		} catch (err) {
			setError(localizeCaughtError(err, locale));
		} finally {
			setSaving(false);
		}
	}
	if (!detail) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error || t(locale, "detail.loading") });
	const booking = detail.booking;
	const next = BOOKING_TRANSITIONS[booking.status] ?? [];
	const driver = drivers.find((item) => item.id === booking.driverId);
	const vehicle = vehicles.find((item) => item.id === booking.vehicleId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "admin-detail-page",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/admin/bookings",
				className: "admin-back",
				children: t(locale, "detail.back")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-detail-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "admin-eyebrow",
						children: t(locale, "detail.eyebrow")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: reference }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "muted",
						children: t(locale, "detail.received", {
							when: formatWhen(booking.createdAt, locale),
							channel: prefixedLabel(locale, "channel", booking.communicationChannel)
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `badge badge--${booking.status}`,
					children: prefixedLabel(locale, "status", booking.status)
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "admin-feedback admin-feedback--error",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "admin-feedback",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-detail-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "admin-detail-main",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "admin-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "admin-card__heading",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "admin-eyebrow",
									children: t(locale, "detail.journey")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "detail.heading") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn--secondary",
									onClick: () => setEditing(!editing),
									children: editing ? t(locale, "detail.cancelEdit") : t(locale, "detail.edit")
								})]
							}),
							editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "booking-fields admin-edit-form",
								onSubmit: (event) => {
									event.preventDefault();
									const form = new FormData(event.currentTarget);
									action(async () => {
										await adminFetch(`/api/v1/admin/bookings/${reference}`, {
											method: "PATCH",
											locale,
											body: JSON.stringify({
												expectedUpdatedAt: booking.updatedAt,
												pickupLocation: form.get("pickupLocation"),
												destination: form.get("destination"),
												pickupAt: toIso(form.get("pickupAt")),
												returnAt: toIso(form.get("returnAt")),
												passengerCount: Number(form.get("passengerCount")),
												contactName: form.get("contactName"),
												phone: form.get("phone"),
												email: form.get("email"),
												message: form.get("message")
											})
										});
										setEditing(false);
									}, t(locale, "detail.saved"));
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.pickupLocation"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "pickupLocation",
											defaultValue: booking.pickupLocation,
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.destination"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "destination",
											defaultValue: booking.destination ?? "",
											required: booking.serviceType !== "hourly_charter" && booking.serviceType !== "city_tour"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.pickupMacau"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "pickupAt",
											type: "datetime-local",
											defaultValue: macauInput(booking.pickupAt),
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.returnMacau"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "returnAt",
											type: "datetime-local",
											defaultValue: macauInput(booking.returnAt)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.passengers"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "passengerCount",
											type: "number",
											min: "1",
											max: "14",
											defaultValue: booking.passengerCount,
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.customerName"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "contactName",
											defaultValue: booking.contactName ?? ""
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.phone"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "phone",
											type: "tel",
											defaultValue: booking.phone ?? ""
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.email"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "email",
											type: "email",
											defaultValue: booking.email ?? ""
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field field--full",
										children: [t(locale, "detail.message"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											name: "message",
											defaultValue: booking.message,
											rows: 3
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn btn--primary",
										disabled: saving,
										children: saving ? t(locale, "detail.saving") : t(locale, "detail.saveDetails")
									})
								]
							}, booking.updatedAt) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "admin-detail-facts",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "detail.pickup") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: booking.pickupLocation }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: formatWhen(booking.pickupAt, locale) })
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "detail.destination") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: booking.destination || booking.offerTitle || t(locale, "detail.hourlyCharter") }),
										booking.returnAt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t(locale, "detail.return", { when: formatWhen(booking.returnAt, locale) }) })
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "detail.customer") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: booking.contactName || t(locale, "detail.notSupplied") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: booking.phone || booking.email || t(locale, "detail.noContact") })
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "detail.passengers") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: booking.passengerCount }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: booking.offerTitle ? t(locale, "detail.specialOffer") : prefixedLabel(locale, "service", booking.serviceType) }),
										booking.offerTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: booking.offerId ? t(locale, "detail.specialOfferLineId", {
											title: booking.offerTitle,
											id: booking.offerId
										}) : t(locale, "detail.specialOfferLine", { title: booking.offerTitle }) }) : null,
										booking.tourGuideRequested === true ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
											t(locale, "detail.tourGuide"),
											": ",
											t(locale, "detail.tourGuideRequested")
										] }) : booking.tourGuideRequested === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
											t(locale, "detail.tourGuide"),
											": ",
											t(locale, "detail.tourGuideNotRequested")
										] }) : null,
										booking.luggageCount != null || booking.handCarryCount != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t(locale, "detail.luggage", {
											luggage: booking.luggageCount ?? 0,
											hand: booking.handCarryCount ?? 0
										}) }) : null
									] })
								]
							}),
							!editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "admin-message",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(locale, "detail.customerMessage") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: booking.message || t(locale, "detail.noMessage") })]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "admin-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "admin-eyebrow",
								children: t(locale, "detail.dispatch")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "detail.driverVehicle") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "muted",
								children: t(locale, "detail.dispatchHelp")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "admin-current-assignment",
								children: [
									t(locale, "detail.current"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: driver?.name || t(locale, "detail.noDriver") }),
									" ·",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: vehicle ? `${vehicle.plateNumber} · ${vehicle.makeModel}` : t(locale, "detail.noVehicle") })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "admin-assignment-form",
								onSubmit: (event) => {
									event.preventDefault();
									const form = new FormData(event.currentTarget);
									action(() => adminFetch(`/api/v1/admin/bookings/${reference}/assignment`, {
										method: "PATCH",
										locale,
										body: JSON.stringify({
											expectedUpdatedAt: booking.updatedAt,
											driverId: form.get("driverId") || null,
											vehicleId: form.get("vehicleId") || null
										})
									}), t(locale, "detail.assignmentSaved"));
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.driver"), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											name: "driverId",
											defaultValue: booking.driverId ?? "",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: t(locale, "detail.selectDriver")
											}), drivers.filter((item) => item.active || item.id === booking.driverId).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: item.id,
												children: [
													item.name,
													" · ",
													item.phone,
													item.active ? "" : ` ${t(locale, "detail.inactive")}`
												]
											}, item.id))]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "detail.vehicle"), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											name: "vehicleId",
											defaultValue: booking.vehicleId ?? "",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: t(locale, "detail.selectVehicle")
											}), vehicles.filter((item) => item.active || item.id === booking.vehicleId).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: item.id,
												children: [
													item.plateNumber,
													" · ",
													item.makeModel,
													" ·",
													" ",
													t(locale, "detail.seats", { count: item.passengerCapacity }),
													item.active ? "" : ` ${t(locale, "detail.inactive")}`
												]
											}, item.id))]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn btn--primary",
										disabled: saving,
										children: saving ? t(locale, "detail.saving") : t(locale, "detail.saveAssignment")
									})
								]
							}, `${booking.driverId}-${booking.vehicleId}`),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/admin/inventory",
								className: "admin-inline-link",
								children: t(locale, "detail.manageInventory")
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "admin-detail-side",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "admin-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "admin-eyebrow",
									children: t(locale, "detail.workflow")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "detail.status") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "muted",
									children: t(locale, "detail.statusHelp")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "admin-status-actions",
									children: next.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: saving,
										className: status === "cancelled" ? "btn btn--danger" : "btn btn--secondary",
										onClick: () => {
											if (status === "cancelled" && !window.confirm(t(locale, "detail.cancelConfirm"))) return;
											action(() => adminFetch(`/api/v1/admin/bookings/${reference}/status`, {
												method: "PATCH",
												locale,
												body: JSON.stringify({ status })
											}), t(locale, "detail.statusChanged", { status: prefixedLabel(locale, "status", status) }));
										},
										children: t(locale, "detail.markStatus", { status: prefixedLabel(locale, "status", status) })
									}, status))
								}),
								next.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "muted",
									children: t(locale, "detail.finalStatus")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "admin-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "admin-eyebrow",
									children: t(locale, "detail.teamNotes")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "detail.remarks") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									className: "admin-note-form",
									onSubmit: (event) => {
										event.preventDefault();
										action(async () => {
											await adminFetch(`/api/v1/admin/bookings/${reference}/notes`, {
												method: "POST",
												locale,
												body: JSON.stringify({ body: note })
											});
											setNote("");
										}, t(locale, "detail.noteAdded"));
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "sr-only",
											htmlFor: "booking-note",
											children: t(locale, "detail.addNoteAria")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											id: "booking-note",
											value: note,
											onChange: (event) => setNote(event.target.value),
											placeholder: t(locale, "detail.notePlaceholder"),
											rows: 3
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "submit",
											className: "btn btn--secondary",
											disabled: saving || note.trim().length < 2,
											children: t(locale, "detail.addNote")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "admin-timeline",
									children: detail.notes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.body }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
										formatWhen(item.created_at, locale),
										" · ",
										item.created_by
									] })] }, item.id))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "admin-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "admin-eyebrow",
									children: t(locale, "detail.history")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "detail.audit") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "admin-timeline",
									children: detail.events.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: prefixedLabel(locale, "event", item.event_type) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
											formatWhen(item.created_at, locale),
											" · ",
											item.actor_id
										] }),
										item.event_type === "status_change" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
											prefixedLabel(locale, "status", item.from_value ?? ""),
											" →",
											" ",
											prefixedLabel(locale, "status", item.to_value ?? "")
										] })
									] }, item.id))
								})
							]
						})
					]
				})]
			})
		]
	});
}
//#endregion
//#region src/pages/admin/bookings/[reference].astro
var _reference__exports = /* @__PURE__ */ __exportAll({
	default: () => $$Reference,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Reference = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Reference;
	const locale = adminLocaleFromCookies(Astro.cookies);
	const reference = Astro.params.reference ?? "";
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.bookingDetail",
		"titleVars": { reference },
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<p><a href="/admin/bookings">${t(locale, "detail.astroBack")}</a></p>${renderComponent($$result, "BookingDetailPanel", BookingDetailPanel, {
		"client:load": true,
		"locale": locale,
		"reference": reference,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/BookingDetailPanel.tsx",
		"client:component-export": "BookingDetailPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/bookings/[reference].astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/bookings/[reference].astro";
var $$url = "/admin/bookings/[reference]";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/bookings/[reference]@_@astro
var page = () => _reference__exports;
//#endregion
export { page };
