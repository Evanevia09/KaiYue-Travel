globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, K as createAstro, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { a as OFFER_IMAGE_TYPES, d as AppError, i as OFFER_IMAGE_MAX_EDGE, u as scaledOfferImageSize } from "./src_BRRiv8WF.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { s as listAdminOffers } from "./service_DalvdZP-.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, l as prefixedLabel, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, r as formatWhen, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
import { env } from "cloudflare:workers";
//#region src/lib/offer-image.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function mimeOf(file) {
	const mime = file.type.split(";")[0]?.trim().toLowerCase() ?? "";
	return OFFER_IMAGE_TYPES.includes(mime) ? mime : null;
}
function canvasContext(width, height) {
	if (typeof OffscreenCanvas !== "undefined") {
		const canvas = new OffscreenCanvas(width, height);
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas is unavailable.");
		return {
			canvas,
			ctx
		};
	}
	if (typeof document === "undefined") throw new Error("Canvas is unavailable.");
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas is unavailable.");
	return {
		canvas,
		ctx
	};
}
async function blobFromCanvas(canvas, type, quality) {
	if ("convertToBlob" in canvas) return canvas.convertToBlob({
		type,
		quality
	});
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => blob ? resolve(blob) : reject(/* @__PURE__ */ new Error("Image encoding failed.")), type, quality);
	});
}
async function encodeVariant(source, maxEdge, quality, name) {
	const size = scaledOfferImageSize(source.width, source.height, maxEdge);
	const { canvas, ctx } = canvasContext(size.width, size.height);
	ctx.drawImage(source, 0, 0, size.width, size.height);
	let blob;
	try {
		blob = await blobFromCanvas(canvas, "image/webp", quality);
		if (!blob.type.includes("webp") || blob.size === 0) throw new Error("WebP unavailable.");
	} catch {
		blob = await blobFromCanvas(canvas, "image/jpeg", Math.min(.88, quality + .04));
	}
	const extension = blob.type.includes("webp") ? "webp" : "jpg";
	return {
		file: new File([blob], `${name}.${extension}`, { type: blob.type || "image/jpeg" }),
		width: size.width,
		height: size.height
	};
}
async function optimizeOfferPhoto(file) {
	if (!mimeOf(file)) throw new AppError("VALIDATION_FAILED", "Only JPEG, PNG, or WebP files are accepted.", { fields: { photo: "Only JPEG, PNG, or WebP files are accepted." } });
	if (file.size > 26214400) throw new AppError("VALIDATION_FAILED", "Each original photo must be 25 MB or smaller.", { fields: { photo: "Each original photo must be 25 MB or smaller." } });
	let bitmap;
	try {
		bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
	} catch {
		throw new AppError("VALIDATION_FAILED", "Could not resize this photo. Try another JPEG, PNG, or WebP.", { fields: { photo: "Could not resize this photo. Try another JPEG, PNG, or WebP." } });
	}
	try {
		const stem = file.name.replace(/\.[^.]+$/, "") || "offer";
		const display = await encodeVariant(bitmap, OFFER_IMAGE_MAX_EDGE, .82, stem);
		const thumbnail = await encodeVariant(bitmap, 480, .72, `${stem}-thumb`);
		if (display.file.size > 5242880 || thumbnail.file.size > 5242880) throw new AppError("VALIDATION_FAILED", "The resized photo is still over 5 MB. Try a simpler image.", { fields: { photo: "The resized photo is still over 5 MB. Try a simpler image." } });
		return {
			display,
			thumbnail
		};
	} catch (error) {
		if (error instanceof AppError) throw error;
		throw new AppError("VALIDATION_FAILED", "Could not resize this photo. Try another JPEG, PNG, or WebP.", { fields: { photo: "Could not resize this photo. Try another JPEG, PNG, or WebP." } });
	} finally {
		bitmap.close();
	}
}
//#endregion
//#region src/components/admin/offer-editor.ts
/** Copy the live FileList before the input is reset; clearing value empties it. */
function takeInputFiles(input) {
	const files = Array.from(input.files ?? []);
	input.value = "";
	return files;
}
function filesFromDataTransfer(data) {
	return Array.from(data?.files ?? []);
}
function offerSaveTarget(editingId) {
	if (editingId) return {
		method: "PATCH",
		path: `/api/admin/offers/${editingId}`
	};
	return {
		method: "POST",
		path: "/api/admin/offers"
	};
}
/** After any write, the dialog must target the saved offer. Create then stays on that id. */
function editorAfterWrite(saved) {
	return saved;
}
function withMainPhoto(offer, photoId) {
	return {
		...offer,
		photos: offer.photos.map((photo) => ({
			...photo,
			isMain: photo.id === photoId
		}))
	};
}
function withoutPhoto(offer, photoId) {
	const photos = offer.photos.filter((photo) => photo.id !== photoId);
	if (photos[0] && !photos.some((photo) => photo.isMain)) photos[0] = {
		...photos[0],
		isMain: true
	};
	return {
		...offer,
		photos
	};
}
function withOfferStatus(offer, status) {
	return {
		...offer,
		status
	};
}
/** Busy key follows the requested next state, not the optimistic current status. */
function offerStatusBusyKey(id, next) {
	return next === "published" ? `publish:${id}` : `unpublish:${id}`;
}
/**
* In-flight publish flips status to published immediately. The button label must still
* follow the target action, or the UI reads "Unpublishing…" while the offer is going live.
*/
function offerStatusControl(busy, id, status) {
	if (busy === `publish:${id}`) return {
		next: "published",
		labelKey: "offers.publishing"
	};
	if (busy === `unpublish:${id}`) return {
		next: "draft",
		labelKey: "offers.unpublishing"
	};
	if (status === "published") return {
		next: "draft",
		labelKey: "offers.unpublish"
	};
	return {
		next: "published",
		labelKey: "offers.publish"
	};
}
//#endregion
//#region src/components/admin/OffersPanel.tsx
var import_jsx_runtime = require_jsx_runtime();
var emptyForm = {
	title: "",
	description: "",
	priceFrom: "",
	terms: ""
};
function photoSrc(offerId, photo) {
	return photo.thumbUrl || photo.url || `/api/admin/offers/${offerId}/photos/${photo.id}`;
}
function uploadWithProgress(url, data, locale, onProgress) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open("POST", url);
		xhr.upload.onprogress = (event) => {
			if (event.lengthComputable && event.total > 0) onProgress(Math.round(event.loaded / event.total * 100));
		};
		xhr.onload = () => {
			try {
				const body = JSON.parse(xhr.responseText);
				if (xhr.status >= 200 && xhr.status < 300 && body.item) {
					resolve(body.item);
					return;
				}
				reject(new Error(localizeCaughtError(body.error ?? { message: t(locale, "offers.uploadFailed") }, locale)));
			} catch {
				reject(new Error(t(locale, "offers.uploadFailed")));
			}
		};
		xhr.onerror = () => reject(new Error(t(locale, "offers.uploadFailed")));
		xhr.send(data);
	});
}
function OffersPanel({ locale, initialItems = null }) {
	const [items, setItems] = (0, import_react.useState)(initialItems ?? []);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(emptyForm);
	const [modal, setModal] = (0, import_react.useState)(false);
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(initialItems == null);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [upload, setUpload] = (0, import_react.useState)(null);
	const dialogRef = (0, import_react.useRef)(null);
	const confirmRef = (0, import_react.useRef)(null);
	const loadSeq = (0, import_react.useRef)(0);
	async function load() {
		const seq = ++loadSeq.current;
		const result = await adminFetch("/api/admin/offers", { locale });
		if (seq !== loadSeq.current) return;
		setItems(result.items);
		setLoading(false);
	}
	function applyOffer(offer) {
		setItems((current) => {
			const index = current.findIndex((item) => item.id === offer.id);
			if (index === -1) return [offer, ...current];
			const next = [...current];
			next[index] = offer;
			return next;
		});
		setEditing((current) => current?.id === offer.id ? offer : current);
	}
	(0, import_react.useEffect)(() => {
		if (initialItems != null) {
			setLoading(false);
			return;
		}
		load().catch((err) => {
			setError(localizeCaughtError(err, locale));
			setLoading(false);
		});
	}, [initialItems, locale]);
	(0, import_react.useEffect)(() => {
		const dialog = dialogRef.current;
		if (!dialog) return;
		if (modal && !dialog.open) dialog.showModal();
		if (!modal && dialog.open) dialog.close();
	}, [modal]);
	(0, import_react.useEffect)(() => {
		const dialog = confirmRef.current;
		if (!dialog) return;
		if (confirmId && !dialog.open) dialog.showModal();
		if (!confirmId && dialog.open) dialog.close();
	}, [confirmId]);
	(0, import_react.useEffect)(() => {
		if (!busy) return;
		const warn = (event) => {
			event.preventDefault();
			event.returnValue = "";
		};
		window.addEventListener("beforeunload", warn);
		return () => window.removeEventListener("beforeunload", warn);
	}, [busy]);
	function openCreate() {
		setEditing(null);
		setForm(emptyForm);
		setError("");
		setModal(true);
	}
	function openEdit(offer) {
		setEditing(offer);
		setForm({
			title: offer.title,
			description: offer.description,
			priceFrom: offer.priceFrom == null ? "" : String(offer.priceFrom),
			terms: offer.terms ?? ""
		});
		setError("");
		setModal(true);
	}
	async function save(event) {
		event.preventDefault();
		if (busy) return;
		setBusy("save");
		setError("");
		try {
			const body = {
				title: form.title,
				description: form.description,
				priceFrom: form.priceFrom.trim() === "" ? void 0 : Number(form.priceFrom),
				terms: form.terms
			};
			const target = offerSaveTarget(editing?.id ?? null);
			const item = editorAfterWrite((await adminFetch(target.path, {
				method: target.method,
				body: JSON.stringify(body),
				locale
			})).item);
			applyOffer(item);
			setEditing(item);
			setForm({
				title: item.title,
				description: item.description,
				priceFrom: item.priceFrom == null ? "" : String(item.priceFrom),
				terms: item.terms ?? ""
			});
			setNotice(t(locale, editing ? "offers.updated" : "offers.created"));
		} catch (err) {
			setError(localizeCaughtError(err, locale));
		} finally {
			setBusy(null);
		}
	}
	async function uploadPhotos(files) {
		if (!editing || files.length === 0 || busy) return;
		setBusy("photos");
		setError("");
		const offerId = editing.id;
		try {
			let latest = editing;
			for (const [index, file] of files.entries()) {
				setUpload({
					index: index + 1,
					total: files.length,
					phase: "optimising",
					percent: 0
				});
				const optimized = await optimizeOfferPhoto(file);
				const data = new FormData();
				data.append("photo", optimized.display.file, optimized.display.file.name);
				data.append("thumbnail", optimized.thumbnail.file, optimized.thumbnail.file.name);
				data.append("width", String(optimized.display.width));
				data.append("height", String(optimized.display.height));
				setUpload({
					index: index + 1,
					total: files.length,
					phase: "uploading",
					percent: 0
				});
				latest = await uploadWithProgress(`/api/admin/offers/${offerId}/photos`, data, locale, (percent) => setUpload({
					index: index + 1,
					total: files.length,
					phase: "uploading",
					percent
				}));
				applyOffer(latest);
			}
			setNotice(t(locale, files.length === 1 ? "offers.photoUploaded" : "offers.photosUploaded"));
		} catch (err) {
			setError(localizeCaughtError(err, locale));
		} finally {
			setBusy(null);
			setUpload(null);
		}
	}
	async function setMain(photoId) {
		if (!editing || busy) return;
		const snapshot = editing;
		applyOffer(withMainPhoto(editing, photoId));
		setBusy(`main:${photoId}`);
		setError("");
		try {
			applyOffer((await adminFetch(`/api/admin/offers/${editing.id}/photos/${photoId}/main`, {
				method: "POST",
				body: JSON.stringify({}),
				locale
			})).item);
		} catch (err) {
			applyOffer(snapshot);
			setError(localizeCaughtError(err, locale));
		} finally {
			setBusy(null);
		}
	}
	async function removePhoto(photoId) {
		if (!editing || busy) return;
		const snapshot = editing;
		applyOffer(withoutPhoto(editing, photoId));
		setBusy(`photo:${photoId}`);
		setError("");
		try {
			applyOffer((await adminFetch(`/api/admin/offers/${editing.id}/photos/${photoId}`, {
				method: "DELETE",
				locale
			})).item);
		} catch (err) {
			applyOffer(snapshot);
			setError(localizeCaughtError(err, locale));
		} finally {
			setBusy(null);
		}
	}
	async function setStatus(id, next) {
		if (busy) return;
		const current = items.find((item) => item.id === id);
		if (current) applyOffer(withOfferStatus(current, next));
		setBusy(offerStatusBusyKey(id, next));
		setError("");
		try {
			applyOffer((await adminFetch(`/api/admin/offers/${id}/${next === "published" ? "publish" : "unpublish"}`, {
				method: "POST",
				body: JSON.stringify({}),
				locale
			})).item);
			setNotice(t(locale, next === "published" ? "offers.published" : "offers.unpublished"));
		} catch (err) {
			if (current) applyOffer(current);
			setError(localizeCaughtError(err, locale));
		} finally {
			setBusy(null);
		}
	}
	async function remove(id) {
		if (busy) return;
		const snapshot = items;
		setBusy(`delete:${id}`);
		setError("");
		setItems((current) => current.filter((item) => item.id !== id));
		setConfirmId(null);
		if (editing?.id === id) {
			setModal(false);
			setEditing(null);
		}
		try {
			await adminFetch(`/api/admin/offers/${id}`, {
				method: "DELETE",
				locale
			});
			setNotice(t(locale, "offers.deleted"));
		} catch (err) {
			setItems(snapshot);
			setError(localizeCaughtError(err, locale));
		} finally {
			setBusy(null);
		}
	}
	const locked = Boolean(busy);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "admin-inventory",
		"aria-busy": locked || loading,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-list-toolbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "admin-eyebrow",
						children: t(locale, "offers.eyebrow")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "offers.heading") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "muted",
						children: t(locale, "offers.lead")
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn--primary",
					onClick: openCreate,
					disabled: locked,
					children: t(locale, "offers.new")
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "admin-feedback admin-feedback--error",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "admin-feedback",
				children: notice
			}),
			busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "admin-feedback",
				children: upload ? upload.phase === "optimising" ? t(locale, "offers.optimising", {
					index: upload.index,
					total: upload.total
				}) : t(locale, "offers.uploading", {
					index: upload.index,
					total: upload.total,
					percent: upload.percent
				}) : `${t(locale, "offers.working")} ${busy.startsWith("publish:") ? t(locale, "offers.publishingStatus") : busy.startsWith("unpublish:") ? t(locale, "offers.unpublishingStatus") : t(locale, "offers.wait")}`
			}),
			upload && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "admin-upload-progress",
				role: "progressbar",
				"aria-valuemin": 0,
				"aria-valuemax": 100,
				"aria-valuenow": upload.phase === "uploading" ? upload.percent : 0,
				"aria-label": t(locale, "offers.uploadProgress"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { width: `${upload.phase === "uploading" ? Math.max(upload.percent, 8) : 12}%` } })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "admin-card admin-table-card",
				children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "muted",
					children: t(locale, "offers.loading")
				}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "muted",
					children: t(locale, "offers.empty")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "admin-bookings-table",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "offers.colTitle") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "offers.colStatus") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "offers.colPrice") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "offers.colUpdated") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: t(locale, "offers.colActions") })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((item) => {
						const action = offerStatusControl(busy, item.id, item.status);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.complete ? t(locale, "offers.ready") : t(locale, "offers.incomplete") })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `badge badge--${item.status}`,
								children: prefixedLabel(locale, "status", item.status)
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: item.priceFrom == null ? t(locale, "offers.hidden") : item.priceFrom }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: formatWhen(item.updatedAt, locale) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "admin-inline-link",
									onClick: () => openEdit(item),
									disabled: locked,
									children: t(locale, "offers.edit")
								}),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "admin-inline-link",
									onClick: () => void setStatus(item.id, action.next),
									disabled: locked,
									children: t(locale, action.labelKey)
								}),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "admin-inline-link",
									onClick: () => setConfirmId(item.id),
									disabled: locked,
									children: t(locale, "offers.delete")
								})
							] })
						] }, item.id);
					}) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dialog", {
				ref: dialogRef,
				className: "admin-editor-dialog admin-editor-dialog--wide",
				"aria-labelledby": "offer-editor-title",
				onClose: () => setModal(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "admin-editor-dialog__content",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "admin-card__heading",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "admin-eyebrow",
								children: editing ? t(locale, "offers.editOffer") : t(locale, "offers.newDraft")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "offer-editor-title",
								children: editing ? editing.title : t(locale, "offers.create")
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "admin-editor-dialog__close",
								"aria-label": t(locale, "offers.close"),
								onClick: () => dialogRef.current?.close(),
								disabled: locked,
								children: "×"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "admin-resource-form",
							onSubmit: (event) => void save(event),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field field--full",
									children: [t(locale, "offers.title"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.title,
										maxLength: 120,
										required: true,
										disabled: locked,
										onChange: (event) => setForm((current) => ({
											...current,
											title: event.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field field--full",
									children: [t(locale, "offers.description"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: form.description,
										maxLength: 2e3,
										rows: 5,
										required: true,
										disabled: locked,
										onChange: (event) => setForm((current) => ({
											...current,
											description: event.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [t(locale, "offers.priceFrom"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: "0.01",
										step: "0.01",
										value: form.priceFrom,
										disabled: locked,
										onChange: (event) => setForm((current) => ({
											...current,
											priceFrom: event.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field field--full",
									children: [t(locale, "offers.terms"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: form.terms,
										maxLength: 4e3,
										rows: 4,
										disabled: locked,
										onChange: (event) => setForm((current) => ({
											...current,
											terms: event.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn btn--primary",
									disabled: locked,
									children: busy === "save" ? t(locale, "offers.saving") : editing ? t(locale, "offers.save") : t(locale, "offers.createDraft")
								})
							]
						}),
						editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "admin-offer-photos",
							onDragOver: (event) => {
								event.preventDefault();
							},
							onDrop: (event) => {
								event.preventDefault();
								if (locked) return;
								uploadPhotos(filesFromDataTransfer(event.dataTransfer));
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: t(locale, "offers.photos") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "muted",
									children: t(locale, "offers.photosHelp")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/jpeg,image/png,image/webp",
									multiple: true,
									disabled: locked,
									onChange: (event) => {
										uploadPhotos(takeInputFiles(event.currentTarget));
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "admin-offer-photo-list",
									children: editing.photos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: photoSrc(editing.id, photo),
											alt: "",
											width: photo.width ?? 120,
											height: photo.height ?? 80,
											loading: "lazy"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "radio",
												name: "main-photo",
												checked: photo.isMain,
												disabled: locked,
												onChange: () => void setMain(photo.id)
											}),
											" ",
											t(locale, "offers.mainPhoto")
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: locked,
											onClick: () => void removePhoto(photo.id),
											children: busy === `photo:${photo.id}` ? t(locale, "offers.removing") : t(locale, "offers.remove")
										})
									] }, photo.id))
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dialog", {
				ref: confirmRef,
				className: "admin-editor-dialog",
				"aria-labelledby": "offer-delete-title",
				onClose: () => setConfirmId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "admin-editor-dialog__content",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "offer-delete-title",
							children: t(locale, "offers.deleteTitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "offers.deleteHelp") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "admin-topbar__actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn--secondary",
								onClick: () => setConfirmId(null),
								disabled: locked,
								children: t(locale, "offers.cancel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn--primary",
								disabled: locked,
								onClick: () => confirmId && void remove(confirmId),
								children: busy?.startsWith("delete:") ? t(locale, "offers.deleting") : t(locale, "offers.deleteOffer")
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/pages/admin/offers.astro
var offers_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Offers,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Offers = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Offers;
	const locale = adminLocaleFromCookies(Astro.cookies);
	let items = null;
	try {
		items = (await listAdminOffers(env)).items;
	} catch {
		items = null;
	}
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.offers",
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "OffersPanel", OffersPanel, {
		"client:load": true,
		"locale": locale,
		"initialItems": items,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/OffersPanel.tsx",
		"client:component-export": "OffersPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/offers.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/offers.astro";
var $$url = "/admin/offers";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/offers@_@astro
var page = () => offers_exports;
//#endregion
export { page };
