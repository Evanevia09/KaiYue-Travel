globalThis.process ??= {};
globalThis.process.env ??= {};
import { r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, F as addAttribute, I as defineScriptVars, K as createAstro, M as renderTemplate, P as renderHead, k as renderSlot } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { n as CANONICAL_PUBLIC_ORIGIN, t as ACCESS_ADMIN_HOST } from "./admin-gate_CU-fRGZ7.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, n as ADMIN_LOCALE_COOKIE, o as formatAdminWhen, r as ADMIN_LOCALE_STORAGE_KEY, s as localizeAdminError, t as AdminLocaleSwitch, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { t as authClient } from "./auth-client_cZN3pWpe.mjs";
//#region src/components/admin/api.ts
function adminFetchInit(init) {
	const method = (init?.method ?? "GET").toUpperCase();
	const mutating = method !== "GET" && method !== "HEAD";
	return {
		...init,
		keepalive: init?.keepalive ?? mutating,
		headers: {
			"content-type": "application/json",
			...init?.headers ?? {}
		}
	};
}
async function adminFetch(path, init) {
	const locale = init?.locale ?? "en";
	const { locale: _locale, ...requestInit } = init ?? {};
	const response = await fetch(path, adminFetchInit(requestInit));
	const body = await response.json();
	if (!response.ok) throw new Error(localizeAdminError(body.error, locale));
	return body;
}
function formatWhen(value, locale = "en") {
	return formatAdminWhen(value, locale);
}
//#endregion
//#region src/components/admin/SignOutButton.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function SignOutButton({ locale }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "btn btn--secondary",
		disabled: busy,
		onClick: () => {
			setBusy(true);
			authClient.signOut().finally(() => window.location.assign("/login"));
		},
		children: busy ? t(locale, "signOut.busy") : t(locale, "signOut")
	});
}
//#endregion
//#region src/layouts/AdminLayout.astro
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$AdminLayout = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$AdminLayout;
	const locale = Astro.props.locale ?? adminLocaleFromCookies(Astro.cookies);
	const title = t(locale, Astro.props.titleKey, Astro.props.titleVars);
	const path = Astro.url.pathname;
	const usesAccess = Astro.url.hostname === ACCESS_ADMIN_HOST;
	return renderTemplate`<html${addAttribute(locale === "zh-Hant" ? "zh-Hant" : "en", "lang")}><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow"><link rel="icon" href="/favicon.ico" sizes="any"><link rel="icon" href="/images/mark.svg" type="image/svg+xml"><title>${title} · ${t(locale, "page.adminSuffix")}</title><script>(function(){${defineScriptVars({
		cookieName: ADMIN_LOCALE_COOKIE,
		storageKey: ADMIN_LOCALE_STORAGE_KEY
	})}
      (() => {
        try {
          const stored = localStorage.getItem(storageKey);
          if (stored !== "en" && stored !== "zh-Hant") return;
          const cookie = document.cookie
            .split("; ")
            .find((row) => row.startsWith(cookieName + "="))
            ?.split("=")[1];
          if (cookie === stored) return;
          const secure = location.protocol === "https:" ? "; Secure" : "";
          document.cookie = \`\${cookieName}=\${stored}; Path=/; Max-Age=31536000; SameSite=Lax\${secure}\`;
          location.reload();
        } catch {
          /* ignore */
        }
      })();
    })();<\/script>${renderHead($$result)}</head><body><div class="admin-shell"><aside class="admin-nav"><a class="admin-brand" href="/admin"><span class="logo-mark" aria-hidden="true"></span><span><strong>Kai Yue</strong><small>${t(locale, "brand.operations")}</small></span></a><nav${addAttribute(t(locale, "nav.aria"), "aria-label")}>${[
		{
			href: "/admin",
			key: "nav.dashboard"
		},
		{
			href: "/admin/bookings",
			key: "nav.bookings"
		},
		{
			href: "/admin/calendar",
			key: "nav.calendar"
		},
		{
			href: "/admin/inventory",
			key: "nav.inventory"
		},
		{
			href: "/admin/contacts",
			key: "nav.contacts"
		},
		{
			href: "/admin/offers",
			key: "nav.offers"
		}
	].map((link) => renderTemplate`<a${addAttribute(link.href, "href")}${addAttribute(path === link.href ? "page" : void 0, "aria-current")}>${t(locale, link.key)}</a>`)}</nav><p class="draft-note admin-nav__secure">${t(locale, "nav.secure")}</p></aside><div class="admin-main"><header class="admin-topbar"><div><p class="admin-eyebrow">${t(locale, "topbar.eyebrow")}</p><h1>${title}</h1></div><div class="admin-topbar__actions">${renderComponent($$result, "AdminLocaleSwitch", AdminLocaleSwitch, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/AdminLocaleSwitch.tsx",
		"client:component-export": "AdminLocaleSwitch"
	})}<a class="btn btn--secondary"${addAttribute(usesAccess ? `${CANONICAL_PUBLIC_ORIGIN}/` : "/", "href")}>${t(locale, "topbar.viewWebsite")}</a>${usesAccess ? renderTemplate`<a class="btn btn--secondary" href="/cdn-cgi/access/logout">${t(locale, "signOut")}</a>` : renderTemplate`${renderComponent($$result, "SignOutButton", SignOutButton, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/SignOutButton.tsx",
		"client:component-export": "SignOutButton"
	})}`}</div></header>${renderSlot($$result, $$slots["default"])}</div></div></body></html>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/layouts/AdminLayout.astro", void 0);
//#endregion
export { adminFetch as n, formatWhen as r, $$AdminLayout as t };
