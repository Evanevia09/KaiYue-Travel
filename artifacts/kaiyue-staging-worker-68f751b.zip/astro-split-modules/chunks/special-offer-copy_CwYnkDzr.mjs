globalThis.process ??= {};
globalThis.process.env ??= {};
import { At as generateCspDigest, C as renderUniqueStylesheet, Ct as removeBase, E as renderComponent, F as addAttribute, I as defineScriptVars, K as createAstro, Kt as object, L as createRenderInstruction, Lt as array, M as renderTemplate, N as maybeRenderHead, P as renderHead, Pn as RenderUndefinedEntryError, Rn as UnknownContentCollectionError, S as renderScriptElement, St as prependForwardSlash, U as unescapeHTML, V as createHeadAndContent, W as escape, Zt as string, bt as isRemotePath, c as createConsoleLogger, en as safeParseAsync, in as AstroError, k as renderSlot, x as spreadAttributes, zt as date } from "./sequence_Cusz3XDW.mjs";
import { n as parse, r as unflatten } from "./scope_CfZQcAg3.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as recordContentEntryRender } from "./record_BFqv2ZvN.mjs";
import { t as level } from "./_virtual_astro_logger_DARKlz-P.mjs";
import { r as VALID_INPUT_FORMATS } from "./consts_BPqL0Mo4.mjs";
import "./src_BRRiv8WF.mjs";
import { r as createIdempotencyKey } from "./ids_Ddm5oCYW.mjs";
import { a as stripLocale, i as localeTags, n as localeNames, r as localePath, t as localeFromPath } from "./i18n_s2qAaY1r.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/runtime/server/render/script.js
async function renderScript(result, id) {
	const inlined = result.inlinedScripts.get(id);
	let content = "";
	if (inlined != null) {
		if (inlined) content = `<script type="module">${inlined}<\/script>`;
	} else {
		const resolved = await result.resolve(id);
		content = `<script type="module" src="${result.userAssetsBase ? (result.base === "/" ? "" : result.base) + result.userAssetsBase : ""}${resolved}"><\/script>`;
	}
	return createRenderInstruction({
		type: "script",
		id,
		content
	});
}
//#endregion
//#region src/components/content/HeroBackdrop.astro
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$HeroBackdrop = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$HeroBackdrop;
	const { src = "/images/hero-home.jpg", alt = "Chauffeur welcoming a family beside a private vehicle at a waterfront hotel in Macau", preserveCopy, fetchpriority, webpSrcset, sizes, width = 1920, height = 1080 } = Astro.props;
	return renderTemplate`${maybeRenderHead($$result)}<div class="hero__bg"><picture>${webpSrcset ? renderTemplate`<source type="image/webp"${addAttribute(webpSrcset, "srcset")}${addAttribute(sizes, "sizes")}>` : null}<img${addAttribute(src, "src")}${addAttribute(width, "width")}${addAttribute(height, "height")}${addAttribute(sizes, "sizes")}${addAttribute(alt, "alt")}${addAttribute(fetchpriority, "fetchpriority")}${addAttribute(fetchpriority === "high" ? "sync" : "async", "decoding")}${addAttribute(preserveCopy || void 0, "data-no-localize")}></picture></div>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/components/content/HeroBackdrop.astro", void 0);
//#endregion
//#region src/components/content/PageHero.astro
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$PageHero = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$PageHero;
	const { eyebrow, title, lede, imageSrc, imageAlt, className, id, contentLang, preserveCopy } = Astro.props;
	const hasBooking = Astro.slots.has("booking");
	const hasInquiry = Astro.slots.has("inquiry");
	return renderTemplate`${maybeRenderHead($$result)}<section${addAttribute(id, "id")}${addAttribute([
		"hero",
		"hero--page",
		className,
		{ "hero--inquiry": hasInquiry }
	], "class:list")}>${renderComponent($$result, "HeroBackdrop", $$HeroBackdrop, {
		"src": imageSrc,
		"alt": imageAlt,
		"preserveCopy": preserveCopy
	})}<div class="hero__stage"><div class="hero__copy">${eyebrow ? renderTemplate`<p class="kicker">${eyebrow}</p>` : null}<h1${addAttribute(contentLang, "lang")}${addAttribute(preserveCopy || void 0, "data-no-localize")}>${title}</h1>${lede ? renderTemplate`<p class="hero-sub"${addAttribute(contentLang, "lang")}${addAttribute(preserveCopy || void 0, "data-no-localize")}>${lede}</p>` : null}</div>${hasInquiry ? renderTemplate`<div class="hero__inquiry">${renderSlot($$result, $$slots["inquiry"])}</div>` : null}${hasBooking ? renderTemplate`<div class="hero-booking">${renderSlot($$result, $$slots["booking"])}</div>` : null}${Astro.slots.has("actions") ? renderTemplate`<div class="hero__actions">${renderSlot($$result, $$slots["actions"])}</div>` : null}${renderSlot($$result, $$slots["default"])}</div></section>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/components/content/PageHero.astro", void 0);
//#endregion
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/assets/runtime.js
function createSvgComponent({ meta, attributes, children, styles }) {
	const hasStyles = styles.length > 0;
	const Component = createComponent({
		async factory(result, props) {
			const normalizedProps = normalizeProps(attributes, props);
			if (hasStyles && result.cspDestination) for (const style of styles) {
				const hash = await generateCspDigest(style, result.cspAlgorithm);
				result._metadata.extraStyleHashes.push(hash);
			}
			return renderTemplate`<svg${spreadAttributes(normalizedProps)}>${unescapeHTML(children)}</svg>`;
		},
		propagation: hasStyles ? "self" : "none"
	});
	Object.defineProperty(Component, "toJSON", {
		value: () => meta,
		enumerable: false
	});
	return Object.assign(Component, meta);
}
var ATTRS_TO_DROP = [
	"xmlns",
	"xmlns:xlink",
	"version"
];
var DEFAULT_ATTRS = {};
function dropAttributes(attributes) {
	for (const attr of ATTRS_TO_DROP) delete attributes[attr];
	return attributes;
}
function normalizeProps(attributes, props) {
	return dropAttributes({
		...DEFAULT_ATTRS,
		...attributes,
		...props
	});
}
var CONTENT_IMAGE_FLAG = "astroContentImageFlag";
var DATA_STORE_VIRTUAL_ID = "astro:data-layer-content";
"" + DATA_STORE_VIRTUAL_ID;
var IMAGE_IMPORT_PREFIX = "__ASTRO_IMAGE_";
`${DATA_STORE_VIRTUAL_ID}`;
//#endregion
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/assets/utils/resolveImports.js
function imageSrcToImportId(imageSrc, filePath) {
	imageSrc = removeBase(imageSrc, IMAGE_IMPORT_PREFIX);
	if (isRemotePath(imageSrc)) return;
	const ext = imageSrc.split(".").at(-1)?.toLowerCase();
	if (!ext || !VALID_INPUT_FORMATS.includes(ext)) return;
	const params = new URLSearchParams(CONTENT_IMAGE_FLAG);
	if (filePath) params.set("importer", filePath);
	return `${imageSrc}?${params.toString()}`;
}
//#endregion
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/content/data-store-source.js
var InMemorySource = class {
	#store;
	constructor(store) {
		this.#store = store;
	}
	hasCollection(collection) {
		return this.#store.hasCollection(collection);
	}
	get(collection, key) {
		return this.#store.get(collection, key);
	}
	entries(collection) {
		return this.#store.entries(collection);
	}
	values(collection) {
		return this.#store.values(collection);
	}
	keys(collection) {
		return this.#store.keys(collection);
	}
	has(collection, key) {
		return this.#store.has(collection, key);
	}
	collections() {
		return this.#store.collections();
	}
};
//#endregion
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/content/data-store.js
var ChunkedCollectionParser = class {
	#entries = /* @__PURE__ */ new Map();
	#remainder = "";
	add(part) {
		const records = (this.#remainder + part).split("\n");
		this.#remainder = records.pop();
		for (const record of records) {
			const parsed = parse(record);
			if (!Array.isArray(parsed) || parsed.length !== 2 || typeof parsed[0] !== "string") throw new Error("Invalid chunked data store entry");
			this.#entries.set(parsed[0], parsed[1]);
		}
	}
	finish() {
		if (this.#remainder) throw new Error("Invalid chunked data store entry");
		return this.#entries;
	}
};
var ImmutableDataStore = class ImmutableDataStore {
	_collections = /* @__PURE__ */ new Map();
	constructor() {
		this._collections = /* @__PURE__ */ new Map();
	}
	get(collectionName, key) {
		return this._collections.get(collectionName)?.get(String(key));
	}
	entries(collectionName) {
		return [...(this._collections.get(collectionName) ?? /* @__PURE__ */ new Map()).entries()];
	}
	values(collectionName) {
		return [...(this._collections.get(collectionName) ?? /* @__PURE__ */ new Map()).values()];
	}
	keys(collectionName) {
		return [...(this._collections.get(collectionName) ?? /* @__PURE__ */ new Map()).keys()];
	}
	has(collectionName, key) {
		const collection = this._collections.get(collectionName);
		if (collection) return collection.has(String(key));
		return false;
	}
	hasCollection(collectionName) {
		return this._collections.has(collectionName);
	}
	collections() {
		return this._collections;
	}
	/**
	* Rebuilds a collections map from a chunked-store manifest whose part file
	* names have already been swapped for their contents.
	*
	* Each collection maps to a list of parts. A part is either a raw string
	* (when the store is loaded from disk) or an ESM namespace from a virtual
	* chunk import (`{ default: string }`, when emitted at runtime). Each part
	* contains independently serialized entry records. This is the inverse of
	* {@link import('./data-store-writer.js').ChunkedWriter} and stays free of
	* Node built-ins so it can run at runtime.
	*/
	static manifestToMap(manifest) {
		const collections = /* @__PURE__ */ new Map();
		for (const [collectionName, parts] of Object.entries(manifest)) {
			const parser = new ChunkedCollectionParser();
			for (const part of parts) parser.add(typeof part === "string" ? part : part.default);
			collections.set(collectionName, parser.finish());
		}
		return collections;
	}
	/**
	* Attempts to load a DataStore from the virtual module.
	* This only works in Vite.
	*/
	static async fromModule() {
		try {
			const data = await import("./_astro_data-layer-content_tNurwGEN.mjs");
			if (data.default instanceof Map) return ImmutableDataStore.fromMap(data.default);
			if (Array.isArray(data.default)) {
				const map2 = unflatten(data.default);
				return ImmutableDataStore.fromMap(map2);
			}
			const map = ImmutableDataStore.manifestToMap(data.default);
			return ImmutableDataStore.fromMap(map);
		} catch {}
		return new ImmutableDataStore();
	}
	static async fromMap(data) {
		const store = new ImmutableDataStore();
		store._collections = data;
		return store;
	}
};
function dataStoreSingleton() {
	let instance = void 0;
	return {
		get: async () => {
			if (!instance) instance = ImmutableDataStore.fromModule().then((store) => new InMemorySource(store));
			return instance;
		},
		set: (store) => {
			instance = new InMemorySource(store);
		}
	};
}
var globalDataStore = dataStoreSingleton();
//#endregion
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/content/loaders/errors.js
function formatZodError(error) {
	return error.issues.map((issue) => `  **${issue.path.join(".")}**: ${issue.message}`);
}
var LiveCollectionError = class LiveCollectionError extends Error {
	collection;
	message;
	cause;
	constructor(collection, message, cause) {
		super(message);
		this.collection = collection;
		this.message = message;
		this.cause = cause;
		this.name = "LiveCollectionError";
		if (cause?.stack) this.stack = cause.stack;
	}
	static is(error) {
		return error instanceof LiveCollectionError;
	}
};
var LiveEntryNotFoundError = class extends LiveCollectionError {
	constructor(collection, entryFilter) {
		super(collection, `Entry ${collection} \u2192 ${typeof entryFilter === "string" ? entryFilter : JSON.stringify(entryFilter)} was not found.`);
		this.name = "LiveEntryNotFoundError";
	}
	static is(error) {
		return error?.name === "LiveEntryNotFoundError";
	}
};
var LiveCollectionValidationError = class extends LiveCollectionError {
	constructor(collection, entryId, error) {
		super(collection, [
			`**${collection} \u2192 ${entryId}** data does not match the collection schema.
`,
			...formatZodError(error),
			""
		].join("\n"));
		this.name = "LiveCollectionValidationError";
	}
	static is(error) {
		return error?.name === "LiveCollectionValidationError";
	}
};
var LiveCollectionCacheHintError = class extends LiveCollectionError {
	constructor(collection, entryId, error) {
		super(collection, [
			`**${String(collection)}${entryId ? ` \u2192 ${String(entryId)}` : ""}** returned an invalid cache hint.
`,
			...formatZodError(error),
			""
		].join("\n"));
		this.name = "LiveCollectionCacheHintError";
	}
	static is(error) {
		return error?.name === "LiveCollectionCacheHintError";
	}
};
//#endregion
//#region ../../node_modules/.pnpm/astro@7.3.2_@emnapi+core@1.11.1_@emnapi+runtime@1.11.3_@types+node@24.13.5_yaml@2.9.1/node_modules/astro/dist/content/runtime.js
var cacheHintSchema = object({
	tags: array(string()).optional(),
	lastModified: date().optional()
});
async function parseLiveEntry(entry, schema, collection) {
	try {
		const parsed = await safeParseAsync(schema, entry.data);
		if (!parsed.success) return { error: new LiveCollectionValidationError(collection, entry.id, parsed.error) };
		if (entry.cacheHint) {
			const cacheHint = cacheHintSchema.safeParse(entry.cacheHint);
			if (!cacheHint.success) return { error: new LiveCollectionCacheHintError(collection, entry.id, cacheHint.error) };
			entry.cacheHint = cacheHint.data;
		}
		return { entry: {
			...entry,
			data: parsed.data
		} };
	} catch (error) {
		return { error: new LiveCollectionError(collection, `Unexpected error parsing entry ${entry.id} in collection ${collection}`, error) };
	}
}
function createGetCollection({ liveCollections, logger }) {
	return async function getCollection(collection, filter) {
		if (collection in liveCollections) throw new AstroError({
			...UnknownContentCollectionError,
			message: `Collection "${collection}" is a live collection. Use getLiveCollection() instead of getCollection().`
		});
		const hasFilter = typeof filter === "function";
		const store = await globalDataStore.get();
		if (await store.hasCollection(collection)) {
			const { default: imageAssetMap } = await import("./content-assets_C2Ul2W5w.mjs");
			const result = [];
			for (const rawEntry of await store.values(collection)) {
				const data = resolveEntryData(rawEntry, imageAssetMap);
				let entry = {
					...rawEntry,
					data,
					collection
				};
				if (hasFilter && !filter(entry)) continue;
				result.push(entry);
			}
			return result;
		} else {
			logger.warn("content", `The collection ${JSON.stringify(collection)} does not exist or is empty. Please check your content config file for errors.`);
			return [];
		}
	};
}
function createGetEntry({ liveCollections, logger }) {
	return async function getEntry(collectionOrLookupObject, lookup) {
		let collection, lookupId;
		if (typeof collectionOrLookupObject === "string") {
			collection = collectionOrLookupObject;
			if (!lookup) throw new AstroError({
				...UnknownContentCollectionError,
				message: "`getEntry()` requires an entry identifier as the second argument."
			});
			lookupId = lookup;
		} else {
			collection = collectionOrLookupObject.collection;
			lookupId = "id" in collectionOrLookupObject ? collectionOrLookupObject.id : collectionOrLookupObject.slug;
		}
		if (collection in liveCollections) throw new AstroError({
			...UnknownContentCollectionError,
			message: `Collection "${collection}" is a live collection. Use getLiveEntry() instead of getEntry().`
		});
		if (typeof lookupId === "object") throw new AstroError({
			...UnknownContentCollectionError,
			message: `The entry identifier must be a string. Received object.`
		});
		const store = await globalDataStore.get();
		if (await store.hasCollection(collection)) {
			const entry = await store.get(collection, lookupId);
			if (!entry) {
				logger.warn("content", `Entry ${collection} → ${lookupId} was not found.`);
				return;
			}
			const { default: imageAssetMap } = await import("./content-assets_C2Ul2W5w.mjs");
			const data = resolveEntryData(entry, imageAssetMap);
			const result = {
				...entry,
				data,
				collection
			};
			warnForPropertyAccess(logger, result.data, "slug", `[content] Attempted to access deprecated property on "${collection}" entry.
The "slug" property is no longer automatically added to entries. Please use the "id" property instead.`);
			warnForPropertyAccess(logger, result, "render", `[content] Invalid attempt to access "render()" method on "${collection}" entry.
To render an entry, use "render(entry)" from "astro:content".`);
			return result;
		}
	};
}
function warnForPropertyAccess(logger, entry, prop, message) {
	if (!(prop in entry)) {
		let _value = void 0;
		Object.defineProperty(entry, prop, {
			get() {
				if (_value === void 0) logger.error("content", message);
				return _value;
			},
			set(v) {
				_value = v;
			},
			enumerable: false
		});
	}
}
function createGetLiveCollection({ liveCollections }) {
	return async function getLiveCollection(collection, filter) {
		if (!(collection in liveCollections)) return { error: new LiveCollectionError(collection, `Collection "${collection}" is not a live collection. Use getCollection() instead of getLiveCollection() to load regular content collections.`) };
		try {
			const context = {
				filter,
				collection
			};
			const response = await liveCollections[collection].loader?.loadCollection?.(context);
			if (response && "error" in response) return { error: response.error };
			const { schema } = liveCollections[collection];
			let processedEntries = response.entries;
			if (schema) {
				const entryResults = await Promise.all(response.entries.map((entry) => parseLiveEntry(entry, schema, collection)));
				for (const result of entryResults) if (result.error) return { error: result.error };
				processedEntries = entryResults.map((result) => result.entry);
			}
			let cacheHint = response.cacheHint;
			if (cacheHint) {
				const cacheHintResult = cacheHintSchema.safeParse(cacheHint);
				if (!cacheHintResult.success) return { error: new LiveCollectionCacheHintError(collection, void 0, cacheHintResult.error) };
				cacheHint = cacheHintResult.data;
			}
			if (processedEntries.length > 0) {
				const entryTags = /* @__PURE__ */ new Set();
				let latestModified;
				for (const entry of processedEntries) if (entry.cacheHint) {
					if (entry.cacheHint.tags) entry.cacheHint.tags.forEach((tag) => entryTags.add(tag));
					if (entry.cacheHint.lastModified instanceof Date) {
						if (latestModified === void 0 || entry.cacheHint.lastModified > latestModified) latestModified = entry.cacheHint.lastModified;
					}
				}
				if (entryTags.size > 0 || latestModified || cacheHint) {
					const mergedCacheHint = {};
					if (cacheHint?.tags || entryTags.size > 0) mergedCacheHint.tags = [.../* @__PURE__ */ new Set([...cacheHint?.tags || [], ...entryTags])];
					if (cacheHint?.lastModified && latestModified) mergedCacheHint.lastModified = cacheHint.lastModified > latestModified ? cacheHint.lastModified : latestModified;
					else if (cacheHint?.lastModified || latestModified) mergedCacheHint.lastModified = cacheHint?.lastModified ?? latestModified;
					cacheHint = mergedCacheHint;
				}
			}
			return {
				entries: processedEntries,
				cacheHint
			};
		} catch (error) {
			return { error: new LiveCollectionError(collection, `Unexpected error loading collection ${collection}${error instanceof Error ? `: ${error.message}` : ""}`, error) };
		}
	};
}
function createGetLiveEntry({ liveCollections }) {
	return async function getLiveEntry(collection, lookup) {
		if (!(collection in liveCollections)) return { error: new LiveCollectionError(collection, `Collection "${collection}" is not a live collection. Use getCollection() instead of getLiveEntry() to load regular content collections.`) };
		try {
			const lookupObject = {
				filter: typeof lookup === "string" ? { id: lookup } : lookup,
				collection
			};
			let entry = await liveCollections[collection].loader?.loadEntry?.(lookupObject);
			if (entry && "error" in entry) return { error: entry.error };
			if (!entry) return { error: new LiveEntryNotFoundError(collection, lookup) };
			const { schema } = liveCollections[collection];
			if (schema) {
				const result = await parseLiveEntry(entry, schema, collection);
				if (result.error) return { error: result.error };
				entry = result.entry;
			}
			return {
				entry,
				cacheHint: entry.cacheHint
			};
		} catch (error) {
			return { error: new LiveCollectionError(collection, `Unexpected error loading entry ${collection} → ${typeof lookup === "string" ? lookup : JSON.stringify(lookup)}`, error) };
		}
	};
}
var CONTENT_LAYER_IMAGE_REGEX = /__ASTRO_IMAGE_="([^"]+)"/g;
async function updateImageReferencesInBody(html, fileName) {
	const { default: imageAssetMap } = await import("./content-assets_C2Ul2W5w.mjs");
	const imageObjects = /* @__PURE__ */ new Map();
	const { getImage } = await import("./_virtual_astro_get-image_D3LRg_u_.mjs");
	for (const [_full, imagePath] of html.matchAll(CONTENT_LAYER_IMAGE_REGEX)) try {
		const decodedImagePath = JSON.parse(imagePath.replace(/&(?:#x22|quot);/g, "\"").replace(/&(?:#x27|apos);/g, "'"));
		let image;
		if (URL.canParse(decodedImagePath.src)) image = await getImage(decodedImagePath);
		else {
			const id = imageSrcToImportId(decodedImagePath.src, fileName);
			const imported = imageAssetMap.get(id);
			if (!id || imageObjects.has(id) || !imported) continue;
			image = await getImage({
				...decodedImagePath,
				src: imported
			});
		}
		imageObjects.set(imagePath, image);
	} catch {
		throw new Error(`Failed to parse image reference: ${imagePath}`);
	}
	return html.replaceAll(CONTENT_LAYER_IMAGE_REGEX, (full, imagePath) => {
		const image = imageObjects.get(imagePath);
		if (!image) return full;
		const { index, ...attributes } = image.attributes;
		return Object.entries({
			...attributes,
			src: image.src,
			...image.srcSet.values.length > 0 ? { srcset: image.srcSet.attribute } : {}
		}).filter(([, value]) => value != null).map(([key, value]) => value === "" ? `${key}=""` : `${key}="${escape(String(value))}"`).join(" ");
	});
}
function resolveImageAtPath(src, fileName, imageAssetMap) {
	const id = imageSrcToImportId(src, fileName);
	if (!id) return;
	const imported = imageAssetMap?.get(id);
	if (!imported) return;
	if (imported.__svgData) {
		const { __svgData: svgData, ...meta } = imported;
		return createSvgComponent({
			meta,
			...svgData
		});
	}
	return imported;
}
function setAtPathCopying(target, path, value) {
	if (path.length === 0) return target;
	const [key, ...rest] = path;
	const copy = Array.isArray(target) ? target.slice() : { ...target };
	copy[key] = rest.length === 0 ? value : setAtPathCopying(copy[key], rest, value);
	return copy;
}
function updateImageReferencesInData(data, fileName, imageAssetMap, imageImports) {
	if (!imageImports?.length) return data;
	let result = data;
	for (const path of imageImports) {
		let src = result;
		for (const key of path) src = src?.[key];
		if (typeof src !== "string") continue;
		const resolved = resolveImageAtPath(src, fileName, imageAssetMap);
		if (resolved !== void 0) result = setAtPathCopying(result, path, resolved);
	}
	return result;
}
function resolveEntryData(entry, imageAssetMap) {
	return updateImageReferencesInData(entry.data, entry.filePath, imageAssetMap, entry.imageImports);
}
function createRenderEntry({ logger }) {
	return async function renderEntry(entry) {
		if (!entry) throw new AstroError(RenderUndefinedEntryError);
		recordContentEntryRender(entry.filePath);
		if (entry.deferredRender) try {
			const { default: contentModules } = await import("./content-modules_oGlFYU7s.mjs");
			const renderEntryImport = contentModules.get(entry.filePath);
			return render$1({
				collection: "",
				id: entry.id,
				renderEntryImport
			});
		} catch (e) {
			logger.error("content", `${e}`);
		}
		const html = entry?.rendered?.metadata?.imagePaths?.length && entry.filePath ? await updateImageReferencesInBody(entry.rendered.html, entry.filePath) : entry?.rendered?.html;
		return {
			Content: createComponent(() => renderTemplate`${unescapeHTML(html)}`),
			headings: entry?.rendered?.metadata?.headings ?? [],
			remarkPluginFrontmatter: entry?.rendered?.metadata?.frontmatter ?? {}
		};
	};
}
async function render$1({ collection, id, renderEntryImport }) {
	const UnexpectedRenderError = new AstroError({
		...UnknownContentCollectionError,
		message: `Unexpected error while rendering ${String(collection)} → ${String(id)}.`
	});
	if (typeof renderEntryImport !== "function") throw UnexpectedRenderError;
	const baseMod = await renderEntryImport();
	if (baseMod == null || typeof baseMod !== "object") throw UnexpectedRenderError;
	const { default: defaultMod } = baseMod;
	if (isPropagatedAssetsModule(defaultMod)) {
		const { collectedStyles, collectedLinks, collectedScripts, getMod } = defaultMod;
		if (typeof getMod !== "function") throw UnexpectedRenderError;
		const propagationMod = await getMod();
		if (propagationMod == null || typeof propagationMod !== "object") throw UnexpectedRenderError;
		return {
			Content: createComponent({
				factory(result, baseProps, slots) {
					let styles = "", links = "", scripts = "";
					if (Array.isArray(collectedStyles)) styles = collectedStyles.map((style) => {
						return renderUniqueStylesheet(result, {
							type: "inline",
							content: style
						});
					}).join("");
					if (Array.isArray(collectedLinks)) links = collectedLinks.map((link) => {
						return renderUniqueStylesheet(result, {
							type: "external",
							src: isRemotePath(link) ? link : prependForwardSlash(link)
						});
					}).join("");
					if (Array.isArray(collectedScripts)) scripts = collectedScripts.map((script) => renderScriptElement(script)).join("");
					let props = baseProps;
					if (id.endsWith("mdx")) props = {
						components: propagationMod.components ?? {},
						...baseProps
					};
					return createHeadAndContent(unescapeHTML(styles + links + scripts), renderTemplate`${renderComponent(result, "Content", propagationMod.Content, props, slots)}`);
				},
				propagation: "self"
			}),
			headings: propagationMod.getHeadings?.() ?? [],
			remarkPluginFrontmatter: propagationMod.frontmatter ?? {}
		};
	} else if (baseMod.Content && typeof baseMod.Content === "function") return {
		Content: baseMod.Content,
		headings: baseMod.getHeadings?.() ?? [],
		remarkPluginFrontmatter: baseMod.frontmatter ?? {}
	};
	else throw UnexpectedRenderError;
}
function isPropagatedAssetsModule(module) {
	return typeof module === "object" && module != null && "__astroPropagation" in module;
}
//#endregion
//#region \0astro:content
var liveCollections = {};
var logger = createConsoleLogger({ level });
var getCollection = createGetCollection({
	liveCollections,
	logger
});
createGetEntry({
	liveCollections,
	logger
});
createRenderEntry({ logger });
createGetLiveCollection({ liveCollections });
createGetLiveEntry({ liveCollections });
//#endregion
//#region src/components/booking/store.ts
var STORAGE_KEY = "kaiyue.booking.journey";
var emptyDraft = (serviceType = "airport_transfer") => ({
	serviceType,
	pickupLocation: "",
	destination: "",
	pickupAt: "",
	returnAt: "",
	passengerCount: 2,
	durationHours: 2,
	luggageCount: "0",
	handCarryCount: "0",
	tourGuideRequested: null,
	vehiclePreference: "",
	communicationChannel: "whatsapp",
	contactName: "",
	phone: "",
	email: "",
	company: "",
	notes: "",
	tourPackageId: "",
	tourPackageTitle: "",
	message: "",
	privacyAccepted: false,
	locale: "en"
});
function defaultContext() {
	return {
		mode: "bottom-sheet",
		sourcePage: "/",
		sourceTrigger: "header",
		enquiryKind: "standard"
	};
}
function createState() {
	return {
		status: "closed",
		open: false,
		step: 1,
		draft: emptyDraft(),
		context: defaultContext(),
		idempotencyKey: createIdempotencyKey(),
		fieldErrors: {}
	};
}
var state = createState();
var listeners = /* @__PURE__ */ new Set();
function emit() {
	for (const listener of listeners) listener();
}
function restoreJourney() {
	if (typeof sessionStorage === "undefined") return null;
	const raw = sessionStorage.getItem(STORAGE_KEY);
	if (!raw) return null;
	try {
		const parsed = JSON.parse(raw);
		if (parsed.savedAt && Date.now() - parsed.savedAt > 216e5) {
			sessionStorage.removeItem(STORAGE_KEY);
			return null;
		}
		return parsed;
	} catch {
		return null;
	}
}
function isDirty(draft) {
	const empty = emptyDraft(draft.serviceType);
	return draft.pickupLocation !== empty.pickupLocation || draft.destination !== empty.destination || draft.pickupAt !== empty.pickupAt || draft.contactName !== empty.contactName || draft.phone !== empty.phone || draft.message !== empty.message || draft.tourPackageId !== empty.tourPackageId || draft.tourGuideRequested !== empty.tourGuideRequested;
}
function withoutEmpty(value) {
	if (!value) return {};
	return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== void 0));
}
function openBooking(context) {
	const restored = withoutEmpty(restoreJourney());
	const enquiryKind = context.enquiryKind ?? state.context.enquiryKind ?? "standard";
	const serviceType = enquiryKind === "special_offer" ? "city_tour" : context.initialTourPackageId ? "city_tour" : context.initialServiceType ?? restored.serviceType ?? state.draft.serviceType;
	const cityTour = serviceType === "city_tour";
	const hourly = serviceType === "hourly_charter";
	const nextContext = {
		...context,
		enquiryKind
	};
	const draft = {
		...state.draft,
		...restored,
		serviceType,
		destination: cityTour || hourly ? "" : restored.destination ?? state.draft.destination,
		returnAt: cityTour || hourly ? "" : restored.returnAt ?? state.draft.returnAt,
		tourPackageId: cityTour ? context.initialTourPackageId ?? state.draft.tourPackageId ?? restored.tourPackageId ?? "" : "",
		tourPackageTitle: cityTour ? context.initialTourPackageTitle ?? state.draft.tourPackageTitle ?? restored.tourPackageTitle ?? "" : ""
	};
	state = {
		...state,
		open: true,
		status: isDirty(draft) ? "open.editing" : "open.pristine",
		context: nextContext,
		draft,
		fieldErrors: {},
		formError: void 0
	};
	emit();
}
//#endregion
//#region src/components/booking/BookingLauncher.tsx
var import_jsx_runtime = require_jsx_runtime();
function BookingLauncher({ label = "Book now", mode = "bottom-sheet", sourcePage, sourceTrigger, serviceType, tourPackageId, tourPackageTitle, className = "btn btn--primary" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className,
		onClick: () => openBooking({
			mode,
			sourcePage,
			sourceTrigger,
			initialServiceType: tourPackageId ? "city_tour" : serviceType,
			initialTourPackageId: tourPackageId,
			initialTourPackageTitle: tourPackageTitle
		}),
		children: label
	});
}
//#endregion
//#region src/lib/site.ts
var site = {
	name: "Kai Yue Travel",
	legalName: "Kai Yue Travel Group Limited",
	legalNameZh: "凱悅旅遊集團有限公司",
	groupLegalName: "Kai Yue Group Limited",
	groupLegalNameZh: "凱悅集團有限公司",
	chineseName: "凱悅旅遊",
	chineseGroupName: "凱悅旅遊集團有限公司",
	tagline: "Your reliable private chauffeur across the Greater Bay Area",
	description: "Explore private chauffeur services across Macau, Mainland China, and Hong Kong for airport transfers, local rides, Macau city tours, and chauffeur hire by the hour. Choose the journey that suits your plans.",
	url: "https://example.invalid",
	phone: "+853 2833 8882",
	fax: "+853 2833 8885",
	businessPhones: [
		"+853 6366 6665",
		"+853 6654 8888",
		"+853 6588 9999"
	],
	addressLines: [
		"600-E Avenida do Dr. Rodrigo Rodrigues",
		"First International Commercial Centre, 16/F, P16-07",
		"Macau"
	],
	addressLocal: "澳門羅理基博士大馬路600-E號 第一國際商業中心16樓P16-07",
	timezone: "Asia/Macau",
	locale: "en",
	contentStatus: "b2c-conservative-b2b-group-portfolio",
	logo: "/images/kai-yue-travel-group-logo.png",
	defaultOgImage: "/images/illustrative/home-hero-family-v2.jpg"
};
[
	{
		slug: "airport-transfer",
		heroImage: "/images/illustrative/airport-transfer-hero.jpg",
		heroImageAlt: "Illustrative airport pickup with travelers meeting a chauffeur beside a private vehicle",
		featuredImage: "/images/illustrative/airport-transfer-feature.jpg",
		featuredImageAlt: "Illustrative airport transfer with luggage being loaded beside a private vehicle",
		serviceType: "airport_transfer",
		title: "Airport transfer",
		h1: "Private airport transfer",
		seoTitle: "Airport Transfer — Private Chauffeur",
		seoDescription: "Private chauffeur transfers to and from airports in Macau, Mainland China, and Hong Kong, connecting arriving and departing guests with hotels and local addresses.",
		summary: "Private airport pickup and drop-off between an airport and a hotel or local address in Macau, Mainland China, or Hong Kong.",
		overviewHeading: "Airport arrivals and departures",
		detailsHeading: "Airport transfer journeys",
		description: "Plan a direct airport journey around your flight time, with space to share your hotel, meeting point, passenger count, and luggage needs.",
		intro: "Travel between an airport in Macau, Mainland China, or Hong Kong and a hotel, home, or other local address with a private chauffeur. Airport transfers suit arrivals, departures, and guests carrying luggage who want one planned journey between the terminal and their destination.",
		whoFor: [
			"Arriving guests who want a pre-arranged pickup",
			"Departing travelers going from a hotel or home to the airport",
			"Families or groups travelling with luggage"
		],
		process: [
			"Connect the airport with your hotel or another local address. Add your flight time and preferred meeting point.",
			"Travel from a hotel, home, or other pickup point to the airport. Choose a pickup time that fits your departure plans.",
			"Include the number of travellers and luggage so the journey can be planned around your party."
		],
		useCases: [
			"Airport arrivals",
			"Airport departures",
			"Groups and luggage"
		],
		included: [
			"Private chauffeur request",
			"Meet-and-greet details you provide",
			"Flight timing notes"
		],
		notIncluded: ["Guaranteed live flight tracking", "Automatic confirmation"],
		quoteBasis: "One-way transfer: pickup, drop-off, timing, passengers, and luggage",
		icon: "plane",
		faqs: [{
			question: "Do you wait if a flight is delayed?",
			answer: "Add the flight details and expected delay notes on the form. Waiting time is reviewed with the request and confirmed by the team, not assumed."
		}, {
			question: "Can I book a same-day airport transfer?",
			answer: "The form asks for at least 24 hours’ notice. Same-day airport requests may be reviewed, but they are not guaranteed."
		}]
	},
	{
		slug: "cross-border-rides",
		heroImage: "/images/illustrative/cross-border-rides-hero.jpg",
		heroImageAlt: "Illustrative travelers discussing an onward journey beside a private vehicle",
		featuredImage: "/images/illustrative/cross-border-rides-feature.jpg",
		featuredImageAlt: "Illustrative itinerary discussion beside a private vehicle in Macau",
		serviceType: "point_to_point",
		title: "Cross border rides",
		h1: "Cross-border car journeys",
		seoTitle: "Cross-Border Private Car — Journey Enquiry",
		seoDescription: "Enquire about a private car journey between Macau, Mainland China, and Hong Kong. Share both addresses, preferred crossing, and travel date for route planning.",
		summary: "Plan a private journey between Macau, Mainland China, and Hong Kong.",
		overviewHeading: "Journeys across the Greater Bay Area",
		detailsHeading: "Cross-border journey details",
		description: "Cross-border travel depends on the origin, destination, crossing point, and journey date. Share those details to discuss a route that fits your plans.",
		intro: "This enquiry is for a private car journey between Macau, Mainland China, and Hong Kong. It helps to provide both addresses, the intended crossing, and your travel date. Crossing options and vehicle availability vary by journey.",
		whoFor: [
			"Guests travelling between Macau, Mainland China, and Hong Kong",
			"Companies moving staff between offices in these regions",
			"Hotels arranging onward journeys for guests"
		],
		process: [
			"Describe the pickup and destination in Macau, Mainland China, or Hong Kong, including the crossing you expect to use.",
			"Give both addresses and the time you hope to arrive.",
			"Border route, passenger documents, and vehicle eligibility all affect how the journey can be arranged."
		],
		useCases: [
			"Macau, Mainland China, and Hong Kong",
			"Onward connections",
			"Crossing requirements"
		],
		included: ["Journey request", "Crossing and document notes you provide"],
		notIncluded: ["Guaranteed border clearance times", "Automatic confirmation"],
		quoteBasis: "Cross-border journey: both addresses, crossing point, timing, and passengers",
		icon: "route",
		faqs: [{
			question: "Is a cross-border ride confirmed when I submit the form?",
			answer: "No. The form stores a request. Eligibility, documentation, and availability are reviewed by a person, and confirmation is separate."
		}, {
			question: "Which crossing points do you use?",
			answer: "State the crossing point you need in the notes. Whether that crossing can be used for your journey is confirmed after review, not assumed on this page."
		}]
	},
	{
		slug: "local-transfers",
		heroImage: "/images/illustrative/local-transfers-hero.jpg",
		heroImageAlt: "Illustrative guest arriving by private vehicle at a Macau venue",
		featuredImage: "/images/illustrative/local-transfers-feature.jpg",
		featuredImageAlt: "Illustrative local drop-off with a chauffeur helping a guest from a private vehicle",
		serviceType: "point_to_point",
		title: "Local transfers",
		h1: "Local transfers",
		seoTitle: "Private Local Transfers — Chauffeur Service",
		seoDescription: "Private local transfers in Macau, Mainland China, or Hong Kong for hotel, restaurant, meeting, and venue journeys. Travel directly between two addresses with a chauffeur.",
		summary: "Private chauffeur journeys between hotels, restaurants, offices, and venues in Macau, Mainland China, or Hong Kong.",
		overviewHeading: "Direct journeys in the same city",
		detailsHeading: "Local transfer ideas",
		description: "A local transfer fits a known pickup and destination when you need one direct ride rather than several stops or an hourly vehicle.",
		intro: "Local transfers are private chauffeur journeys that start and finish in the same city in Macau, Mainland China, or Hong Kong. Use this request for a hotel to restaurant drop-off, an office to venue move, or any single journey between two local addresses that is not an airport or hourly request.",
		whoFor: [
			"Guests moving between venues in the same city",
			"Residents who need a single private journey",
			"Hosts arranging pickups for visiting guests"
		],
		process: [
			"Travel between a hotel and a restaurant or other local address.",
			"Move from an office to a meeting, event venue, or client appointment.",
			"Choose one pickup and one drop-off for a direct local journey without an hourly itinerary."
		],
		useCases: [
			"Hotel and dining",
			"Office and events",
			"Direct one-way travel"
		],
		included: ["Private vehicle request", "Passenger and luggage notes"],
		notIncluded: ["Waiting time unless requested as an hourly service"],
		quoteBasis: "Local journey: pickup, destination, timing, and passenger count",
		icon: "building",
		faqs: [{
			question: "How is this different from a point-to-point request?",
			answer: "It is the same one-way journey model. Choose this when both addresses are in the same city and you are not arranging an airport pickup or drop-off."
		}, {
			question: "Can I add stops along the way?",
			answer: "List extra stops in the notes. Several stops or an open itinerary are usually better requested as an hourly service with a dedicated chauffeur."
		}]
	},
	{
		slug: "local-chauffeur",
		heroImage: "/images/illustrative/local-chauffeur-hero-v2.jpg",
		heroImageAlt: "Illustrative view from the rear passenger area of a chauffeur driving through Macau",
		featuredImage: "/images/illustrative/local-chauffeur-feature.jpg",
		featuredImageAlt: "Illustrative chauffeur waiting with a private vehicle between appointments",
		serviceType: "hourly_charter",
		title: "Local chauffeur",
		h1: "Local chauffeur by the hour",
		seoTitle: "Local Chauffeur by the Hour — Dedicated Private Car",
		seoDescription: "Keep a private chauffeur and vehicle by the hour in Macau, Mainland China, or Hong Kong for meetings, errands, and multiple stops on one flexible local itinerary.",
		summary: "One private vehicle and chauffeur for a planned block of hours.",
		overviewHeading: "Keep a car for your itinerary",
		detailsHeading: "Ways to use a local chauffeur",
		description: "A local chauffeur by the hour suits days with several stops, time between meetings, or plans that may change along the way.",
		intro: "Keep one private vehicle and chauffeur for a planned block of hours in Macau, Mainland China, or Hong Kong instead of booking separate rides for each stop. This service fits meetings across the city, family errands, or a flexible outing with waiting time between destinations.",
		whoFor: [
			"Guests with several stops in one outing",
			"Companies moving executives between meetings",
			"Families who want the same vehicle for a half-day"
		],
		process: [
			"Visit more than one address in the same city during the same planned time block.",
			"Keep the vehicle for travel between business appointments or event venues.",
			"Share a starting point and broad plan while leaving room to adjust the order of stops."
		],
		useCases: [
			"Several local stops",
			"Business appointments",
			"Flexible outings"
		],
		included: ["Time-block request", "Itinerary notes"],
		notIncluded: ["Unlimited overtime without confirmation"],
		quoteBasis: "Time block: requested hours, itinerary notes, and vehicle preference",
		icon: "clock",
		faqs: [{
			question: "How many hours should I request?",
			answer: "Estimate the time you genuinely need, including waiting between stops. The team confirms the block after review."
		}, {
			question: "Is a destination required?",
			answer: "Not for an hourly booking. Still describe the area and likely stops so the review is realistic."
		}]
	},
	{
		slug: "weddings",
		heroImage: "/images/illustrative/weddings-hero.jpg",
		heroImageAlt: "Illustrative couple arriving by private vehicle for a wedding in Macau",
		featuredImage: "/images/illustrative/weddings-feature.jpg",
		featuredImageAlt: "Illustrative wedding guests boarding a private vehicle between venues",
		serviceType: "hourly_charter",
		title: "Weddings",
		h1: "Wedding chauffeur transport",
		seoTitle: "Wedding Chauffeur — Private Car Transport",
		seoDescription: "Plan private chauffeur transport for a wedding in Macau, Mainland China, or Hong Kong, from ceremony arrivals and photo stops to guest journeys between venues.",
		summary: "Private car journeys for ceremony arrivals, photo stops, and wedding guests.",
		overviewHeading: "Travel around the wedding schedule",
		detailsHeading: "Wedding day journeys",
		description: "Wedding transport can cover several timed movements in one day, with the schedule, passenger groups, and venue addresses shaping the plan.",
		intro: "A wedding day may involve travel to the ceremony, stops for photographs, and guest movements between venues. Private chauffeur transport can be planned around those separate journeys and their timing. Decoration and in-car styling are outside the transport service.",
		whoFor: [
			"Couples arranging ceremony and reception transport",
			"Planners coordinating guest movements between venues",
			"Families who need several vehicles on the same day"
		],
		process: [
			"Plan how the couple, family, and guests will arrive at the ceremony location.",
			"Allow for travel between venues or photo locations within the day's schedule.",
			"Describe guest groups and timing when more than one vehicle or movement is needed."
		],
		useCases: [
			"Ceremony arrivals",
			"Photo stops",
			"Guest shuttles"
		],
		included: ["Vehicle request per movement", "Schedule notes you provide"],
		notIncluded: ["In-car decoration or styling", "Automatic confirmation"],
		quoteBasis: "Wedding day: schedule, movements, vehicle count, and hours needed",
		icon: "map",
		faqs: [{
			question: "Can we request several vehicles for the same day?",
			answer: "Yes. List each movement and how many passengers it covers so the team can review how many vehicles the schedule actually needs."
		}, {
			question: "How early should we send a wedding request?",
			answer: "The form asks for at least 24 hours' notice, but wedding days involve several movements. Sending the schedule early leaves room for review and confirmation."
		}]
	},
	{
		slug: "city-tours",
		heroImage: "/images/illustrative/city-tours-hero.jpg",
		heroImageAlt: "Illustrative visitors enjoying a Macau city stop near their private vehicle",
		featuredImage: "/images/illustrative/city-tours-feature.jpg",
		featuredImageAlt: "Illustrative visitors returning to their private vehicle between Macau sights",
		serviceType: "hourly_charter",
		title: "City tours",
		h1: "City tours with a private chauffeur",
		seoTitle: "Private Macau City Tours by the Hour — Chauffeur Transport",
		seoDescription: "Explore Macau by private car with a chauffeur for a planned block of hours. Suggest city sights, photo stops, and a pace that suits your group.",
		summary: "A private city tour by the hour, with stops and pace you suggest.",
		overviewHeading: "Discover Macau between stops",
		detailsHeading: "Shape your city outing",
		description: "Suggest the places you want to see and how long you want. This is private transport, not a ticketed guided tour.",
		intro: "Explore Macau sights in a private vehicle for a planned block of hours. Choose the places that interest your group, leave time for photographs and breaks, and move between stops with a chauffeur. Attraction admission and licensed guiding are separate from transport.",
		whoFor: [
			"Visitors with a short list of Macau stops and a preferred pace",
			"Families touring with children and luggage in the car",
			"Hosts showing arriving guests around the city"
		],
		process: [
			"Build your outing around the Macau sights your group most wants to visit.",
			"Choose how long to spend at each stop, including time for photos or breaks.",
			"Keep your party together in one private car between the places on your list."
		],
		useCases: [
			"Macau sights",
			"Photo stops and breaks",
			"Travel together"
		],
		included: ["Time-block request", "Stop list and pace notes"],
		notIncluded: ["Guided tour tickets or attraction admission"],
		quoteBasis: "City tour: start time, suggested stops, hours needed, and passenger count",
		icon: "map",
		faqs: [{
			question: "Does the chauffeur act as a tour guide?",
			answer: "This is a private transport request. Licensed guiding and attraction tickets are not included unless separately confirmed."
		}, {
			question: "Can we change the order of stops on the day?",
			answer: "You can, within the hours you requested. Adding time beyond the confirmed block is reviewed with the team rather than assumed."
		}]
	}
].map((service) => ({
	href: `/services/${service.slug}`,
	label: service.title
}));
/**
* Service groups feed the homepage service cards. The header and footer add
* City Tours as its own group of package links.
*/
var serviceGroups = [{
	label: "Point To Point",
	children: [
		{
			href: "/services/airport-transfer",
			label: "Airport Transfer"
		},
		{
			href: "/services/cross-border-rides",
			label: "Cross Border Rides"
		},
		{
			href: "/services/local-transfers",
			label: "Local Transfers"
		}
	]
}, {
	label: "By The Hour",
	children: [
		{
			href: "/services/local-chauffeur",
			label: "Local Chauffeur"
		},
		{
			href: "/services/weddings",
			label: "Weddings"
		},
		{
			href: "/services/city-tours",
			label: "City Tours"
		}
	]
}];
var cityTourLinks = [{
	href: "/services/city-tours/half-day",
	label: "Half day"
}, {
	href: "/services/city-tours/full-day",
	label: "Full day"
}];
var serviceMenus = serviceGroups.map((group) => ({
	...group,
	children: group.children.filter((child) => child.href !== "/services/city-tours")
}));
var nav = [
	...serviceMenus,
	{
		label: "City Tours",
		children: cityTourLinks
	},
	{
		href: "/special-offers",
		label: "Special Offers"
	},
	{
		label: "Business",
		children: [
			{
				href: "/business/travel-agency",
				label: "Travel agency"
			},
			{
				href: "/corporate",
				label: "Corporate solution"
			},
			{
				href: "/business/hotels-resorts",
				label: "Hotels & resorts"
			}
		]
	}
];
var footerServiceGroups = [
	...serviceMenus,
	{
		label: "City Tours",
		children: cityTourLinks
	},
	{
		label: "Special Offers",
		children: [{
			href: "/special-offers",
			label: "Current offers"
		}]
	}
];
//#endregion
//#region src/components/content/SiteLogo.astro
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$SiteLogo = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$SiteLogo;
	const { loading = "eager" } = Astro.props;
	return renderTemplate`${maybeRenderHead($$result)}<a class="logo" href="/"><picture><source type="image/webp" srcset="/images/kai-yue-travel-group-logo.webp"><img class="logo-image"${addAttribute(site.logo, "src")} alt="Kai Yue Travel Group" width="624" height="122"${addAttribute(loading, "loading")} decoding="async"></picture></a>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/components/content/SiteLogo.astro", void 0);
//#endregion
//#region src/components/content/WeChatQr.astro
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var WECHAT_QR_SRC = "/images/wechat-qr.svg";
var $$WeChatQr = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$WeChatQr;
	const { variant = "page" } = Astro.props;
	return renderTemplate`${maybeRenderHead($$result)}<figure${addAttribute(["wechat-qr", `wechat-qr--${variant}`], "class:list")}><div class="wechat-qr__frame"><img${addAttribute(WECHAT_QR_SRC, "src")}${addAttribute(160, "width")}${addAttribute(160, "height")} alt="WeChat QR – coming soon" loading="lazy" decoding="async"><span class="wechat-qr__label" aria-hidden="true">WeChat QR – coming soon</span></div><figcaption class="wechat-qr__caption">WeChat</figcaption></figure>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/components/content/WeChatQr.astro", void 0);
//#endregion
//#region src/layouts/BaseLayout.astro
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$BaseLayout = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$BaseLayout;
	const { title, description = site.description, noindex = false, showMobileBook = true, bookingEnabled = false, ogImage = site.defaultOgImage, preserveMetadata = false, specialOffers } = Astro.props;
	const origin = Astro.site ?? site.url;
	const canonical = new URL(Astro.url.pathname, origin).toString();
	const ogImageUrl = new URL(ogImage, origin).toString();
	const locale = localeFromPath(Astro.url.pathname);
	const path = stripLocale(Astro.url.pathname);
	const isHome = path === "/";
	const tourPackages = bookingEnabled ? (await getCollection("cityTours", ({ id, data }) => data.status !== "hidden" && id !== "special-offer")).sort((a, b) => a.data.order - b.data.order || a.id.localeCompare(b.id)).map(({ id, data }) => {
		return {
			id,
			title: (locale === "en" ? data : data.translations?.[locale] ?? data).title,
			durationHours: data.durationHours ?? null
		};
	}) : [];
	function isCurrent(href) {
		return href === "/" ? path === "/" : path === href || path.startsWith(`${href}/`);
	}
	function isSectionCurrent(item) {
		if ("children" in item && item.children) return item.children.some((child) => isCurrent(child.href));
		return Boolean("href" in item && item.href && isCurrent(item.href));
	}
	return renderTemplate`<html${addAttribute(localeTags[locale], "lang")}><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="icon" href="/favicon.ico" sizes="any"><link rel="icon" href="/images/mark.svg" type="image/svg+xml"><title${addAttribute(preserveMetadata || void 0, "data-no-localize")}>${title} · ${site.name}</title><meta name="description"${addAttribute(description, "content")}${addAttribute(preserveMetadata || void 0, "data-no-localize")}><link rel="canonical"${addAttribute(canonical, "href")}>${[
		"en",
		"pt",
		"zh-Hant"
	].map((language) => renderTemplate`<link rel="alternate"${addAttribute(localeTags[language], "hreflang")}${addAttribute(new URL(localePath(path, language), origin).toString(), "href")}>`)}<link rel="alternate" hreflang="x-default"${addAttribute(new URL(path, origin).toString(), "href")}>${noindex && renderTemplate`<meta name="robots" content="noindex, nofollow">`}<meta property="og:title"${addAttribute(`${title} · ${site.name}`, "content")}${addAttribute(preserveMetadata || void 0, "data-no-localize")}><meta property="og:description"${addAttribute(description, "content")}${addAttribute(preserveMetadata || void 0, "data-no-localize")}><meta property="og:url"${addAttribute(canonical, "content")}><meta property="og:locale"${addAttribute(localeTags[locale], "content")}><meta property="og:type" content="website"><meta property="og:image"${addAttribute(ogImageUrl, "content")}><meta name="twitter:card" content="summary_large_image"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" media="print" onload="this.media='all'"><noscript><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet"></noscript>${renderSlot($$result, $$slots["head"])}${bookingEnabled && renderTemplate`<script>(function(){${defineScriptVars({ tourPackages })}
          window.__KY_TOUR_PACKAGES = tourPackages;
        })();<\/script>`}${specialOffers && renderTemplate`<script>(function(){${defineScriptVars({ specialOffers })}
          window.__KY_SPECIAL_OFFERS = specialOffers;
        })();<\/script>`}${renderHead($$result)}</head><body${addAttribute({
		"page-no-mobile-book": !showMobileBook,
		"page-home": isHome
	}, "class:list")}><a class="skip-link" href="#main">Skip to content</a><header class="site-header"><div class="wrap site-header__inner">${renderComponent($$result, "SiteLogo", $$SiteLogo, {})}<nav class="nav nav--pill" aria-label="Primary">${nav.map((item) => "children" in item && item.children ? renderTemplate`<details class="nav-dropdown"><summary${addAttribute({ "is-current": isSectionCurrent(item) }, "class:list")}>${item.label}</summary><ul class="nav-dropdown__menu">${item.children.map((child) => renderTemplate`<li><a${addAttribute(child.href, "href")}${addAttribute(isCurrent(child.href) ? "page" : void 0, "aria-current")}>${child.label}</a></li>`)}</ul></details>` : renderTemplate`<a${addAttribute("href" in item ? item.href : "/", "href")}${addAttribute("href" in item && item.href && isCurrent(item.href) ? "page" : void 0, "aria-current")}>${item.label}</a>`)}<a href="/about"${addAttribute(isCurrent("/about") ? "page" : void 0, "aria-current")}>About Us</a></nav><div class="header-actions"><details class="lang-switch"><summary${addAttribute(`Language, ${localeNames[locale]}`, "aria-label")}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.75"></circle><path d="M3 12h18M12 3c2.5 2.8 3.8 5.8 3.8 9S14.5 18.2 12 21c-2.5-2.8-3.8-5.8-3.8-9S9.5 5.8 12 3Z" stroke="currentColor" stroke-width="1.75"></path></svg>${locale === "en" ? "EN" : locale === "pt" ? "PT" : "繁"}</summary><ul class="lang-switch__menu" data-no-localize><li><a${addAttribute(localePath(path, "en"), "href")} hreflang="en" lang="en"${addAttribute(locale === "en" ? "true" : void 0, "aria-current")}>English</a></li><li><a${addAttribute(localePath(path, "pt"), "href")} hreflang="pt-PT" lang="pt-PT"${addAttribute(locale === "pt" ? "true" : void 0, "aria-current")}>Português</a></li><li><a${addAttribute(localePath(path, "zh-Hant"), "href")} hreflang="zh-Hant" lang="zh-Hant"${addAttribute(locale === "zh-Hant" ? "true" : void 0, "aria-current")}>繁體中文</a></li></ul></details><a class="header-chip"${addAttribute(`https://wa.me/${site.phone.replaceAll(/\D/g, "")}`, "href")} target="_blank" rel="noopener noreferrer" aria-label="General enquiry on WhatsApp"><span class="header-chip__icon" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M20 11.6a8 8 0 0 1-11.8 7L4 20l1.4-4.1A8 8 0 1 1 20 11.6Z" stroke="currentColor" stroke-width="1.75" stroke-linejoin="round"></path><path d="M8.7 8.2c.5 2.7 2.4 4.6 5.1 5.1l1.2-1.2c.2-.2.5-.3.8-.1l1.7.8c.3.1.4.4.4.7-.1 1.1-1 2-2.1 2.1-4.5.3-7.9-3.1-7.6-7.6.1-1.1 1-2 2.1-2.1.3 0 .6.1.7.4l.8 1.7c.1.3.1.6-.1.8L10.5 10" stroke="currentColor" stroke-width="1.35" stroke-linecap="round"></path></svg></span>General Enquiry</a><details class="mobile-nav"><summary class="menu-toggle" aria-label="Site menu"><span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span></summary><nav class="mobile-nav__panel" aria-label="Mobile">${nav.map((item) => "children" in item && item.children ? renderTemplate`<details class="mobile-nav__group"><summary${addAttribute(["mobile-nav__toggle", { "is-current": isSectionCurrent(item) }], "class:list")}>${item.label}</summary><div class="mobile-nav__submenu">${item.children.map((child) => renderTemplate`<a${addAttribute(child.href, "href")}${addAttribute(isCurrent(child.href) ? "page" : void 0, "aria-current")}>${child.label}</a>`)}</div></details>` : renderTemplate`<a${addAttribute("href" in item ? item.href : "/", "href")}${addAttribute("href" in item && item.href && isCurrent(item.href) ? "page" : void 0, "aria-current")}>${item.label}</a>`)}<a class="mobile-nav__about" href="/about"${addAttribute(isCurrent("/about") ? "page" : void 0, "aria-current")}>About Us</a></nav></details></div></div></header><main id="main">${renderSlot($$result, $$slots["default"])}</main>${bookingEnabled && showMobileBook ? renderTemplate`<div class="mobile-book">${renderComponent($$result, "BookingLauncher", BookingLauncher, {
		"client:load": true,
		"sourcePage": Astro.url.pathname,
		"sourceTrigger": "mobile-persistent",
		"label": "Book now",
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/booking/BookingLauncher.tsx",
		"client:component-export": "BookingLauncher"
	})}</div>` : null}<footer class="site-footer"><div class="wrap site-footer__grid"><div>${renderComponent($$result, "SiteLogo", $$SiteLogo, { "loading": "lazy" })}<p>${site.legalName}</p><p class="draft-note">Private bookings on this site are chauffeur requests for Macau, Mainland China, and Hong Kong, quoted after review. Corporate, hotel, and agency programmes follow the Kai Yue Group portfolio.</p><p><a${addAttribute(`tel:${site.phone.replaceAll(" ", "")}`, "href")}>${site.phone}</a></p><p>${site.addressLines.join(", ")}</p>${renderComponent($$result, "WeChatQr", $$WeChatQr, { "variant": "footer" })}</div><div><h2>Services</h2><div class="site-footer__groups">${footerServiceGroups.map((group) => renderTemplate`<div class="site-footer__group"><h3>${group.label}</h3><ul>${group.children.map((item) => renderTemplate`<li><a${addAttribute(item.href, "href")}>${item.label}</a></li>`)}</ul></div>`)}</div></div><div><h2>Company</h2><ul><li><a href="/about">About Us</a></li><li><a href="/contact">Contact</a></li><li><a href="/faq">FAQ</a></li><li><a href="/privacy">Privacy</a></li><li><a href="/terms">Terms</a></li></ul></div><div><h2>B2B Solution</h2><ul><li><a href="/business/hotels-resorts">Hotels &amp; Resorts</a></li><li><a href="/business/travel-agency">Travel Agency</a></li><li><a href="/corporate">Corporate Solutions</a></li></ul></div></div></footer>${bookingEnabled ? renderTemplate`${renderComponent($$result, "BookingSheet", null, {
		"client:only": "react",
		"client:component-hydration": "only",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/booking/BookingSheet.tsx",
		"client:component-export": "BookingSheet"
	})}` : null}${renderScript($$result, "/agent/repos/KaiYue-Travel/apps/web/src/layouts/BaseLayout.astro?astro&type=script&index=0&lang.ts")}${renderScript($$result, "/agent/repos/KaiYue-Travel/apps/web/src/layouts/BaseLayout.astro?astro&type=script&index=1&lang.ts")}</body></html>`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/layouts/BaseLayout.astro", void 0);
//#endregion
//#region src/lib/special-offer-copy.ts
var specialOfferCopy = {
	en: {
		title: "Special Offers",
		description: "Published chauffeur offers with a car and driver. Quotes are confirmed before travel.",
		kicker: "Current offers",
		heading: "Special Offers",
		lede: "These are the published offers that are ready to request. A team member confirms the quote before travel.",
		empty: "There are no published special offers right now. Ask the team about a city tour or a private car and driver.",
		from: "From",
		terms: "Terms",
		book: "Request this offer",
		descriptionHeading: "Description",
		photos: "Photos",
		showPhoto: "Show photo",
		packageLabel: "Package",
		choosePackage: "Choose a package",
		choosePackageError: "Choose a package.",
		enquiryTitle: "Special Offer enquiry",
		enquiryProgress: "Special Offer enquiry",
		continue: "Continue request →",
		close: "Close special offer enquiry",
		heroEyebrow: "Special offers · Greater Bay Area",
		heroTitle: "Current chauffeur offers",
		heroLede: "Choose a published offer, tell us where to collect you, and send a request. The team confirms the quote before travel.",
		browse: "See current offers",
		serviceValue: "Car with driver"
	},
	pt: {
		title: "Ofertas especiais",
		description: "Ofertas de motorista publicadas, com carro e condutor. O orçamento confirma-se antes da viagem.",
		kicker: "Ofertas atuais",
		heading: "Ofertas especiais",
		lede: "Estas são as ofertas publicadas e prontas a pedir. Um membro da equipa confirma o orçamento antes da viagem.",
		empty: "Não há ofertas especiais publicadas neste momento. Fale com a equipa sobre um passeio pela cidade ou um carro com motorista.",
		from: "Desde",
		terms: "Condições",
		book: "Pedir esta oferta",
		descriptionHeading: "Descrição",
		photos: "Fotos",
		showPhoto: "Mostrar foto",
		packageLabel: "Pacote",
		choosePackage: "Escolha um pacote",
		choosePackageError: "Escolha um pacote.",
		enquiryTitle: "Pedido de oferta especial",
		enquiryProgress: "Pedido de oferta especial",
		continue: "Continuar pedido →",
		close: "Fechar o pedido de oferta especial",
		heroEyebrow: "Ofertas especiais · Grande Baía",
		heroTitle: "Ofertas atuais com motorista",
		heroLede: "Escolha uma oferta publicada, diga-nos onde o ir buscar e envie o pedido. A equipa confirma o orçamento antes da viagem.",
		browse: "Ver ofertas atuais",
		serviceValue: "Carro com motorista"
	},
	"zh-Hant": {
		title: "特別優惠",
		description: "已發布的司機包車接送優惠，附車輛及司機。出發前由團隊確認報價。",
		kicker: "最新優惠",
		heading: "特別優惠",
		lede: "以下為已發布、可供申請的優惠。出發前由團隊確認報價。",
		empty: "目前沒有已發布的特別優惠。歡迎向團隊查詢城市遊覽或包車司機服務。",
		from: "起",
		terms: "條款",
		book: "申請此優惠",
		descriptionHeading: "說明",
		photos: "圖片",
		showPhoto: "顯示圖片",
		packageLabel: "套票",
		choosePackage: "選擇套票",
		choosePackageError: "請選擇套票。",
		enquiryTitle: "特別優惠查詢",
		enquiryProgress: "特別優惠查詢",
		continue: "繼續申請 →",
		close: "關閉特別優惠查詢",
		heroEyebrow: "特別優惠 · 大灣區",
		heroTitle: "最新司機包車接送優惠",
		heroLede: "選擇已發布的優惠，告訴我們接載地點，然後送出申請。出發前由團隊確認報價。",
		browse: "查看最新優惠",
		serviceValue: "車輛連司機"
	}
};
function specialOfferUi(locale) {
	return specialOfferCopy[locale];
}
//#endregion
export { renderScript as i, $$BaseLayout as n, $$PageHero as r, specialOfferUi as t };
