globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll, r as __toESM } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, K as createAstro, M as renderTemplate } from "./sequence_Cusz3XDW.mjs";
import { t as require_react } from "./react_BKr1XGtN.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { t as require_jsx_runtime } from "./global_DvSwDXQV.mjs";
import { a as adminLocaleFromCookies, c as localizeCaughtError, u as t } from "./AdminLocaleSwitch_BYs5zYgz.mjs";
import { n as adminFetch, t as $$AdminLayout } from "./AdminLayout_BreuzgnK.mjs";
//#region src/components/admin/InventoryPanel.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function InventoryPanel({ locale }) {
	const [drivers, setDrivers] = (0, import_react.useState)([]);
	const [vehicles, setVehicles] = (0, import_react.useState)([]);
	const [tab, setTab] = (0, import_react.useState)("drivers");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [modal, setModal] = (0, import_react.useState)(false);
	const dialogRef = (0, import_react.useRef)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	async function load() {
		const [driverResult, vehicleResult] = await Promise.all([adminFetch("/api/v1/admin/drivers", { locale }), adminFetch("/api/v1/admin/vehicles", { locale })]);
		setDrivers(driverResult.items);
		setVehicles(vehicleResult.items);
	}
	(0, import_react.useEffect)(() => {
		load().catch((err) => setError(localizeCaughtError(err, locale)));
	}, [locale]);
	(0, import_react.useEffect)(() => {
		const dialog = dialogRef.current;
		if (!dialog) return;
		if (modal && !dialog.open) dialog.showModal();
		if (!modal && dialog.open) dialog.close();
	}, [modal]);
	function openEditor(id) {
		setEditing(id);
		setError("");
		setNotice("");
		setModal(true);
	}
	const selectedDriver = drivers.find((item) => item.id === editing);
	const selectedVehicle = vehicles.find((item) => item.id === editing);
	async function submit(event) {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		const isDriver = tab === "drivers";
		const body = isDriver ? {
			name: form.get("name"),
			phone: form.get("phone"),
			email: form.get("email"),
			notes: form.get("notes"),
			active: form.get("active") === "on"
		} : {
			plateNumber: form.get("plateNumber"),
			makeModel: form.get("makeModel"),
			passengerCapacity: Number(form.get("passengerCapacity")),
			contactName: form.get("contactName"),
			contactPhone: form.get("contactPhone"),
			notes: form.get("notes"),
			active: form.get("active") === "on"
		};
		setSaving(true);
		setError("");
		setNotice("");
		try {
			await adminFetch(`/api/v1/admin/${isDriver ? "drivers" : "vehicles"}${editing ? `/${editing}` : ""}`, {
				method: editing ? "PATCH" : "POST",
				body: JSON.stringify(body),
				locale
			});
			await load();
			setModal(false);
			setEditing(null);
			setNotice(t(locale, isDriver ? "inv.driverSaved" : "inv.vehicleSaved"));
		} catch (err) {
			setError(localizeCaughtError(err, locale));
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "admin-inventory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "admin-list-toolbar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "admin-eyebrow",
						children: t(locale, "inv.eyebrow")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: t(locale, "inv.heading") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "muted",
						children: t(locale, "inv.lead")
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-tabs",
				role: "tablist",
				"aria-label": t(locale, "inv.tabAria"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": tab === "drivers",
					onClick: () => {
						setTab("drivers");
						setEditing(null);
						setModal(false);
					},
					children: [
						t(locale, "inv.drivers"),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: drivers.length })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": tab === "vehicles",
					onClick: () => {
						setTab("vehicles");
						setEditing(null);
						setModal(false);
					},
					children: [
						t(locale, "inv.vehicles"),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: vehicles.length })
					]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "admin-feedback admin-feedback--error",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "admin-feedback",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "admin-inventory-grid admin-inventory-grid--single",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "admin-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "admin-card__heading",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: tab === "drivers" ? t(locale, "inv.roster") : t(locale, "inv.fleet") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn--primary",
							onClick: () => openEditor(null),
							children: tab === "drivers" ? t(locale, "inv.addDriver") : t(locale, "inv.addVehicle")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "admin-resource-list",
						children: [tab === "drivers" ? drivers.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "admin-resource",
							onClick: () => openEditor(item.id),
							"aria-label": t(locale, "inv.editDriverAria", { name: item.name }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [item.phone, item.email ? ` · ${item.email}` : ""] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: item.active ? "admin-active" : "admin-inactive",
								children: item.active ? t(locale, "inv.active") : t(locale, "inv.inactive")
							})]
						}, item.id)) : vehicles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "admin-resource",
							onClick: () => openEditor(item.id),
							"aria-label": t(locale, "inv.editVehicleAria", { plate: item.plateNumber }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
								item.plateNumber,
								" · ",
								item.makeModel
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
								t(locale, "inv.passengers", { count: item.passengerCapacity }),
								item.contactName ? ` · ${item.contactName}` : "",
								item.contactPhone ? ` · ${item.contactPhone}` : ""
							] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: item.active ? "admin-active" : "admin-inactive",
								children: item.active ? t(locale, "inv.active") : t(locale, "inv.inactive")
							})]
						}, item.id)), (tab === "drivers" ? drivers : vehicles).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "muted",
							children: tab === "drivers" ? t(locale, "inv.emptyDriver") : t(locale, "inv.emptyVehicle")
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dialog", {
				ref: dialogRef,
				className: "admin-editor-dialog",
				"aria-labelledby": "admin-editor-title",
				onClose: () => setModal(false),
				onClick: (event) => {
					if (event.target === event.currentTarget) event.currentTarget.close();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "admin-editor-dialog__content",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "admin-card__heading",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "admin-eyebrow",
								children: editing ? t(locale, "inv.editRecord") : t(locale, "inv.newRecord")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "admin-editor-title",
								children: tab === "drivers" ? editing ? t(locale, "inv.editDriver") : t(locale, "inv.addDriverTitle") : editing ? t(locale, "inv.editVehicle") : t(locale, "inv.addVehicleTitle")
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "admin-editor-dialog__close",
								"aria-label": t(locale, "inv.close"),
								onClick: () => dialogRef.current?.close(),
								children: "×"
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "admin-feedback admin-feedback--error",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "admin-resource-form",
							onSubmit: (event) => void submit(event),
							children: [
								tab === "drivers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.name"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "name",
											defaultValue: selectedDriver?.name ?? "",
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.phone"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "phone",
											type: "tel",
											defaultValue: selectedDriver?.phone ?? "",
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.email"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "email",
											type: "email",
											defaultValue: selectedDriver?.email ?? ""
										})]
									})
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.plate"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "plateNumber",
											defaultValue: selectedVehicle?.plateNumber ?? "",
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.makeModel"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "makeModel",
											defaultValue: selectedVehicle?.makeModel ?? "",
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.capacity"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "passengerCapacity",
											type: "number",
											min: "1",
											max: "14",
											defaultValue: selectedVehicle?.passengerCapacity ?? 4,
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.partner"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "contactName",
											defaultValue: selectedVehicle?.contactName ?? ""
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [t(locale, "inv.contactPhone"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "contactPhone",
											type: "tel",
											defaultValue: selectedVehicle?.contactPhone ?? ""
										})]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field field--full",
									children: [t(locale, "inv.notes"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										name: "notes",
										defaultValue: (tab === "drivers" ? selectedDriver?.notes : selectedVehicle?.notes) ?? "",
										rows: 3
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "admin-checkbox",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "active",
											type: "checkbox",
											defaultChecked: (tab === "drivers" ? selectedDriver?.active : selectedVehicle?.active) ?? true
										}),
										" ",
										t(locale, "inv.available")
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn btn--primary",
									disabled: saving,
									children: saving ? t(locale, "inv.saving") : editing ? t(locale, "inv.save") : tab === "drivers" ? t(locale, "inv.addDriverBtn") : t(locale, "inv.addVehicleBtn")
								})
							]
						}, `${tab}-${editing ?? "new"}`)
					]
				})
			})
		]
	});
}
//#endregion
//#region src/pages/admin/inventory.astro
var inventory_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Inventory,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$Inventory = createComponent(($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$Inventory;
	const locale = adminLocaleFromCookies(Astro.cookies);
	return renderTemplate`${renderComponent($$result, "AdminLayout", $$AdminLayout, {
		"titleKey": "title.inventory",
		"locale": locale
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "InventoryPanel", InventoryPanel, {
		"client:load": true,
		"locale": locale,
		"client:component-hydration": "load",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/admin/InventoryPanel.tsx",
		"client:component-export": "InventoryPanel"
	})}` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/inventory.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/admin/inventory.astro";
var $$url = "/admin/inventory";
//#endregion
//#region \0virtual:astro:page:src/pages/admin/inventory@_@astro
var page = () => inventory_exports;
//#endregion
export { page };
