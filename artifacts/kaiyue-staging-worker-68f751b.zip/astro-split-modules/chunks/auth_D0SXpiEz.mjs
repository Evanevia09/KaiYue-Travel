globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as createAdminSessionAuth, t as allowedAdminEmails } from "./admin-session_CiBIbtuM.mjs";
import { d as AppError } from "./src_BRRiv8WF.mjs";
import { c as isAccessAdminHost, d as isProductionHost, i as accessTakesOver, l as isLocalAdminSurface, p as passwordAdminAllowed, r as accessConfigured } from "./admin-gate_CU-fRGZ7.mjs";
//#region src/lib/server/access-jwt.ts
var JWKS_TTL_MS = 36e5;
var jwksCache = /* @__PURE__ */ new Map();
function accessIssuer(teamDomain) {
	return `https://${teamDomain.replace(/^https?:\/\//, "").replace(/\/$/, "")}`;
}
function accessCertsUrl(teamDomain) {
	return `${accessIssuer(teamDomain)}/cdn-cgi/access/certs`;
}
function decodeSegment(segment) {
	const padded = segment.replace(/-/g, "+").replace(/_/g, "/");
	return atob(padded.padEnd(padded.length + (4 - padded.length % 4) % 4, "="));
}
function decodeJwtPayload(token) {
	const parts = token.split(".");
	if (parts.length !== 3 || !parts[1]) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	try {
		return JSON.parse(decodeSegment(parts[1]));
	} catch {
		throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	}
}
function assertAccessClaims(payload, issuer, audience, nowSeconds = Date.now() / 1e3) {
	if (payload.iss !== issuer) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	const aud = payload.aud;
	if (!(aud === audience || Array.isArray(aud) && aud.some((value) => value === audience))) throw new AppError("FORBIDDEN", "Admin access is not allowed for this identity.");
	if (typeof payload.exp !== "number" || payload.exp <= nowSeconds) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	if (payload.nbf != null && (typeof payload.nbf !== "number" || payload.nbf > nowSeconds)) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
}
async function getAccessJwks(certsUrl, fetchImpl = fetch) {
	const cached = jwksCache.get(certsUrl);
	if (cached && cached.expiresAt > Date.now()) return cached.keys;
	const response = await fetchImpl(certsUrl);
	if (!response.ok) throw new AppError("UNAVAILABLE", "Could not verify admin identity.", { expose: false });
	const keys = (await response.json()).keys ?? [];
	jwksCache.set(certsUrl, {
		keys,
		expiresAt: Date.now() + JWKS_TTL_MS
	});
	return keys;
}
function bytesFromBase64Url(value) {
	const bytes = Uint8Array.from(decodeSegment(value), (char) => char.charCodeAt(0));
	return new Uint8Array(bytes);
}
async function verifyAccessJwt(token, env, fetchImpl = fetch) {
	const teamDomain = env.ACCESS_TEAM_DOMAIN?.trim();
	const audience = env.ACCESS_AUD?.trim();
	if (!teamDomain || !audience) throw new AppError("FORBIDDEN", "Admin access is not configured.");
	const issuer = accessIssuer(teamDomain);
	const payload = decodeJwtPayload(token);
	assertAccessClaims(payload, issuer, audience);
	const email = typeof payload.email === "string" ? payload.email : void 0;
	const sub = typeof payload.sub === "string" ? payload.sub : email;
	if (!email || !sub) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	const header = JSON.parse(decodeSegment(token.split(".")[0]));
	const jwk = (await getAccessJwks(accessCertsUrl(teamDomain), fetchImpl)).find((key) => key.kid === header.kid);
	if (!jwk) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	const key = await crypto.subtle.importKey("jwk", jwk, {
		name: "RSASSA-PKCS1-v1_5",
		hash: "SHA-256"
	}, false, ["verify"]);
	const [encodedHeader, encodedPayload, encodedSignature] = token.split(".");
	if (!await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, bytesFromBase64Url(encodedSignature), new TextEncoder().encode(`${encodedHeader}.${encodedPayload}`))) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	return {
		id: sub,
		email
	};
}
//#endregion
//#region src/lib/server/auth.ts
async function requireAdmin(request, env) {
	if (accessTakesOver(env, request)) {
		if (!accessConfigured(env)) throw new AppError("FORBIDDEN", "Admin access is not configured.");
		const accessToken = request.headers.get("cf-access-jwt-assertion");
		if (!accessToken) throw new AppError("FORBIDDEN", "Admin access is not configured.");
		return verifyAccessJwt(accessToken, env);
	}
	if (isProductionHost(request) && !passwordAdminAllowed(env, request)) throw new AppError("FORBIDDEN", "Admin access is not configured.");
	if (isLocalAdminSurface(env, request) && env.DEV_ADMIN_BYPASS === "true") return {
		id: "dev-admin",
		email: "dev-admin@localhost"
	};
	const token = request.headers.get("cf-access-jwt-assertion");
	if (token && accessConfigured(env)) return verifyAccessJwt(token, env);
	if (!passwordAdminAllowed(env, request)) throw new AppError("FORBIDDEN", "Admin access is not configured.");
	const allowed = allowedAdminEmails(env);
	if (allowed.size === 0) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	if (env.TEMP_ADMIN_EXPIRES_AT) {
		const expiresAt = Date.parse(env.TEMP_ADMIN_EXPIRES_AT);
		if (!Number.isFinite(expiresAt) || Date.now() >= expiresAt) throw new AppError("UNAUTHORIZED", "Temporary admin access has expired.");
	}
	const session = await createAdminSessionAuth(env, false, request).api.getSession({ headers: request.headers });
	if (!session || !allowed.has(session.user.email.toLowerCase())) throw new AppError("UNAUTHORIZED", "Admin authentication is required.");
	return {
		id: session.user.id,
		email: session.user.email
	};
}
function requireSameOrigin(request, env) {
	if (request.method === "GET" || request.method === "HEAD") return;
	const origin = request.headers.get("origin");
	const site = env.PUBLIC_SITE_URL;
	const requestOrigin = new URL(request.url).origin;
	const allowed = /* @__PURE__ */ new Set();
	if (site && !isAccessAdminHost(request)) allowed.add(new URL(site).origin);
	allowed.add(requestOrigin);
	if (origin && !allowed.has(origin)) throw new AppError("FORBIDDEN", "Cross-origin admin mutations are not allowed.");
}
//#endregion
export { requireSameOrigin as n, requireAdmin as t };
