globalThis.process ??= {};
globalThis.process.env ??= {};
import { d as AppError, f as toErrorBody } from "./src_BRRiv8WF.mjs";
import { i as createRequestId } from "./ids_Ddm5oCYW.mjs";
import { i as run, n as first } from "./db_BJi_UM06.mjs";
function requestIdFrom(request, existing) {
	return existing || request.headers.get("cf-ray") || createRequestId();
}
function json(data, status = 200, requestId) {
	const headers = new Headers({
		"content-type": "application/json; charset=utf-8",
		"cache-control": "private, no-store, no-cache, must-revalidate",
		"cdn-cache-control": "no-store",
		"cloudflare-cdn-cache-control": "no-store"
	});
	if (requestId) headers.set("x-request-id", requestId);
	return new Response(JSON.stringify(data), {
		status,
		headers
	});
}
function errorResponse(error, requestId) {
	if (error instanceof AppError) return json(toErrorBody(error, requestId), error.status, requestId);
	return json(toErrorBody(new AppError("UNAVAILABLE", "Something went wrong. Please try again.", { expose: false }), requestId), 500, requestId);
}
async function readJson(request) {
	if (!(request.headers.get("content-type") ?? "").includes("application/json")) throw new AppError("VALIDATION_FAILED", "Send a JSON request.", { status: 400 });
	const text = await request.text();
	if (text.length > 16384) throw new AppError("VALIDATION_FAILED", "Request is too large.", { status: 413 });
	try {
		return JSON.parse(text);
	} catch {
		throw new AppError("VALIDATION_FAILED", "Request JSON is invalid.", { status: 400 });
	}
}
function clientIp(request) {
	return request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for") || "local";
}
function fail(code, message, fields) {
	throw new AppError(code, message, { fields });
}
function logSafe(level, message, meta) {
	const payload = {
		level,
		message,
		...meta,
		ts: (/* @__PURE__ */ new Date()).toISOString()
	};
	if (level === "error") {
		console.error(JSON.stringify(payload));
		return;
	}
	if (level === "warn") {
		console.warn(JSON.stringify(payload));
		return;
	}
	console.log(JSON.stringify(payload));
}
//#endregion
//#region src/lib/server/rate-limit.ts
var WINDOW_MS = 6e5;
var MAX_HITS = 8;
var ADMIN_SIGNIN_WINDOW_MS = 6e5;
var ADMIN_SIGNIN_MAX_HITS = 5;
async function enforceRateLimit(db, bucket, options) {
	const windowMs = options?.windowMs ?? WINDOW_MS;
	const maxHits = options?.maxHits ?? MAX_HITS;
	const now = Date.now();
	const row = await first(db, "SELECT count, window_start FROM rate_limits WHERE bucket = ?", bucket);
	if (!row || now - Date.parse(row.window_start) >= windowMs) {
		await run(db, `INSERT INTO rate_limits (bucket, count, window_start)
       VALUES (?, 1, ?)
       ON CONFLICT(bucket) DO UPDATE SET count = 1, window_start = excluded.window_start`, bucket, new Date(now).toISOString());
		return;
	}
	if (row.count >= maxHits) throw new AppError("RATE_LIMITED", "Too many requests. Please wait a few minutes and try again.");
	await run(db, "UPDATE rate_limits SET count = count + 1 WHERE bucket = ?", bucket);
}
async function enforceAdminSignInRateLimit(db, ip) {
	await enforceRateLimit(db, `admin-signin:${ip}`, {
		windowMs: ADMIN_SIGNIN_WINDOW_MS,
		maxHits: ADMIN_SIGNIN_MAX_HITS
	});
}
//#endregion
export { fail as a, readJson as c, errorResponse as i, requestIdFrom as l, enforceRateLimit as n, json as o, clientIp as r, logSafe as s, enforceAdminSignInRateLimit as t };
