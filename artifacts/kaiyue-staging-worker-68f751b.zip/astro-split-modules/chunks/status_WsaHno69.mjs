globalThis.process ??= {};
globalThis.process.env ??= {};
//#region ../../packages/contracts/src/status.ts
var BOOKING_STATUSES = [
	"enquiry",
	"assigned",
	"completed",
	"cancelled"
];
var CONTACT_STATUSES = [
	"new",
	"replied",
	"closed"
];
var BOOKING_TRANSITIONS = {
	enquiry: ["assigned", "cancelled"],
	assigned: ["completed", "cancelled"],
	completed: [],
	cancelled: []
};
var CONTACT_TRANSITIONS = {
	new: ["replied", "closed"],
	replied: ["closed"],
	closed: []
};
function canTransitionBooking(from, to) {
	return BOOKING_TRANSITIONS[from].includes(to);
}
function canTransitionContact(from, to) {
	return CONTACT_TRANSITIONS[from].includes(to);
}
//#endregion
export { canTransitionBooking as a, CONTACT_TRANSITIONS as i, BOOKING_TRANSITIONS as n, canTransitionContact as o, CONTACT_STATUSES as r, BOOKING_STATUSES as t };
