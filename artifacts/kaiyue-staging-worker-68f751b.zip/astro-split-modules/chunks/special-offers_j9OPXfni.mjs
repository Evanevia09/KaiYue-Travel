globalThis.process ??= {};
globalThis.process.env ??= {};
import { n as __exportAll } from "./rolldown-runtime_BDykq6kg.mjs";
import { E as renderComponent, F as addAttribute, K as createAstro, M as renderTemplate, N as maybeRenderHead } from "./sequence_Cusz3XDW.mjs";
import { t as createComponent } from "./compiler_BO3FY072.mjs";
import { n as $$BaseLayout, r as $$PageHero, t as specialOfferUi } from "./special-offer-copy_CwYnkDzr.mjs";
import { r as localePath, t as localeFromPath } from "./i18n_s2qAaY1r.mjs";
import { c as listPublicOffers } from "./service_DalvdZP-.mjs";
import { env } from "cloudflare:workers";
//#region src/pages/special-offers.astro
var special_offers_exports = /* @__PURE__ */ __exportAll({
	default: () => $$SpecialOffers,
	file: () => $$file,
	prerender: () => false,
	url: () => $$url
});
createAstro("https://kaiyue-travel-staging.kai-yue.workers.dev");
var $$SpecialOffers = createComponent(async ($$result, $$props, $$slots) => {
	const Astro = $$result.createAstro($$props, $$slots);
	Astro.self = $$SpecialOffers;
	Astro.response.headers.set("Cache-Control", "private, no-store, no-cache, must-revalidate");
	Astro.response.headers.set("CDN-Cache-Control", "no-store");
	Astro.response.headers.set("Cloudflare-CDN-Cache-Control", "no-store");
	const locale = localeFromPath(Astro.url.pathname);
	const copy = specialOfferUi(locale);
	let items = [];
	try {
		items = (await listPublicOffers(env)).items;
	} catch {
		items = [];
	}
	const widgetOffers = items.map((item) => ({
		id: item.id,
		title: item.title
	}));
	return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, {
		"title": copy.title,
		"description": copy.description,
		"bookingEnabled": true,
		"showMobileBook": false,
		"specialOffers": widgetOffers,
		"data-astro-cid-dk3qou5t": true
	}, { "default": ($$result) => renderTemplate`${renderComponent($$result, "PageHero", $$PageHero, {
		"className": "hero--city-tours",
		"eyebrow": copy.heroEyebrow,
		"title": copy.heroTitle,
		"lede": copy.heroLede,
		"imageSrc": "/images/illustrative/city-tours-hero.jpg",
		"imageAlt": "Illustrative scene of a private car with visitors in Macau.",
		"data-astro-cid-dk3qou5t": true
	}, { "booking": ($$result) => renderTemplate`${renderComponent($$result, "BookingEmbedded", null, {
		"slot": "booking",
		"client:only": "react",
		"sourcePage": Astro.url.pathname,
		"enquiryKind": "special_offer",
		"data-astro-cid-dk3qou5t": true,
		"client:component-hydration": "only",
		"client:component-path": "/agent/repos/KaiYue-Travel/apps/web/src/components/booking/BookingEmbedded.tsx",
		"client:component-export": "BookingEmbedded"
	})}` })}${maybeRenderHead($$result)}<section class="section page-offers" aria-labelledby="special-offers-title" data-no-localize data-astro-cid-dk3qou5t><div class="wrap" data-astro-cid-dk3qou5t><p class="kicker" data-astro-cid-dk3qou5t>${copy.kicker}</p><h2 id="special-offers-title" data-astro-cid-dk3qou5t>${copy.heading}</h2><p class="lede" data-astro-cid-dk3qou5t>${copy.lede}</p>${items.length === 0 ? renderTemplate`<p class="muted" data-astro-cid-dk3qou5t>${copy.empty}</p>` : renderTemplate`<div class="home-tour-grid" data-astro-cid-dk3qou5t>${items.map((item, index) => renderTemplate`<article class="home-tour-card" data-astro-cid-dk3qou5t>${item.mainPhotoUrl && renderTemplate`<a class="home-tour-card__media"${addAttribute(localePath(`/special-offers/${item.id}`, locale), "href")} data-astro-cid-dk3qou5t><img${addAttribute(item.mainPhotoThumbUrl ?? item.mainPhotoUrl, "src")}${addAttribute(item.mainPhotoThumbUrl ? `${item.mainPhotoThumbUrl} 480w, ${item.mainPhotoUrl} 1600w` : void 0, "srcset")} sizes="(max-width: 700px) 100vw, (max-width: 1000px) 50vw, 33vw" alt=""${addAttribute(item.mainPhotoWidth ?? 1600, "width")}${addAttribute(item.mainPhotoHeight ?? 1104, "height")}${addAttribute(index === 0 ? "eager" : "lazy", "loading")} decoding="async"${addAttribute(index === 0 ? "high" : "low", "fetchpriority")} data-astro-cid-dk3qou5t></a>`}<div class="home-tour-card__body" data-astro-cid-dk3qou5t><h3 data-astro-cid-dk3qou5t><a${addAttribute(localePath(`/special-offers/${item.id}`, locale), "href")} data-astro-cid-dk3qou5t>${item.title}</a></h3><p data-astro-cid-dk3qou5t>${item.description}</p>${item.priceFrom != null && renderTemplate`<p class="home-tour-card__fact" data-astro-cid-dk3qou5t>${copy.from} ${item.priceFrom}</p>`}${item.terms && renderTemplate`<p data-astro-cid-dk3qou5t><strong data-astro-cid-dk3qou5t>${copy.terms}.</strong> ${item.terms}</p>`}<p data-astro-cid-dk3qou5t><a class="btn btn--primary"${addAttribute(localePath(`/special-offers/${item.id}`, locale), "href")} data-astro-cid-dk3qou5t>${copy.book}</a></p></div></article>`)}</div>`}</div></section>` })}`;
}, "/agent/repos/KaiYue-Travel/apps/web/src/pages/special-offers.astro", void 0);
var $$file = "/agent/repos/KaiYue-Travel/apps/web/src/pages/special-offers.astro";
var $$url = "/special-offers";
//#endregion
export { special_offers_exports as n, $$SpecialOffers as t };
