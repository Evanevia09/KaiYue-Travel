# Staging Worker deployment package — FINAL REPORT

Built at committed head `68f751be9e79171198020e7a157f295bff5db1ee` (short `68f751b`).
This archive is a box copy. It is not an upload. No secrets. No `.env` / `.dev.vars`.

Independent staging-readiness review is OK for a **staging-only** trial of this head.
Production temporary-login capability is already approved (t73/t74). No extra user
approval is required for that later production configuration. This agent still
does not merge, upload, deploy, or retry production Workers Builds.

## Exact identifiers

| Item | Value |
| --- | --- |
| Source SHA | `68f751be9e79171198020e7a157f295bff5db1ee` |
| Script name | `kaiyue-travel-staging` |
| **main_module (exact name)** | `entry.js` |
| Module MIME | `application/javascript+module` |
| `entry.js` bytes | 4185645 |
| `entry.js` sha256 | `28cb9f0a561d79732c4922ddd50489a19134c501b1b0134e52ad75585195cca7` |
| Bundler | `npx wrangler deploy --dry-run --env staging --name kaiyue-travel-staging --keep-vars` (no network) |
| Dry-run reported size | 4087.54 KiB / gzip 820.84 KiB |
| Astro split modules (inspection) | `astro-split-modules/` — 73 files, including `entry.mjs` + chunks (`login_Dsyd4KSj.mjs`, `admin-gate_CU-fRGZ7.mjs`, …) |
| Split MIME | `application/javascript+module` for `.mjs` |

Do **not** PUT the Astro split tree unless `main_module` is also changed to `entry.mjs` and every chunk is attached. The recovered Nov5 Worker used a single Wrangler-bundled `entry.js`. This package matches that name.

Source maps were omitted (they contain local absolute paths).

## HARD BLOCKER — do not use assets.jwt with keep_assets

Independent API-plan review is correct. Official Upload Worker metadata:
“An explicit `assets` upload takes precedence over `keep_assets`.”
The 14-file session JWT is a **version ledger**, not a patch. Using it **drops** unpublished public files that are not in those 14 paths.

`keep_assets:true` with **no** `assets` object keeps the current public set and can replace Worker JS only. It does **not** install LoginForm / `api._aekQyCR.js`. Live GET of those URLs returns cached `404.html` **without** Worker middleware headers, so extra Worker text modules cannot serve them. `run_worker_first` for only those 14 paths is an official wrangler field, but applying `assets.config` under `keep_assets` without a complete-manifest jwt is not a documented additive operation (community repro: routing stays `serve_directly`).

`metadata.staging.keep_assets.and_new_assets.TEMPLATE.json` is **UNSAFE — do not send.** See `HARD-BLOCKER.md` in this archive and `docs/records/2026-11-10-staging-asset-add-blocker.md`.

Unblockers that are not this agent inventing APIs: a Cloudflare complete asset export of the current staging Worker, or an official additive-asset operation. Independent review and staging approval still required before mutations.

## keep_assets is not enough (14 files still 404)

`keep_assets: true` is supported on Cloudflare Upload Worker metadata. It **retains the previous version’s asset set**. It does **not** install new hashed files.

GET-probed 31 dist `/_astro` files against live staging and production:

- **17 MATCH** (HTTP 200, sha256 equal on staging and production). `keep_assets:true` covers these public islands. Do not re-upload them. Do not upload rebuilt HTML (this dist was built with staging `PUBLIC_SITE_URL` and would replace live HTML).
- **14 NEW / 404** on both staging and production. `keep_assets` will **not** create them. `/login` is SSR (`prerender=false`) and will emit script tags for these hashes once this Worker is live.

`api._aekQyCR.js` is the admin fetch helper. It **404s on live today**. After sign-in, `/admin` will request it. `keep_assets` alone leaves that 404 in place.

### Required new uploads (14)

| path | sha256 | cf_hash_32 (first 32 hex of sha256) | bytes | why |
| --- | --- | --- | --- | --- |
| `/_astro/LoginForm.DI7HqLqN.js` | `61254b0edcf09f90df2b70f41ddfc85fcd901e8a6a26dee00fd8317668dfa8d8` | `61254b0edcf09f90df2b70f41ddfc85f` | 1486 | `/login` island (404 live) |
| `/_astro/AdminLocaleSwitch.AW9mvxVt.js` | `d55fe39e8f7f7c0ee2090c3b6fa58f74b4e4badf4ce49953e82dc09e59f5ed5b` | `d55fe39e8f7f7c0ee2090c3b6fa58f74` | 767 | `/login` and `/admin` |
| `/_astro/admin-i18n.BqNzmZPb.js` | `83d96e89a82e8612c72cac618d724156a1d829a8524e98748d45b5ae5ed09f84` | `83d96e89a82e8612c72cac618d724156` | 38287 | `/login` and `/admin` |
| `/_astro/api._aekQyCR.js` | `4dc3ce0595b63c220cdf7fd84839415a6170799b8a913f7040f15765b9d975d9` | `4dc3ce0595b63c220cdf7fd84839415a` | 488 | `/admin` fetch helper (404 live) |
| `/_astro/SignOutButton.DcT_T_1m.js` | `f9811f3ba7690b0da1bf1b72a39b55be2341e90b0b52c73627788e636f5ba8a2` | `f9811f3ba7690b0da1bf1b72a39b55be` | 531 | `/admin` after sign-in |
| `/_astro/DashboardPanel.BOTjT2Gn.js` | `0c4e40f794022cbb1fe0ac0ece75ac27bf43b52775f91ef3b2a1386c8b21a18d` | `0c4e40f794022cbb1fe0ac0ece75ac27` | 3240 | `/admin` after sign-in |
| `/_astro/BookingsPanel.bFDjlHxY.js` | `2c9ec0b6b676e866035ba961e5827f66e6e55bf1a6a42c25a90cde781c3ee679` | `2c9ec0b6b676e866035ba961e5827f66` | 7320 | `/admin` after sign-in |
| `/_astro/BookingDetailPanel.BkbY9XB-.js` | `69a984a14db47b22971f782757c7b73239599cdd504a076d5336da68948628bc` | `69a984a14db47b22971f782757c7b732` | 10843 | `/admin` after sign-in |
| `/_astro/CalendarPanel.C4LBMqaW.js` | `daf7f06501c05271d474ce1221aea7f73f8027408d8c66481ae0eb087ec4667e` | `daf7f06501c05271d474ce1221aea7f7` | 28744 | `/admin` after sign-in |
| `/_astro/ContactsPanel.C4l2f9ag.js` | `f557bde41604ba99d6d221d69484c71f23600b30183549d8152d6b4d2d35cbed` | `f557bde41604ba99d6d221d69484c71f` | 1500 | `/admin` after sign-in |
| `/_astro/ContactDetailPanel.BX3k8Way.js` | `47cbb618fe3f8a97cb197e7571d7f08c6f7e142d8d7c686b19b149e0571bc87a` | `47cbb618fe3f8a97cb197e7571d7f08c` | 2035 | `/admin` after sign-in |
| `/_astro/InventoryPanel.DHPXN2e6.js` | `e1def28e8fc661facd60571ecde105ac7ff04d316a4eea431cba2fee434389fd` | `e1def28e8fc661facd60571ecde105ac` | 7060 | `/admin` after sign-in |
| `/_astro/OffersPanel.ChIAc9eb.js` | `a2e867361639f125abffb06e58f99aac63e994271ac2f9dec82e67c1ae8b7d53` | `a2e867361639f125abffb06e58f99aac` | 14213 | `/admin` after sign-in |
| `/_astro/SetupForm.CNBXj-dW.js` | `b0960f502140254b4d8c27ac1a451f753452ba76760ff9fea9639c768a66c14e` | `b0960f502140254b4d8c27ac1a451f75` | 1808 | `/setup-admin` (loopback-only route) |

Bytes are in `new-assets-required/` (basename only). Session body is `assets-upload-session.manifest.json`.

### Login graph (what `/login` will request)

| path | live staging/prod | keep_assets covers? |
| --- | --- | --- |
| `/_astro/LoginForm.DI7HqLqN.js` | 404 | **NO — upload required** |
| `/_astro/AdminLocaleSwitch.AW9mvxVt.js` | 404 | **NO — upload required** |
| `/_astro/admin-i18n.BqNzmZPb.js` | 404 | **NO — upload required** |
| `/_astro/auth-client.B2D_TZZE.js` | 200, sha256 match | yes |
| `/_astro/react.Bi21MRdE.js` | 200, sha256 match | yes |
| `/_astro/jsx-runtime.myd_k2E3.js` | 200, sha256 match | yes |

### Matching public `/_astro` (keep_assets OK)

`auth-client.B2D_TZZE.js`, `BaseLayout.astro_astro_type_script_index_1_lang.gK1lsl9Z.js`, `BaseLayout.Dq8L4eEk.css`, `BookingEmbedded.cFmMjUfb.js`, `BookingForm.BY2srzpk.js`, `BookingLauncher.BqoyMjDS.js`, `BookingSheet.BjhsA3XK.js`, `client.DrPMauyT.js`, `ContactForm.CJmZZAL8.js`, `i18n.CluPyr_6.js`, `jsx-runtime.myd_k2E3.js`, `react-dom.Zo7SlITr.js`, `react.Bi21MRdE.js`, `rolldown-runtime.C_o-9qvY.js`, `src.BLL3_vvi.js`, `status.CrrMiddk.js`, `store.BKJ62xil.js`.

Full hashes: `MANIFEST.json` → `existing_matching_astro` / `asset_comparisons` / `dist_assets` (139 client files hashed for comparison; HTML/images were **not** uploaded and must stay under `keep_assets`).

## Safe asset-upload then PUT (PM / sanctioned connector)

This agent did not and will not call Cloudflare write APIs, `wrangler deploy`, or `wrangler versions upload`.

1. `POST /accounts/:account_id/workers/scripts/kaiyue-travel-staging/assets-upload-session`  
   body = `assets-upload-session.manifest.json` (the 14 new files only).
2. `POST /accounts/:account_id/workers/assets/upload?base64=true` with the JWT from step 1.  
   Each part name = `cf_hash_32`, value = base64(file bytes), `Content-Type: application/javascript`.
3. `PUT /accounts/:account_id/workers/scripts/kaiyue-travel-staging` multipart:
   - metadata JSON = `metadata.staging.keep_assets.and_new_assets.TEMPLATE.json` with `assets.jwt` replaced by the **completion** JWT from step 2 (`keep_assets: true` still set so existing public assets remain).
   - file field `entry.js`, MIME `application/javascript+module`, filename `entry.js`.
   - `keep_bindings: ["secret_text"]` so `BETTER_AUTH_SECRET` / `RESEND_API_KEY` / `ADMIN_SETUP_TOKEN` stay. Secret **values are not in this zip**.

`package-multipart.mjs` builds a **local** `multipart.bin` from `metadata.staging.keep_assets.json` + `entry.js`. It does not send HTTP and does not read credentials. If you use the JWT template, copy that metadata over the keep_assets-only file first, paste the completion JWT, then run the packer.

**PUT deploys immediately.** There is no dry-run on that API. Confirm staging hostname only.

`keep_assets`-only PUT (skipping steps 1–2) would ship the new Worker JS but leave `/login` and `/admin` islands 404, including `LoginForm.DI7HqLqN.js` and `api._aekQyCR.js`.

## env.staging bindings (names/settings, no secret values)

Worker name: `kaiyue-travel-staging`  
`compatibility_date`: `2026-09-01`  
`compatibility_flags`: `nodejs_compat`

| Binding | Type | Setting |
| --- | --- | --- |
| `ASSETS` | assets | keep previous + add the 14 files above |
| `DB` | D1 | `kaiyue-travel-staging` / `043cd0ff-a1e6-4b5e-98c1-968c286e0c70` |
| `OFFERS_BUCKET` | R2 | `kaiyue-offers-staging` |
| `ENVIRONMENT` | plain_text | `preview` |
| `PUBLIC_SITE_URL` | plain_text | `https://kaiyue-travel-staging.kai-yue.workers.dev` |
| `BUSINESS_TIMEZONE` | plain_text | `Asia/Macau` |
| `BOOKING_NOTICE_HOURS` | plain_text | `24` |
| `WHATSAPP_NUMBER` | plain_text | `+85328338882` |
| `ACCESS_TEAM_DOMAIN` | plain_text | `""` (empty; password admin allowed on staging) |
| `ACCESS_AUD` | plain_text | `""` |
| `DEV_ADMIN_BYPASS` | plain_text | `false` |
| `ADMIN_EMAILS` | plain_text | `daniel@kaiyuemacau.com` (already on staging; do not rotate) |
| `TEMP_ADMIN_EXPIRES_AT` | plain_text | `2026-11-24T15:59:59+08:00` (already on staging; do not rotate) |

Secrets (keep, do not put values in metadata): `BETTER_AUTH_SECRET`, `RESEND_API_KEY`, `ADMIN_SETUP_TOKEN`.

Do not bind D1 `069aa442-30c9-4454-ab3a-26eb372b3a1f`.

## Constraints

- No `wrangler deploy` / `wrangler versions upload` from the agent that built this.
- No production Workers Builds retry for `kaiyue-travel`.
- No secret values, no env files, no source maps.
- Do not upload dist HTML/CSS/images from this rebuild; `keep_assets` preserves current public pages.
- User approval for **live** after staging persists is already granted for the temporary-login capability (t73/t74). Staging trial of `68f751b` is the remaining operational step.
- Provisioner zip `artifacts/kaiyue-provision-admin-local.zip` is a **separate** independently reviewed artifact. PM already started that server. This Worker package does not change provisioner bytes or behaviour.

## Archive layout

- `FINAL-REPORT.md` — this file
- `SOURCE-SHA.txt` — full git SHA
- `MANIFEST.json` — modules, dist hashes, live GET comparisons, bindings
- `worker-modules/entry.js` — PUT this as `main_module`
- `astro-split-modules/` — inspection only
- `new-assets-required/` — the 14 files + `NEW_ASSETS.json`
- `metadata.staging.keep_assets.json` — keep_assets PUT template (insufficient for `/login` alone)
- `metadata.staging.keep_assets.and_new_assets.TEMPLATE.json` — same + `assets.jwt` placeholder
- `assets-upload-session.manifest.json` — step 1 body
- `package-multipart.mjs` — local multipart dump; no credentials
